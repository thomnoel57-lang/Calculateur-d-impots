export function formatEuros(value: number, showSign = false): string {
  if (!Number.isFinite(value)) return '0 €';
  const rounded = Math.round(value);
  const abs = Math.abs(rounded);
  const formatted = abs.toLocaleString('fr-FR').replace(/[\u202f\u00a0]/g, ' ');
  if (rounded < 0) return `−${formatted} €`;
  if (showSign && rounded > 0) return `+${formatted} €`;
  return `${formatted} €`;
}

export function formatExactEuros(value: number): string {
  if (!Number.isFinite(value)) return '0,00 €';
  return value.toLocaleString('fr-FR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + ' €';
}

export function formatPct(value: number, decimals = 1, showSign = false): string {
  if (!Number.isFinite(value)) return '0,0 %';
  const sign = showSign && value > 0 ? '+' : value < 0 ? '−' : '';
  const abs = Math.abs(value);
  return (
    sign +
    abs.toLocaleString('fr-FR', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }) +
    ' %'
  );
}

export function clamp(val: number, min: number, max: number): number {
  if (!Number.isFinite(val)) return min;
  return Math.max(min, Math.min(max, val));
}

const FRENCH_MONTHS = [
  'janvier',
  'février',
  'mars',
  'avril',
  'mai',
  'juin',
  'juillet',
  'août',
  'septembre',
  'octobre',
  'novembre',
  'décembre',
];

const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

export function formatFrenchDateFromDayIndex(dayIndex: number): string {
  const safeDay = clamp(Math.round(dayIndex), 0, 365);
  if (safeDay === 0) return '1er janvier';
  let remaining = safeDay;
  for (let m = 0; m < 12; m++) {
    if (remaining <= DAYS_IN_MONTH[m]) {
      const dayNum = Math.max(1, remaining);
      return `${dayNum === 1 ? '1er' : dayNum} ${FRENCH_MONTHS[m]}`;
    }
    remaining -= DAYS_IN_MONTH[m];
  }
  return '31 décembre';
}
