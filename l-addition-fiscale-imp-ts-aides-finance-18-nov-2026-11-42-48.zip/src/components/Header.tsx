import React from 'react';
import {
  BarChart3,
  BookOpen,
  Landmark,
  Receipt,
  RotateCcw,
  SlidersHorizontal,
  Users,
} from 'lucide-react';

export type AppViewTab =
  | 'simulateur'
  | 'finance'
  | 'panorama'
  | 'audit'
  | 'registre';

interface HeaderProps {
  activeTab: AppViewTab;
  onChangeTab: (tab: AppViewTab) => void;
  activeTaxCount: number;
  totalCatalogCount: number;
  beginnerMode: boolean;
  onToggleBeginnerMode: () => void;
  onReset: () => void;
}

const NAV_ITEMS: { id: AppViewTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'simulateur', label: 'Simulateur & Schémas', icon: BarChart3 },
  { id: 'finance', label: 'Comprendre la Finance', icon: Landmark },
  { id: 'panorama', label: 'Qui Paye Quoi ?', icon: Users },
  { id: 'audit', label: 'Audit 100 %', icon: SlidersHorizontal },
  { id: 'registre', label: 'Impôts & Aides', icon: Receipt },
];

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onChangeTab,
  beginnerMode,
  onToggleBeginnerMode,
  onReset,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-[#E4DFD5] bg-[#FFFDF9]/95 backdrop-blur-md no-print">
      <div className="mx-auto flex max-w-[1440px] flex-wrap lg:flex-nowrap items-center justify-between gap-4 lg:gap-8 px-4 py-2.5 sm:px-6">
        {/* Zone 1 : Marque éditoriale */}
        <button
          type="button"
          onClick={() => onChangeTab('simulateur')}
          className="font-serif text-lg font-bold tracking-tight text-[#141413] whitespace-nowrap shrink-0 cursor-pointer hover:text-[#1E3A8A] transition-colors"
        >
          L’Addition Fiscale
        </button>

        {/* Zone 2 : Navigation principale */}
        <nav
          aria-label="Vues principales du simulateur"
          className="flex flex-wrap sm:flex-nowrap items-center gap-1 order-3 lg:order-2 w-full lg:w-auto justify-start lg:justify-center"
        >
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onChangeTab(item.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-[#141413] text-white'
                    : 'text-[#57534E] hover:bg-[#F2EFE8] hover:text-[#141413]'
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3 : Action Pédagogie + Reset */}
        <div className="flex items-center gap-2 shrink-0 order-2 lg:order-3">
          <button
            type="button"
            onClick={onToggleBeginnerMode}
            title="Basculer entre explications simplifiées et vue dense"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              beginnerMode
                ? 'border-[#BFDBFE] bg-[#EFF6FF] text-[#1E3A8A] hover:bg-[#DBEAFE]'
                : 'border-[#D6D0C4] bg-white text-[#44403C] hover:bg-[#FAF8F4]'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5 shrink-0" />
            <span>{beginnerMode ? 'Mode Pédago : ON' : 'Mode Expert'}</span>
          </button>

          <button
            type="button"
            onClick={onReset}
            title="Réinitialiser les réglages du profil"
            className="inline-flex items-center gap-1 rounded-lg border border-[#D6D0C4] bg-white px-2.5 py-1.5 text-xs font-medium text-[#57534E] hover:bg-[#FAF8F4] hover:text-[#141413] whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span className="hidden xl:inline">Reset</span>
          </button>
        </div>
      </div>
    </header>
  );
};
