import React from 'react';
import { Building2, CheckCircle2, HelpCircle, ShieldCheck, Wallet } from 'lucide-react';
import { SimulationResult, SimulationState } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface HeroSummaryProps {
  state: SimulationState;
  result: SimulationResult;
  beginnerMode: boolean;
  onToggleInclureSociete: (val: boolean) => void;
  onToggleImpotsLatentsHolding: (val: boolean) => void;
  onOpenFinanceLab: () => void;
}

export const HeroSummary: React.FC<HeroSummaryProps> = ({
  state,
  result,
  beginnerMode,
  onToggleInclureSociete,
  onToggleImpotsLatentsHolding,
  onOpenFinanceLab,
}) => {
  const { holdingAndValuation: hv, aides } = result;
  const impotsEnAttenteActifs =
    state.inclureTaxesSocieteEtHolding && state.inclureImpotsLatentsHolding
      ? result.impotsEnAttenteHolding
      : 0;
  const reservesSocieteHolding =
    state.inclureTaxesSocieteEtHolding
      ? Math.max(
          0,
          hv.reserveRestantEnHolding + hv.beneficeRetenuEnFiliale - impotsEnAttenteActifs
        )
      : 0;
  const hasCompanyOrHolding =
    result.impotsPayesParEntreprise > 0 ||
    hv.reserveRestantEnHolding > 0 ||
    hv.beneficeRetenuEnFiliale > 0 ||
    hv.valorisationPapierEstimee > 0;
  const hasLatentHoldingReserves = hv.totalImpotsEnAttenteFlux > 0;

  const isNetBeneficiary = result.tauxNetApresAidesPct < 0;

  return (
    <section className="rounded-2xl border border-[#E4DFD5] bg-white p-4 sm:p-6 shadow-xs space-y-4">
      {/* En-tête éditorial façon grand journal économique */}
      <div className="flex flex-col gap-3 border-b-2 border-[#141413] pb-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-[#78716C]">
            République Française · Exercice 2026 · Zéro double comptage
          </div>
          <h2 className="font-editorial text-2xl sm:text-3xl font-bold tracking-tight text-[#141413] mt-0.5">
            L’ADDITION FISCALE INTÉGRALE
          </h2>
          <p className="text-xs text-[#57534E] mt-0.5">
            État · URSSAF · Sécurité Sociale · Collectivités · Douanes · Holding &amp; Redistribution 100 % incluse
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="inline-flex items-center gap-1.5 text-[#15803D] font-semibold">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>
              Balance comptable vérifiée :{' '}
              <strong className="font-mono-num">
                {result.ecartBalanceComptable === 0 ? '0 € d’écart' : formatEuros(result.ecartBalanceComptable)}
              </strong>
            </span>
          </div>

          <label className="inline-flex items-center gap-2 rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-3 py-1.5 font-semibold text-[#141413] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={state.inclureTaxesSocieteEtHolding}
              onChange={(e) => onToggleInclureSociete(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-[#CBC4B6] accent-[#1E3A8A]"
            />
            <span>Tout inclure à 100 % (Société + Holding)</span>
          </label>

          {state.inclureTaxesSocieteEtHolding && hasLatentHoldingReserves && (
            <label className="inline-flex items-center gap-2 rounded-lg border border-[#DDD6FE] bg-[#F5F3FF] px-3 py-1.5 font-semibold text-[#5B21B6] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={state.inclureImpotsLatentsHolding}
                onChange={(e) => onToggleImpotsLatentsHolding(e.target.checked)}
                className="h-3.5 w-3.5 rounded border-[#C4B5FD] accent-[#6D28D9]"
              />
              <span>Compter impôts en attente (Holding/Filiale)</span>
            </label>
          )}
        </div>
      </div>

      {/* Distinction Entreprise / Holding / Impôts en attente / Poche */}
      {hasCompanyOrHolding && (
        <div className="flex flex-col gap-2 rounded-xl border border-[#FDE68A] bg-[#FFFBEB] p-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-2.5 text-xs text-[#78350F]">
            <Building2 className="h-4 w-4 shrink-0 text-[#B45309] mt-0.5" />
            <div>
              <strong className="text-[#141413]">Entreprise &amp; Holding ≠ Argent en poche :</strong>{' '}
              Votre société/holding paie{' '}
              <strong className="font-mono-num">{formatEuros(result.impotsEntrepriseImmediats)}</strong>{' '}
              d’impôts immédiats (IS, CFE, 1,25 %, IS trésorerie, taxe 2 %),{' '}
              <strong className="font-mono-num text-[#6D28D9]">
                {formatEuros(hv.totalImpotsEnAttenteFlux)}
              </strong>{' '}
              d’<strong>impôts en attente</strong> (PFU 31,4 % + CEHR + CDHR si sortie vers poche), et il reste{' '}
              <strong className="font-mono-num">{formatEuros(hv.reservesNettesApresImpotsEnAttente)}</strong>{' '}
              de réserves nettes bloquées (holding + filiale)
              {hv.impotLatentReport150OBTer > 0 && (
                <>
                  {' '}
                  · Stock 150-0 B ter en report :{' '}
                  <strong className="font-mono-num">{formatEuros(hv.impotLatentReport150OBTer)}</strong> d’impôt latent.
                </>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenFinanceLab}
            className="text-xs font-bold text-[#1E3A8A] underline underline-offset-4 hover:text-[#172554] cursor-pointer whitespace-nowrap shrink-0"
          >
            Ouvrir le Labo Finance &amp; Arnault →
          </button>
        </div>
      )}

      {/* 5 KPI principaux en carte éditoriale */}
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-5">
        {/* KPI 1 : Richesse totale créée */}
        <div className="rounded-xl border border-[#E4DFD5] bg-[#FAF8F4] p-4">
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
            <span>Richesse totale créée</span>
            {beginnerMode && (
              <span title="Super-brut payé par l'employeur + revenus du capital + bénéfices/impôts société si inclus.">
                <HelpCircle className="h-3.5 w-3.5 text-[#A8A29E]" />
              </span>
            )}
          </div>
          <div className="mt-1.5 font-mono-num text-2xl font-extrabold text-[#141413]">
            {formatEuros(result.richesseCreeeTotale)}
          </div>
          <div className="mt-1 text-[11px] text-[#57534E]">
            Soit <strong className="font-mono-num">{formatEuros(result.richesseCreeeTotale / 12)}</strong> / mois
          </div>
        </div>

        {/* KPI 2 : Total prélevé (100% inclus) */}
        <div className="rounded-xl border border-[#FECDD3] bg-[#FFF1F2]/70 p-4">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#9F1239]">
            {state.inclureTaxesSocieteEtHolding
              ? 'Total prélevé (100 %)'
              : 'Impôts perso seuls'}
          </div>
          <div className="mt-1.5 font-mono-num text-2xl font-extrabold text-[#BE123C]">
            −{formatEuros(result.totalPrelevements)}
          </div>
          <div className="mt-1 text-[11px] text-[#9F1239]/80">
            Taux brut : <strong className="font-mono-num">{formatPct(result.tauxPrelevementReelPct)}</strong> ·{' '}
            {impotsEnAttenteActifs > 0
              ? `dont ${formatEuros(impotsEnAttenteActifs, true)} en attente`
              : `${result.activeTaxCount} taxes actives`}
          </div>
        </div>

        {/* KPI 3 : Aides + Études + Santé + Droits retraite (100%) */}
        <div className="rounded-xl border border-[#A7F3D0] bg-[#ECFDF5]/60 p-4">
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#065F46]">
            <span className="inline-flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5" />
              Aides &amp; droits 100 %
            </span>
          </div>
          <div className="mt-1.5 font-mono-num text-2xl font-extrabold text-[#047857]">
            {formatEuros(aides.totalAidesEtServicesComplet, true)}
          </div>
          <div className="mt-1 text-[11px] text-[#065F46]/80">
            Cash : <strong className="font-mono-num">{formatEuros(aides.totalAidesMonetaires, true)}</strong> ·
            Nature/droits : <strong className="font-mono-num">{formatEuros(aides.totalPrestationsEnNatureEtDroits, true)}</strong>
          </div>
        </div>

        {/* KPI 4 : Taux Net Intégral 100% */}
        <div
          className={`rounded-xl border p-4 ${
            isNetBeneficiary
              ? 'border-[#86EFAC] bg-[#F0FDF4]'
              : 'border-[#BFDBFE] bg-[#EFF6FF]/70'
          }`}
        >
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#44403C]">
            <span>Taux Net Intégral 100 %</span>
            {beginnerMode && (
              <span title="(Impôts − Aides cash − Études/Santé/Droits retraite/Services) ÷ Richesse. Négatif = vous recevez plus que vous ne cotisez.">
                <HelpCircle className="h-3.5 w-3.5 text-[#78716C]" />
              </span>
            )}
          </div>
          <div
            className={`mt-1.5 font-mono-num text-2xl font-extrabold ${
              isNetBeneficiary ? 'text-[#15803D]' : 'text-[#1E3A8A]'
            }`}
          >
            {formatPct(result.tauxNetApresAidesPct, 1, true)}
          </div>
          <div className="mt-1 text-[11px] text-[#57534E]">
            Cash seul : <strong className="font-mono-num">{formatPct(result.tauxNetApresAidesMonetairesPct, 1, true)}</strong>
          </div>
        </div>

        {/* KPI 5 : Net pur restant en poche */}
        <div className="rounded-xl border border-[#141413] bg-[#141413] p-4 text-white">
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#D6D3D1]">
            <span className="inline-flex items-center gap-1">
              <Wallet className="h-3.5 w-3.5 text-[#4ADE80]" />
              Net pur en poche
            </span>
          </div>
          <div className="mt-1.5 font-mono-num text-2xl font-extrabold text-white">
            {formatEuros(result.resteNetApresAidesEtTaxes)}
          </div>
          <div className="mt-1 text-[11px] text-[#D6D3D1]">
            {reservesSocieteHolding > 0
              ? `+ ${formatEuros(reservesSocieteHolding, true)} net en société/holding`
              : `${formatEuros(result.resteNetApresAidesEtTaxes / 12)} / mois dispo réel`}
          </div>
        </div>
      </div>

      {/* Détail complet de la redistribution 100% (Cash + Études + Santé + Droits retraite + Services publics) */}
      <div className="pt-3 border-t border-[#EFECE4] flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between text-xs">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[#44403C]">
          <span className="font-bold text-[#141413]">Inclus à 100 % en face de vos impôts :</span>
          {aides.items.map((a) => (
            <span key={a.id} className="font-mono-num">
              {a.label.split(' (')[0]} :{' '}
              <strong className="text-[#047857]">{formatEuros(a.amount, true)}</strong>
            </span>
          ))}
          {aides.itemsEnNatureEtDroits.map((a) => (
            <span key={a.id} className="font-mono-num">
              {a.label.split(' (')[0]} :{' '}
              <strong className="text-[#1E3A8A]">{formatEuros(a.amount, true)}</strong>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};
