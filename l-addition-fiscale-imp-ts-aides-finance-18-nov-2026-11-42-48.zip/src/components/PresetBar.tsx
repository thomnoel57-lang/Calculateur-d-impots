import React from 'react';
import { PresetProfile } from '../types/fiscal';

interface PresetBarProps {
  presets: PresetProfile[];
  activePresetId: string;
  onSelectPreset: (preset: PresetProfile) => void;
  beginnerMode: boolean;
}

export const PresetBar: React.FC<PresetBarProps> = ({
  presets,
  activePresetId,
  onSelectPreset,
  beginnerMode,
}) => {
  const activePreset = presets.find((p) => p.id === activePresetId);

  return (
    <section className="rounded-2xl border border-[#E4DFD5] bg-white p-4 sm:p-5 shadow-xs no-print">
      <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
        <div>
          <h2 className="font-editorial text-base sm:text-lg font-bold text-[#141413]">
            Tester un exemple réel en 1 clic (des plus modestes aux ultra-riches) :
          </h2>
          <p className="text-xs text-[#78716C]">
            12 profils complets incluant à 100 % impôts perso, société/holding et aides (cash + études, santé, retraite).
          </p>
        </div>
        <span className="text-xs font-medium text-[#78716C]">
          {presets.length} situations · Barèmes 2026
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
        {presets.map((preset) => {
          const isActive = preset.id === activePresetId;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onSelectPreset(preset)}
              aria-pressed={isActive}
              className={`group flex flex-col items-start rounded-xl border p-2.5 text-left transition-all cursor-pointer ${
                isActive
                  ? 'border-[#141413] bg-[#141413] text-white shadow-xs'
                  : 'border-[#E4DFD5] bg-[#FAF8F4] text-[#141413] hover:border-[#CBC4B6] hover:bg-white'
              }`}
            >
              <span
                className={`text-[10px] font-semibold uppercase tracking-wider mb-0.5 ${
                  isActive ? 'text-[#D6D3D1]' : 'text-[#78716C]'
                }`}
              >
                {preset.badge}
              </span>
              <span className="text-xs font-bold leading-snug line-clamp-1">
                {preset.shortName}
              </span>
              <span
                className={`mt-0.5 text-[11px] font-mono-num ${
                  isActive ? 'text-[#F2EFE8]' : 'text-[#57534E]'
                }`}
              >
                {preset.incomeTag}
              </span>
            </button>
          );
        })}
      </div>

      {activePreset && (
        <div className="mt-3.5 pt-3 border-t border-[#EFECE4] flex flex-col gap-1.5 sm:flex-row sm:items-center sm:justify-between text-xs text-[#44403C]">
          <p>
            <strong className="font-bold text-[#141413]">{activePreset.name} :</strong>{' '}
            {activePreset.summary}
          </p>
          {beginnerMode && (
            <p className="text-[#1E3A8A] font-semibold shrink-0 sm:max-w-md sm:text-right">
              {activePreset.fiscalInsight}
            </p>
          )}
        </div>
      )}
    </section>
  );
};
