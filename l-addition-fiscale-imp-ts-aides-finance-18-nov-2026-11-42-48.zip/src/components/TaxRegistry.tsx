import React, { useMemo, useState } from 'react';
import { Download, Printer, Search } from 'lucide-react';
import { TAX_FAMILIES } from '../data/taxCatalog';
import { SimulationResult, SimulationState, TaxFamilyId } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface TaxRegistryProps {
  state: SimulationState;
  result: SimulationResult;
  beginnerMode: boolean;
}

type FilterMode = 'all' | 'active' | 'perso' | 'societe' | 'en_attente';

export const TaxRegistry: React.FC<TaxRegistryProps> = ({
  state,
  result,
  beginnerMode,
}) => {
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<FilterMode>('all');
  const [familyFilter, setFamilyFilter] = useState<TaxFamilyId | 'all'>('all');

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return result.items.filter((it) => {
      if (filterMode === 'active' && it.amount === 0) return false;
      if (filterMode === 'perso' && it.entry.incidence !== 'personnel') return false;
      if (
        filterMode === 'societe' &&
        it.entry.incidence !== 'entreprise_societe' &&
        it.entry.incidence !== 'holding_en_attente'
      ) {
        return false;
      }
      if (filterMode === 'en_attente' && it.entry.incidence !== 'holding_en_attente') {
        return false;
      }
      if (familyFilter !== 'all' && it.entry.family !== familyFilter) return false;
      if (q) {
        const hay = `${it.entry.name} ${it.entry.shortName} ${it.entry.simpleSummary} ${it.entry.legalRef}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [result.items, search, filterMode, familyFilter]);

  const handleExportCsv = () => {
    const header = [
      'ID',
      'Nom',
      'Famille',
      'Incidence',
      'Montant_EUR',
      'Taux_2026',
      'Reference_Legale',
    ].join(';');
    const rows = result.items.map((it) =>
      [
        it.entry.id,
        `"${it.entry.name.replace(/"/g, '""')}"`,
        TAX_FAMILIES[it.entry.family].shortLabel,
        it.entry.incidence,
        it.amount,
        `"${it.entry.rate2026.replace(/"/g, '""')}"`,
        `"${it.entry.legalRef.replace(/"/g, '""')}"`,
      ].join(';')
    );
    const csv = [header, ...rows].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `addition-fiscale-2026-${state.statut}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Aides sociales & Prestations en nature 100 % incluses */}
      <section className="rounded-2xl border border-[#A7F3D0] bg-white p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-[#EFECE4] pb-3">
          <div>
            <h2 className="font-editorial text-xl font-bold text-[#141413]">
              Aides, Études Gratuites, Santé &amp; Droits Retraite Inclus à 100 %
            </h2>
            <p className="text-xs text-[#57534E]">
              Tout ce que votre foyer reçoit en face des impôts payés : allocations en argent + valeur réelle des services et droits sociaux acquis.
            </p>
          </div>
          <span className="font-mono-num text-xl font-extrabold text-[#047857]">
            {formatEuros(result.aides.totalAidesEtServicesComplet, true)} / an
          </span>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {/* Colonne 1 : Aides monétaires directes */}
          <div className="rounded-xl border border-[#E4DFD5] bg-[#FAF8F4] p-4 space-y-2.5">
            <div className="flex items-baseline justify-between border-b border-[#E4DFD5] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#065F46]">
                1. Aides monétaires directes (versées)
              </h3>
              <span className="font-mono-num text-sm font-extrabold text-[#047857]">
                {formatEuros(result.aides.totalAidesMonetaires, true)}
              </span>
            </div>

            {result.aides.items.length > 0 ? (
              <div className="divide-y divide-[#EFECE4]">
                {result.aides.items.map((a) => (
                  <div key={a.id} className="py-2 flex items-start justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-[#141413]">{a.label}</div>
                      <div className="text-[#57534E] mt-0.5">{a.explanation}</div>
                      <div className="text-[10.5px] text-[#78716C] mt-0.5">{a.organisme}</div>
                    </div>
                    <span className="font-mono-num font-bold text-[#047857] shrink-0">
                      {formatEuros(a.amount, true)}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#78716C]">
                Revenus supérieurs aux plafonds des aides en espèces (RSA, ASPA, Prime d’activité, APL, PAJE, CMG, CROUS).
              </p>
            )}
          </div>

          {/* Colonne 2 : Prestations en nature, Tarifs sociaux & Droits acquis */}
          <div className="rounded-xl border border-[#BFDBFE] bg-[#EFF6FF]/50 p-4 space-y-2.5">
            <div className="flex items-baseline justify-between border-b border-[#BFDBFE] pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#1E3A8A]">
                2. Études, Santé, Tarifs sociaux, Retraite &amp; CPF (100 %)
              </h3>
              <span className="font-mono-num text-sm font-extrabold text-[#1E3A8A]">
                {formatEuros(result.aides.totalPrestationsEnNatureEtDroits, true)}
              </span>
            </div>

            <div className="divide-y divide-[#DBEAFE]">
              {result.aides.itemsEnNatureEtDroits.map((a) => (
                <div key={a.id} className="py-2 flex items-start justify-between gap-3 text-xs">
                  <div>
                    <div className="font-bold text-[#141413]">{a.label}</div>
                    <div className="text-[#44403C] mt-0.5">{a.explanation}</div>
                    <div className="text-[10.5px] text-[#78716C] mt-0.5">{a.organisme}</div>
                  </div>
                  <span className="font-mono-num font-bold text-[#1E3A8A] shrink-0">
                    {formatEuros(a.amount, true)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Registre exhaustif · Loi de Finances & LFSS 2026 */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 no-print">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
              Registre Exhaustif · Loi de Finances &amp; LFSS 2026
            </div>
            <h2 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
              Les {result.totalCatalogCount} Impôts, Cotisations &amp; Taxes Passés au Crible
            </h2>
            <p className="text-xs text-[#57534E]">
              {result.activeTaxCount} taxes actives sur ce profil · Total prélevé :{' '}
              <strong className="font-mono-num text-[#141413]">
                {formatEuros(result.totalPrelevements)}
              </strong>{' '}
              ({formatPct(result.tauxPrelevementReelPct)})
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#D6D0C4] bg-white px-3 py-1.5 text-xs font-semibold text-[#141413] hover:bg-[#FAF8F4] cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#141413] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#292524] cursor-pointer"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Imprimer l’Addition</span>
            </button>
          </div>
        </div>

        {/* Filtres et recherche */}
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between no-print">
          <div className="relative flex-1 max-w-md">
            <Search className="h-4 w-4 text-[#A8A29E] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un impôt (TVA, holding, CSG, douane, crypto, malus…)"
              className="w-full rounded-lg border border-[#D6D0C4] bg-white pl-9 pr-3 py-1.5 text-xs text-[#141413] focus:border-[#1E3A8A] focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'all', label: `Toutes (${result.items.length})` },
                { id: 'active', label: `Actives (${result.activeTaxCount})` },
                { id: 'perso', label: 'Foyer perso' },
                { id: 'societe', label: 'Société & Holding' },
                { id: 'en_attente', label: 'Holding / En attente' },
              ] as { id: FilterMode; label: string }[]
            ).map((btn) => (
              <button
                key={btn.id}
                type="button"
                onClick={() => setFilterMode(btn.id)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold cursor-pointer ${
                  filterMode === btn.id
                    ? 'bg-[#141413] text-white'
                    : 'bg-[#F2EFE8] text-[#44403C] hover:bg-[#E5E0D5]'
                }`}
              >
                {btn.label}
              </button>
            ))}

            <select
              aria-label="Filtrer par famille fiscale"
              value={familyFilter}
              onChange={(e) => setFamilyFilter(e.target.value as TaxFamilyId | 'all')}
              className="rounded-lg border border-[#D6D0C4] bg-white px-2.5 py-1 text-xs text-[#141413]"
            >
              <option value="all">Toutes les familles</option>
              {(Object.keys(TAX_FAMILIES) as TaxFamilyId[]).map((fid) => (
                <option key={fid} value={fid}>
                  {TAX_FAMILIES[fid].shortLabel}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Tableau du ticket de caisse */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#E4DFD5] text-[11px] uppercase tracking-wider text-[#78716C]">
                <th className="py-2 pr-3 font-semibold">Prélèvement &amp; explication simple</th>
                <th className="py-2 px-2 font-semibold hidden sm:table-cell">Catégorie / Qui paie</th>
                <th className="py-2 px-2 font-semibold hidden lg:table-cell">Barème 2026</th>
                <th className="py-2 pl-3 text-right font-semibold">Montant/an</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFECE4]">
              {filteredItems.map((it) => {
                const fam = TAX_FAMILIES[it.entry.family];
                const isCorp =
                  it.entry.incidence === 'entreprise_societe' ||
                  it.entry.incidence === 'holding_en_attente';
                const isExcluded = isCorp && !state.inclureTaxesSocieteEtHolding;

                return (
                  <tr
                    key={it.entry.id}
                    className={`hover:bg-[#FAF8F4] ${isExcluded ? 'opacity-65' : ''}`}
                  >
                    <td className="py-2.5 pr-3 align-top">
                      <div className="font-semibold text-[#141413]">
                        {it.entry.name}
                        {it.entry.isMemoOnly && (
                          <span className="ml-2 text-[10px] font-semibold text-[#78716C]">
                            (Mémo · déjà compté)
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#57534E] mt-0.5">
                        {beginnerMode ? it.entry.simpleSummary : it.entry.description}
                      </div>
                      <div className="text-[10px] text-[#78716C] mt-0.5">
                        {it.formulaNote} · {it.entry.legalRef}
                      </div>
                    </td>
                    <td className="py-2.5 px-2 align-top hidden sm:table-cell whitespace-nowrap">
                      <div className="font-medium text-[#44403C]">{fam.shortLabel}</div>
                      <div className="text-[10px] text-[#78716C]">
                        {it.entry.incidence === 'personnel'
                          ? 'Foyer personnel'
                          : it.entry.incidence === 'holding_en_attente'
                            ? 'Holding (bloqué)'
                            : 'Payé par société'}
                      </div>
                    </td>
                    <td className="py-2.5 px-2 align-top hidden lg:table-cell text-[11px] text-[#57534E] max-w-[220px]">
                      {it.entry.rate2026}
                    </td>
                    <td className="py-2.5 pl-3 align-top text-right font-mono-num font-bold whitespace-nowrap">
                      {it.entry.isMemoOnly ? (
                        <span className="text-[#A8A29E]">Mémo</span>
                      ) : (
                        <span
                          className={
                            it.amount < 0
                              ? 'text-[#15803D]'
                              : it.amount > 0
                                ? isExcluded
                                  ? 'text-[#B45309]'
                                  : 'text-[#141413]'
                                : 'text-[#CBC4B6]'
                          }
                        >
                          {formatEuros(it.amount)}
                          {isExcluded && it.amount > 0 && (
                            <span className="block text-[9px] font-normal text-[#B45309]">
                              (hors total perso)
                            </span>
                          )}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
