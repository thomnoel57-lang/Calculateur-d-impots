import React, { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { PILLARS } from '../data/taxCatalog';
import { ExpertOverrides, PillarId, SimulationResult, SimulationState } from '../types/fiscal';
import { formatEuros } from '../utils/formatters';

interface ExpertAuditProps {
  state: SimulationState;
  result: SimulationResult;
  onChange: (updater: (prev: SimulationState) => SimulationState) => void;
}

interface FieldSpec {
  key: keyof ExpertOverrides;
  label: string;
  unit: string;
  step?: number;
  max?: number;
}

const PILLAR_FIELDS: Record<PillarId, FieldSpec[]> = {
  travail: [
    { key: 'tauxVersementMobilitePct', label: 'Taux Versement Mobilité local (%)', unit: '%', step: 0.1, max: 3.5 },
    { key: 'gardeEnfantsFraisAnnuels', label: 'Frais garde d’enfants < 6 ans (base CMG/crédit)', unit: '€', step: 250 },
  ],
  conso_tva: [
    { key: 'depensesTva20', label: 'Dépenses soumises à TVA 20 % (TTC/an)', unit: '€', step: 500 },
    { key: 'depensesTva10', label: 'Restauration, hôtels, travaux TVA 10 % (TTC/an)', unit: '€', step: 250 },
    { key: 'depensesTva55', label: 'Alimentation, livres TVA 5,5 % (TTC/an)', unit: '€', step: 250 },
    { key: 'depensesTva21', label: 'Médicaments remboursés & presse TVA 2,1 %', unit: '€', step: 50 },
    { key: 'achatsHorsUeDouane', label: 'Achats/colis hors Union Européenne (droits de douane)', unit: '€', step: 100 },
    { key: 'achatsHighTechNeufs', label: 'Achats smartphones/PC neufs (Copie privée)', unit: '€', step: 100 },
    { key: 'abonnementsTelecomStreaming', label: 'Abonnements fibre/mobile & streaming SVOD', unit: '€', step: 50 },
    { key: 'achatsEquipementMaison', label: 'Équipement maison/meubles (Éco-contributions REP)', unit: '€', step: 100 },
  ],
  energie_eau: [
    { key: 'consoElectriciteKwh', label: 'Consommation électricité (kWh/an)', unit: 'kWh', step: 250 },
    { key: 'consoGazKwh', label: 'Consommation gaz naturel (kWh/an)', unit: 'kWh', step: 500 },
    { key: 'consoFioulLitres', label: 'Fioul domestique (litres/an)', unit: 'L', step: 100 },
    { key: 'consoEauM3', label: 'Consommation eau potable (m³/an)', unit: 'm³', step: 5 },
    { key: 'teomAnnuelle', label: 'Taxe ordures ménagères (TEOM/REOM)', unit: '€', step: 20 },
    { key: 'taxeBalayageAnnuelle', label: 'Taxe de balayage communale', unit: '€', step: 10 },
  ],
  auto_transports: [
    { key: 'consoCarburantLitres100', label: 'Consommation véhicule (L/100 km)', unit: 'L/100', step: 0.2 },
    { key: 'prixCarburantTtcLitre', label: 'Prix carburant à la pompe (€/L)', unit: '€', step: 0.05 },
    { key: 'peagesAutorouteAnnuelsTtc', label: 'Péages autoroutiers (TTC/an)', unit: '€', step: 50 },
    { key: 'transportsCommunTrainTtc', label: 'Transports en commun & trains SNCF (TTC/an)', unit: '€', step: 50 },
    { key: 'volsEuropeEcoNb', label: 'Vols Europe / France par an (nb)', unit: 'vols', step: 1 },
    { key: 'volsLongCourrierEcoNb', label: 'Vols long-courriers éco par an (nb)', unit: 'vols', step: 1 },
    { key: 'traverseesMaritimesNb', label: 'Traversées maritimes / ferry par an (nb)', unit: 'trav.', step: 1 },
    { key: 'nuiteesHotelLocationFrance', label: 'Nuitées hôtel / Airbnb en France', unit: 'nuits', step: 1 },
    { key: 'timbresFiscauxAmendesAnnuels', label: 'Timbres fiscaux & amendes/FPS (€/an)', unit: '€', step: 20 },
  ],
  habitudes_assurances: [
    { key: 'consoVinLitresAn', label: 'Consommation vin (litres/an)', unit: 'L', step: 5 },
    { key: 'consoBiereLitresAn', label: 'Consommation bière (litres/an)', unit: 'L', step: 5 },
    { key: 'consoSpiritueuxLitresAn', label: 'Spiritueux > 18° (litres/an)', unit: 'L', step: 0.5 },
    { key: 'consoSodasSucresLitresAn', label: 'Sodas sucrés (litres/an)', unit: 'L', step: 5 },
    { key: 'primeAssuranceAutoTtc', label: 'Assurance Auto annuelle (TTC)', unit: '€', step: 50 },
    { key: 'primeAssuranceHabitationTtc', label: 'Assurance Habitation annuelle (TTC)', unit: '€', step: 30 },
    { key: 'primeMutuelleSanteTtc', label: 'Mutuelle Santé annuelle (TTC)', unit: '€', step: 50 },
    { key: 'misesJeuxLoterieParisAn', label: 'Mises Loto / FDJ / Paris sportifs (€/an)', unit: '€', step: 50 },
    { key: 'depensesSpectaclesCinemaTtc', label: 'Places cinéma / concerts / spectacles (€/an)', unit: '€', step: 25 },
  ],
  immobilier: [
    { key: 'taxeFonciereAnnuelle', label: 'Taxe foncière annuelle', unit: '€', step: 50 },
    { key: 'taxeHabitationSecondaire', label: 'Taxe d’habitation résidence secondaire', unit: '€', step: 100 },
    { key: 'patrimoineImmoNetIfi', label: 'Patrimoine immobilier net taxable IFI (> 1,3 M€)', unit: '€', step: 50000 },
    { key: 'loyersNetsFonciersAnnuels', label: 'Loyers perçus (revenus fonciers/LMNP)', unit: '€', step: 1000 },
    { key: 'achatImmobilierPrixAncien', label: 'Achat immobilier ancien (DMTO notaire)', unit: '€', step: 10000 },
    { key: 'achatImmobilierPrixNeuf', label: 'Achat immobilier neuf VEFA (TVA 20 %)', unit: '€', step: 10000 },
    { key: 'surfaceConstructionAmenagementM2', label: 'Construction / extension / piscine (m²)', unit: 'm²', step: 5 },
  ],
  capital_transmission: [
    { key: 'dividendesBrutsAnnuels', label: 'Dividendes bruts totaux (€/an)', unit: '€', step: 2000 },
    { key: 'interetsBrutsFiscalisesAnnuels', label: 'Intérêts bancaires fiscalisés (hors Livret A)', unit: '€', step: 200 },
    { key: 'plusValuesMobilieresBrutes', label: 'Plus-values d’actions vendues (€/an)', unit: '€', step: 1000 },
    { key: 'plusValuesCryptoBrutes', label: 'Plus-values Crypto converties en €', unit: '€', step: 500 },
    { key: 'achatsActionsFrancaisesTtf', label: 'Ordres d’achat actions françaises (TTF 0,4 %)', unit: '€', step: 1000 },
    { key: 'actionsGratuitesBspceGains', label: 'Gains BSPCE / Actions gratuites vendus', unit: '€', step: 1000 },
    { key: 'montantSuccessionRecue', label: 'Succession reçue cette année (€)', unit: '€', step: 10000 },
    { key: 'exitTaxPlusValuesLatentes', label: 'Plus-values latentes soumises à Exit Tax', unit: '€', step: 10000 },
  ],
  entreprise: [
    { key: 'beneficeSocieteAvantIs', label: 'Bénéfice société avant IS (€/an)', unit: '€', step: 5000 },
    { key: 'partRemonteeHoldingPct', label: 'Part dividendes remontée en Holding (%)', unit: '%', step: 5, max: 100 },
    { key: 'dividendesSortisDeHoldingPourPoche', label: 'Dividendes extraits d’une holding vers poche', unit: '€', step: 5000 },
    { key: 'tresorerieAccumuleeHolding', label: 'Trésorerie placée en holding (base IS 25 %)', unit: '€', step: 25000 },
    { key: 'rendementTresorerieHoldingPct', label: 'Rendement annuel trésorerie holding (%)', unit: '%', step: 0.2, max: 15 },
    { key: 'actifsNonOperationnelsHolding', label: 'Actifs passifs holding (taxe 2 % si > 5 M€)', unit: '€', step: 250000 },
    { key: 'plusValuesEnReport150OBTer', label: 'Plus-values en report art. 150-0 B ter (mémo)', unit: '€', step: 100000 },
    { key: 'valorisationEntrepriseEstimee', label: 'Valorisation estimée des parts d’entreprise (€)', unit: '€', step: 50000 },
    { key: 'decoteLiquiditeCessionPct', label: 'Décote liquidité si vente massive (%)', unit: '%', step: 5, max: 60 },
    { key: 'cfeAnnuelle', label: 'CFE (Cotisation foncière des entreprises)', unit: '€', step: 100 },
    { key: 'chiffreAffairesEntreprise', label: 'Chiffre d’affaires de la société (CVAE/C3S/Surtaxe)', unit: '€', step: 50000 },
    { key: 'fraisChambreConsulaire', label: 'Taxe Chambres consulaires (CCI / CMA)', unit: '€', step: 25 },
    { key: 'tvsVehiculesSociete', label: 'Taxes véhicules de société (ex-TVS)', unit: '€', step: 100 },
    { key: 'montantRachatActionsSociete', label: 'Rachat/annulation d’actions (> 1 Md€ CA)', unit: '€', step: 50000 },
    { key: 'aidesPubliquesEntrepriseCirBpi', label: 'CIR / Subventions BPI reçus par la société (mémo)', unit: '€', step: 5000 },
  ],
};

export const ExpertAudit: React.FC<ExpertAuditProps> = ({
  state,
  result,
  onChange,
}) => {
  const [activePillar, setActivePillar] = useState<PillarId>('entreprise');

  const pillarItems = result.items.filter(
    (it) => it.entry.pillar === activePillar && !it.entry.isMemoOnly
  );
  const pillarTotal = pillarItems.reduce((s, it) => s + it.amount, 0);
  const fields = PILLAR_FIELDS[activePillar] ?? [];

  const handleFieldChange = (key: keyof ExpertOverrides, value: number) => {
    onChange((prev) => ({
      ...prev,
      overrides: {
        ...prev.overrides,
        [key]: Number.isFinite(value) ? Math.max(0, value) : 0,
      },
    }));
  };

  const handleResetField = (key: keyof ExpertOverrides) => {
    onChange((prev) => {
      const next = { ...prev.overrides };
      delete next[key];
      return { ...prev, overrides: next };
    });
  };

  return (
    <div className="space-y-4">
      <section className="rounded-xl border border-[#E4DFD5] bg-white p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="font-serif text-xl font-bold text-[#141413]">
              Audit Expert des 8 Piliers (INSEE + Saisie Libre)
            </h2>
            <p className="text-xs text-[#6B675E]">
              Chaque chiffre est pré-estimé automatiquement selon les moyennes INSEE pour votre profil. Saisissez vos vrais montants pour affiner à l’euro près.
            </p>
          </div>
          {result.overriddenKeys.size > 0 && (
            <button
              type="button"
              onClick={() => onChange((prev) => ({ ...prev, overrides: {} }))}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-3 py-1.5 text-xs font-semibold text-[#141413] hover:bg-[#F2EFE8] cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Revenir aux estimations INSEE ({result.overriddenKeys.size} modifs)</span>
            </button>
          )}
        </div>

        {/* Sélecteur des 8 piliers */}
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8">
          {PILLARS.map((p) => {
            const pSum = result.items
              .filter((it) => it.entry.pillar === p.id && !it.entry.isMemoOnly)
              .reduce((s, it) => s + it.amount, 0);
            const active = activePillar === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setActivePillar(p.id)}
                className={`rounded-lg border p-2.5 text-left transition-colors cursor-pointer ${
                  active
                    ? 'border-[#141413] bg-[#141413] text-white'
                    : 'border-[#E4DFD5] bg-[#FAF8F4] text-[#141413] hover:bg-[#F2EFE8]'
                }`}
              >
                <div className="text-[11px] font-bold leading-tight">{p.shortLabel}</div>
                <div
                  className={`mt-1 font-mono-num text-xs font-semibold ${
                    active ? 'text-[#E4DFD5]' : 'text-[#57534E]'
                  }`}
                >
                  {formatEuros(pSum)}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Détail du pilier sélectionné */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <section className="rounded-xl border border-[#E4DFD5] bg-white p-5 shadow-xs lg:col-span-6 space-y-3">
          <h3 className="font-serif text-base font-bold text-[#141413]">
            Paramètres éditables du pilier
          </h3>
          {fields.map((f) => {
            const val = result.effective[f.key];
            const isOverridden = result.overriddenKeys.has(f.key);
            return (
              <div
                key={f.key}
                className="flex flex-col gap-1 border-b border-[#EFECE5] pb-2.5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex-1 pr-2">
                  <label htmlFor={`audit-${f.key}`} className="text-xs font-semibold text-[#141413]">
                    {f.label}
                  </label>
                  <div className="text-[10px] text-[#7A756B]">
                    {isOverridden ? 'Valeur personnalisée' : 'Estimation auto INSEE'}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <input
                    id={`audit-${f.key}`}
                    type="number"
                    min={0}
                    max={f.max}
                    step={f.step ?? 1}
                    value={val}
                    onChange={(e) => handleFieldChange(f.key, Number(e.target.value))}
                    className={`w-32 rounded-md border px-2.5 py-1 text-right font-mono-num text-xs font-semibold ${
                      isOverridden
                        ? 'border-[#1E3A8A] bg-blue-50/40 text-[#1E3A8A]'
                        : 'border-[#D6D0C4] bg-[#FAF8F4] text-[#141413]'
                    }`}
                  />
                  <span className="text-xs text-[#6B675E] w-9">{f.unit}</span>
                  {isOverridden && (
                    <button
                      type="button"
                      onClick={() => handleResetField(f.key)}
                      title="Réinitialiser à l'estimation auto"
                      className="text-[#7A756B] hover:text-[#141413] cursor-pointer"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {activePillar === 'entreprise' && (
            <p className="text-[11px] text-amber-900 bg-amber-50/70 border border-amber-200 rounded-md px-3 py-2">
              {state.inclureTaxesSocieteEtHolding
                ? 'Audit 100 % activé : l’IS société, la CFE et la quote-part holding (1,25 %) sont comptabilisés dans votre charge fiscale totale.'
                : 'Mode foyer personnel seul actif : réactivez l’audit société 100 % dans la synthèse du Simulateur pour inclure IS, CFE et holding.'}
            </p>
          )}
        </section>

        <section className="rounded-xl border border-[#E4DFD5] bg-white p-5 shadow-xs lg:col-span-6 space-y-3">
          <div className="flex items-baseline justify-between border-b border-[#EFECE5] pb-2">
            <h3 className="font-serif text-base font-bold text-[#141413]">
              Taxes calculées sur ce pilier
            </h3>
            <span className="font-mono-num text-sm font-bold text-[#141413]">
              {formatEuros(pillarTotal)}
            </span>
          </div>

          <div className="divide-y divide-[#EFECE5]">
            {pillarItems.map((it) => (
              <div key={it.entry.id} className="py-2.5 flex items-start justify-between gap-3 text-xs">
                <div>
                  <div className="font-semibold text-[#141413]">{it.entry.name}</div>
                  <div className="text-[11px] text-[#57534E] mt-0.5">
                    {it.entry.simpleSummary}
                  </div>
                  <div className="text-[10px] text-[#7A756B] mt-0.5">
                    {it.formulaNote} · {it.entry.legalRef} ·{' '}
                    {it.entry.incidence === 'personnel'
                      ? 'Foyer perso'
                      : it.entry.incidence === 'holding_en_attente'
                        ? 'Holding (bloqué)'
                        : 'Payé par la société'}
                  </div>
                </div>
                <span
                  className={`font-mono-num font-bold shrink-0 ${
                    it.amount < 0
                      ? 'text-[#15803D]'
                      : it.amount > 0
                        ? 'text-[#141413]'
                        : 'text-[#9A948A]'
                  }`}
                >
                  {formatEuros(it.amount)}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
