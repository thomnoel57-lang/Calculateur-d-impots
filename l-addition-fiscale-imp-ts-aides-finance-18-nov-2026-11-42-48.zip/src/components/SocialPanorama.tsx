import React, { useMemo, useState } from 'react';
import { PRESET_PROFILES } from '../data/presets';
import { runSimulation } from '../engine/taxEngine';
import { PresetProfile, SimulationResult } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface SocialPanoramaProps {
  activePresetId: string;
  onSelectPreset: (preset: PresetProfile) => void;
}

type CompareMetric = 'taux_net_100' | 'taux_net_cash' | 'taux_brut' | 'montants' | 'structure';

export const SocialPanorama: React.FC<SocialPanoramaProps> = ({
  activePresetId,
  onSelectPreset,
}) => {
  const [metric, setMetric] = useState<CompareMetric>('taux_net_100');
  const [includeCorpInCompare, setIncludeCorpInCompare] = useState<boolean>(true);
  const [duelLeftId, setDuelLeftId] = useState<string>('etudiant_boursier');
  const [duelRightId, setDuelRightId] = useState<string>('ultra_riche_actionnaire');

  const allSimulations = useMemo(() => {
    return PRESET_PROFILES.map((preset) => {
      const sim = runSimulation({
        ...preset.state,
        inclureTaxesSocieteEtHolding: includeCorpInCompare,
      });
      return { preset, sim };
    });
  }, [includeCorpInCompare]);

  const duelLeft =
    allSimulations.find((x) => x.preset.id === duelLeftId) ?? allSimulations[0];
  const duelRight =
    allSimulations.find((x) => x.preset.id === duelRightId) ??
    allSimulations[allSimulations.length - 1];

  const renderMetricBar = (sim: SimulationResult) => {
    if (metric === 'taux_net_100' || metric === 'taux_net_cash') {
      const val =
        metric === 'taux_net_100'
          ? sim.tauxNetApresAidesPct
          : sim.tauxNetApresAidesMonetairesPct;
      const isNeg = val < 0;
      const widthPct = Math.min(100, Math.max(4, Math.abs(val) * 1.05));
      return (
        <div className="flex items-center gap-3 w-full">
          <div className="flex-1 h-4 rounded-md bg-[#F2EFE8] overflow-hidden flex items-center">
            <div
              className={`h-full rounded-md transition-all ${
                isNeg ? 'bg-[#15803D]' : 'bg-[#1E3A8A]'
              }`}
              style={{ width: `${widthPct}%` }}
            />
          </div>
          <span
            className={`font-mono-num text-xs font-extrabold w-20 text-right ${
              isNeg ? 'text-[#15803D]' : 'text-[#1E3A8A]'
            }`}
          >
            {formatPct(val, 1, true)}
          </span>
        </div>
      );
    }

    if (metric === 'taux_brut') {
      const widthPct = Math.min(100, Math.max(4, sim.tauxPrelevementReelPct * 1.3));
      return (
        <div className="flex items-center gap-3 w-full">
          <div className="flex-1 h-4 rounded-md bg-[#F2EFE8] overflow-hidden">
            <div
              className="h-full rounded-md bg-[#BE123C] transition-all"
              style={{ width: `${widthPct}%` }}
            />
          </div>
          <span className="font-mono-num text-xs font-extrabold text-[#BE123C] w-20 text-right">
            {formatPct(sim.tauxPrelevementReelPct)}
          </span>
        </div>
      );
    }

    if (metric === 'montants') {
      return (
        <div className="flex flex-wrap items-center justify-end gap-x-4 gap-y-1 text-xs font-mono-num">
          <span className="text-[#BE123C] font-semibold">
            Impôts : {formatEuros(sim.totalPrelevements)}
          </span>
          <span className="text-[#047857] font-semibold">
            Aides 100% : {formatEuros(sim.aides.totalAidesEtServicesComplet, true)}
          </span>
          <span className="text-[#141413] font-bold">
            Poche : {formatEuros(sim.resteNetApresAidesEtTaxes)}
          </span>
        </div>
      );
    }

    const tot = Math.max(1, sim.totalPrelevements);
    const visPct = (sim.impotsVisibles / tot) * 100;
    const cachePct = 100 - visPct;
    return (
      <div className="flex items-center gap-3 w-full">
        <div className="flex-1 h-4 rounded-md bg-[#F2EFE8] overflow-hidden flex">
          <div
            title={`Visibles : ${Math.round(visPct)}%`}
            className="bg-[#141413] h-full"
            style={{ width: `${visPct}%` }}
          />
          <div
            title={`Peu visibles/cachés : ${Math.round(cachePct)}%`}
            className="bg-[#D97706] h-full"
            style={{ width: `${cachePct}%` }}
          />
        </div>
        <span className="font-mono-num text-[11px] font-semibold text-[#44403C] w-28 text-right">
          {Math.round(visPct)}% vis. / {Math.round(cachePct)}% cach.
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EFECE4] pb-3">
          <div>
            <h2 className="font-editorial text-2xl font-bold text-[#141413]">
              Des Plus Modestes aux Ultra-Riches : Qui Paye Quoi ?
            </h2>
            <p className="text-xs text-[#57534E] mt-0.5">
              Comparez à 100 % impôts perso + société/holding et toutes les aides (cash + études gratuites + santé Sécu + droits retraite + services publics).
            </p>
          </div>

          <label className="inline-flex items-center gap-2 rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-3 py-1.5 text-xs font-semibold text-[#141413] cursor-pointer">
            <input
              type="checkbox"
              checked={includeCorpInCompare}
              onChange={(e) => setIncludeCorpInCompare(e.target.checked)}
              className="rounded border-[#CBC4B6] accent-[#1E3A8A]"
            />
            <span>Inclure à 100 % Société + Holding (IS, CFE, 1,25 % &amp; impôts en attente)</span>
          </label>
        </div>

        {/* Sélecteur de métrique */}
        <div className="flex flex-wrap gap-2">
          {(
            [
              { id: 'taux_net_100', label: 'Taux Net Intégral 100 %' },
              { id: 'taux_net_cash', label: 'Taux Net (cash seul)' },
              { id: 'taux_brut', label: 'Taux Brut avant aides (%)' },
              { id: 'montants', label: 'Montants (€/an)' },
              { id: 'structure', label: 'Visible vs Caché (%)' },
            ] as { id: CompareMetric; label: string }[]
          ).map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setMetric(m.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold cursor-pointer transition-colors ${
                metric === m.id
                  ? 'bg-[#141413] text-white'
                  : 'bg-[#F2EFE8] text-[#44403C] hover:bg-[#E5E0D5]'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {/* Liste comparative */}
        <div className="divide-y divide-[#EFECE4]">
          {allSimulations.map(({ preset, sim }) => {
            const isActive = preset.id === activePresetId;
            return (
              <div
                key={preset.id}
                className={`py-3 px-2.5 rounded-xl flex flex-col gap-2 md:flex-row md:items-center md:justify-between ${
                  isActive ? 'bg-[#EFF6FF]/60' : 'hover:bg-[#FAF8F4]'
                }`}
              >
                <div className="md:w-72 shrink-0 flex items-center justify-between md:block">
                  <div>
                    <button
                      type="button"
                      onClick={() => onSelectPreset(preset)}
                      className="text-left text-xs font-bold text-[#141413] hover:text-[#1E3A8A] underline-offset-2 hover:underline cursor-pointer"
                    >
                      {preset.name}
                    </button>
                    <div className="text-[11px] text-[#78716C]">
                      {preset.incomeTag} · {formatEuros(sim.aides.totalAidesEtServicesComplet, true)} aides &amp; droits
                    </div>
                  </div>
                </div>

                <div className="flex-1 max-w-2xl">{renderMetricBar(sim)}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Duel Face-à-Face */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs space-y-4">
        <div>
          <h3 className="font-editorial text-xl font-bold text-[#141413]">
            Duel Fiscal : Comparez Deux Profils Ligne par Ligne
          </h3>
          <p className="text-xs text-[#57534E]">
            Inclusion intégrale 100 % : impôts perso, impôts société/holding, réserves bloquées, aides cash, études/santé/droits retraite et reste réel en poche.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {[
            { side: 'left', current: duelLeft, setter: setDuelLeftId },
            { side: 'right', current: duelRight, setter: setDuelRightId },
          ].map(({ side, current, setter }) => {
            const reservesLocked = current.sim.holdingAndValuation.reservesNettesApresImpotsEnAttente;
            return (
              <div
                key={side}
                className="rounded-xl border border-[#E4DFD5] p-4 space-y-3 bg-[#FAF8F4]"
              >
                <select
                  aria-label={side === 'left' ? 'Profil comparé A' : 'Profil comparé B'}
                  value={current.preset.id}
                  onChange={(e) => setter(e.target.value)}
                  className="w-full rounded-lg border border-[#D6D0C4] bg-white px-3 py-2 text-xs font-bold text-[#141413]"
                >
                  {PRESET_PROFILES.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#57534E]">Richesse créée totale</span>
                    <span className="font-mono-num font-bold text-[#141413]">
                      {formatEuros(current.sim.richesseCreeeTotale)}
                    </span>
                  </div>
                  <div className="flex justify-between text-[#BE123C]">
                    <span>Impôts &amp; cotisations personnels</span>
                    <span className="font-mono-num font-bold">
                      {formatEuros(current.sim.impotsPersonnelsSeuls)}
                    </span>
                  </div>
                  <div className="flex justify-between text-[#B45309]">
                    <span>Impôts société / holding immédiats</span>
                    <span className="font-mono-num font-bold">
                      {formatEuros(current.sim.impotsEntrepriseImmediats)}
                    </span>
                  </div>
                  {current.sim.impotsEnAttenteHolding > 0 && (
                    <div className="flex justify-between text-[#6D28D9]">
                      <span>Impôts en attente (Holding &amp; Filiale)</span>
                      <span className="font-mono-num font-bold">
                        {formatEuros(current.sim.impotsEnAttenteHolding)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-[#047857]">
                    <span>Aides monétaires directes (CAF, CROUS…)</span>
                    <span className="font-mono-num font-bold">
                      {formatEuros(current.sim.aides.totalAidesMonetaires, true)}
                    </span>
                  </div>
                  <div className="flex justify-between text-[#1E3A8A]">
                    <span>Études gratuites, Santé, Retraite &amp; Services</span>
                    <span className="font-mono-num font-bold">
                      {formatEuros(current.sim.aides.totalPrestationsEnNatureEtDroits, true)}
                    </span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#E4DFD5] font-bold text-[#141413]">
                    <span>Taux brut / Taux net intégral 100 %</span>
                    <span className="font-mono-num">
                      {formatPct(current.sim.tauxPrelevementReelPct)} /{' '}
                      <span
                        className={
                          current.sim.tauxNetApresAidesPct < 0
                            ? 'text-[#15803D]'
                            : 'text-[#1E3A8A]'
                        }
                      >
                        {formatPct(current.sim.tauxNetApresAidesPct, 1, true)}
                      </span>
                    </span>
                  </div>
                  <div className="flex justify-between text-[#44403C]">
                    <span>Reste réel en poche (pouvoir d’achat + épargne)</span>
                    <span className="font-mono-num font-extrabold text-[#141413]">
                      {formatEuros(current.sim.resteNetApresAidesEtTaxes)}
                    </span>
                  </div>
                  {reservesLocked > 0 && (
                    <div className="flex justify-between text-[#7C3AED]">
                      <span>Réserves nettes bloquées (après impôts en attente)</span>
                      <span className="font-mono-num font-bold">
                        {formatEuros(reservesLocked)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
