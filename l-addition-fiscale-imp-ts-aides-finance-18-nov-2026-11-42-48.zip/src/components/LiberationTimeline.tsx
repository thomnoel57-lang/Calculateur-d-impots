import React, { useState } from 'react';
import { Calendar, EyeOff, Layers, Landmark } from 'lucide-react';
import { BENEFICIARIES } from '../data/taxCatalog';
import { BeneficiaryId, SimulationResult } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface LiberationTimelineProps {
  result: SimulationResult;
  beginnerMode: boolean;
}

const MONTHS_2026 = [
  { name: 'Jan', days: 31 },
  { name: 'Fév', days: 28 },
  { name: 'Mar', days: 31 },
  { name: 'Avr', days: 30 },
  { name: 'Mai', days: 31 },
  { name: 'Jun', days: 30 },
  { name: 'Jul', days: 31 },
  { name: 'Aoû', days: 31 },
  { name: 'Sep', days: 30 },
  { name: 'Oct', days: 31 },
  { name: 'Nov', days: 30 },
  { name: 'Déc', days: 31 },
];

type StructTab = 'familles' | 'beneficiaires' | 'iceberg';

export const LiberationTimeline: React.FC<LiberationTimelineProps> = ({
  result,
  beginnerMode,
}) => {
  const [structTab, setStructTab] = useState<StructTab>('familles');
  const [hoveredFam, setHoveredFam] = useState<string | null>(null);

  const freedomPct = Math.min(100, Math.max(0, (result.joursPourEtat / 365) * 100));
  const totalTax = Math.max(1, result.totalPrelevements);

  // Segments du ruban de 365 jours : chaque famille d'impôt en jours + jours pour vous
  const daySegments = [
    ...result.families
      .filter((f) => f.amount > 0)
      .map((f) => {
        const exactDays = (f.amount / totalTax) * result.joursPourEtat;
        return {
          id: f.id,
          label: f.shortLabel,
          color: f.color,
          exactDays,
          days: Math.round(exactDays),
          widthPct: (exactDays / 365) * 100,
        };
      }),
    {
      id: 'vous',
      label: 'Pour vous',
      color: '#15803D',
      exactDays: result.joursPourVous,
      days: result.joursPourVous,
      widthPct: (result.joursPourVous / 365) * 100,
    },
  ];

  // Mini-calendrier 12 mois
  let runningDay = 0;
  const calendarMonths = MONTHS_2026.map((m) => {
    const startDay = runningDay + 1;
    const endDay = runningDay + m.days;
    runningDay = endDay;
    const isAllTax = endDay <= result.joursPourEtat;
    const isAllFree = startDay > result.joursPourEtat;
    const taxShareInMonth = isAllTax
      ? 100
      : isAllFree
        ? 0
        : ((result.joursPourEtat - startDay + 1) / m.days) * 100;
    return { ...m, startDay, endDay, isAllTax, isAllFree, taxShareInMonth };
  });

  // Donut SVG pour Schéma 5 (8 familles)
  const donutR = 74;
  const donutCirc = 2 * Math.PI * donutR;
  let donutOffset = 0;

  const totalBenef = Math.max(
    1,
    Object.values(result.parBeneficiaire).reduce((s, v) => s + v, 0)
  );

  const visTotal = Math.max(
    1,
    result.impotsVisibles + result.impotsSemiVisibles + result.impotsCaches
  );

  return (
    <div className="space-y-5">
      {/* SCHÉMA 4 · Votre année de 365 jours découpée par impôt */}
      <section className="bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
              Schéma 4 · Votre année de 365 jours découpée par impôt
            </div>
            <h2 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
              Votre Jour de Libération Fiscale :{' '}
              <span className="text-[#BE123C] underline decoration-[#FECDD3] decoration-4 underline-offset-4">
                {result.jourLiberationDate}
              </span>
            </h2>
          </div>

          <div className="flex items-center gap-2.5 text-xs font-mono-num">
            <div className="px-3 py-1.5 rounded-xl bg-[#FFF1F2] border border-[#FECDD3] text-[#9F1239]">
              <strong>{result.joursPourEtat} j</strong> pour l’État
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-[#ECFDF5] border border-[#A7F3D0] text-[#065F46]">
              <strong>{result.joursPourVous} j</strong> pour vous
            </div>
          </div>
        </div>

        {/* Ruban 365 jours + drapeau Jour de Libération */}
        <div className="relative pt-8 pb-2">
          <div
            className="absolute top-0 -translate-x-1/2 flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-[#141413] text-white text-[10.5px] font-bold whitespace-nowrap shadow-sm transition-all duration-300 z-10"
            style={{ left: `${Math.min(91, Math.max(9, freedomPct))}%` }}
          >
            <Calendar className="w-3 h-3 text-[#4ADE80]" />
            <span>{result.jourLiberationDate}</span>
          </div>

          <div className="h-9 w-full rounded-xl overflow-hidden flex border border-[#E4DFD5] shadow-inner">
            {daySegments.map((seg) =>
              seg.widthPct > 0.3 ? (
                <div
                  key={seg.id}
                  style={{ width: `${seg.widthPct}%`, backgroundColor: seg.color }}
                  className="h-full border-r border-white/40 flex items-center justify-center overflow-hidden transition-all duration-300"
                  title={`${seg.label} : ${seg.days} jours (${formatPct((seg.exactDays / 365) * 100)})`}
                >
                  {seg.widthPct >= 7 && (
                    <span className="text-[10px] font-mono-num font-bold text-white whitespace-nowrap px-1">
                      {seg.days}j
                    </span>
                  )}
                </div>
              ) : null
            )}
          </div>
        </div>

        {/* Mini-calendrier des 12 mois */}
        <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5 mt-3">
          {calendarMonths.map((m) => (
            <div
              key={m.name}
              className="rounded-lg border border-[#E4DFD5] bg-[#FAF8F4] p-1.5 text-center"
              title={`${m.name} : ${Math.round(m.taxShareInMonth)} % travaillé pour financer le budget public`}
            >
              <div className="text-[10px] font-bold text-[#44403C]">{m.name}</div>
              <div className="mt-1 h-2 w-full rounded-sm bg-[#DCFCE7] overflow-hidden">
                <div
                  className="h-full bg-[#BE123C]"
                  style={{ width: `${m.taxShareInMonth}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {beginnerMode && (
          <p className="mt-3 text-xs text-[#57534E]">
            Note 100 % tout inclus : en tenant compte de toutes vos aides, études gratuites, santé Sécu et droits retraite acquis ({formatEuros(result.aides.totalAidesEtServicesComplet)}), votre contribution nette équivaut à{' '}
            <strong className="font-mono-num text-[#141413]">
              {result.tauxNetApresAidesPct <= 0
                ? '0 jour net (vous recevez plus que vous ne cotisez)'
                : `${Math.round((result.tauxNetApresAidesPct / 100) * 365)} jours nets sur 365`}
            </strong>
            .
          </p>
        )}
      </section>

      {/* SCHÉMA 5 · Décryptage structurel (8 Familles / Qui encaisse ? / L'Iceberg caché) */}
      <section className="bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
              Schéma 5 · Décryptage structurel
            </div>
            <h2 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
              Où Vont Vos {formatEuros(result.totalPrelevements)} de Prélèvements ?
            </h2>
          </div>

          <div className="inline-flex rounded-xl bg-[#F2EFE8] p-1 gap-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setStructTab('familles')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer ${
                structTab === 'familles'
                  ? 'bg-white text-[#141413] shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>8 Familles</span>
            </button>
            <button
              type="button"
              onClick={() => setStructTab('beneficiaires')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer ${
                structTab === 'beneficiaires'
                  ? 'bg-white text-[#141413] shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              <Landmark className="w-3.5 h-3.5" />
              <span>Qui encaisse ?</span>
            </button>
            <button
              type="button"
              onClick={() => setStructTab('iceberg')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer ${
                structTab === 'iceberg'
                  ? 'bg-white text-[#141413] shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>L’Iceberg caché</span>
            </button>
          </div>
        </div>

        {/* Onglet 1 : Donut SVG + 8 Familles */}
        {structTab === 'familles' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-4 flex flex-col items-center">
              <svg viewBox="0 0 210 210" className="w-52 h-52">
                <circle
                  cx={105}
                  cy={105}
                  r={donutR}
                  fill="none"
                  stroke="#F2EFE8"
                  strokeWidth={26}
                />
                {result.families
                  .filter((f) => f.amount > 0)
                  .map((fam) => {
                    const segLen = (fam.amount / totalTax) * donutCirc;
                    const offset = donutOffset;
                    donutOffset += segLen;
                    const isActive = hoveredFam === fam.id;
                    return (
                      <circle
                        key={fam.id}
                        cx={105}
                        cy={105}
                        r={donutR}
                        fill="none"
                        stroke={fam.color}
                        strokeWidth={isActive ? 31 : 25}
                        strokeDasharray={`${Math.max(0, segLen - 1.5)} ${donutCirc}`}
                        strokeDashoffset={-offset}
                        transform="rotate(-90 105 105)"
                        className="transition-all duration-200 cursor-pointer"
                        opacity={hoveredFam && !isActive ? 0.3 : 1}
                        onMouseEnter={() => setHoveredFam(fam.id)}
                        onMouseLeave={() => setHoveredFam(null)}
                      />
                    );
                  })}
                <text
                  x={105}
                  y={94}
                  textAnchor="middle"
                  className="fill-[#78716C] text-[10px] font-semibold uppercase"
                >
                  Total prélevé
                </text>
                <text
                  x={105}
                  y={114}
                  textAnchor="middle"
                  className="fill-[#141413] text-[15px] font-extrabold font-mono-num"
                >
                  {formatEuros(result.totalPrelevements, result.totalPrelevements >= 100000)}
                </text>
                <text
                  x={105}
                  y={131}
                  textAnchor="middle"
                  className="fill-[#BE123C] text-[11px] font-bold font-mono-num"
                >
                  {formatPct(result.tauxPrelevementReelPct)} du créé
                </text>
              </svg>
              <p className="text-[11px] text-[#78716C] text-center">
                Soit <strong className="font-mono-num text-[#141413]">{formatEuros(result.totalPrelevements / 12)}/mois</strong> ou{' '}
                <strong className="font-mono-num text-[#141413]">{formatEuros(result.totalPrelevements / 365)}/jour</strong>
              </p>
            </div>

            <div className="md:col-span-8 space-y-2">
              {result.families.map((fam) => {
                const topItems = fam.items
                  .filter((it) => !it.entry.isMemoOnly && it.amount >= 1)
                  .sort((a, b) => b.amount - a.amount)
                  .slice(0, 3);
                return (
                  <div
                    key={fam.id}
                    onMouseEnter={() => setHoveredFam(fam.id)}
                    onMouseLeave={() => setHoveredFam(null)}
                    className={`p-2.5 rounded-xl border transition ${
                      hoveredFam === fam.id
                        ? 'bg-[#FAF8F4] border-[#141413]/30 shadow-2xs'
                        : 'border-[#EFECE4] hover:bg-[#FAF8F4]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-[#141413] flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-xs shrink-0"
                          style={{ backgroundColor: fam.color }}
                        />
                        {fam.label}
                      </span>
                      <span className="font-mono-num font-extrabold text-[#141413]">
                        {formatEuros(fam.amount)}{' '}
                        <span className="text-[#78716C] font-semibold">
                          ({formatPct(fam.shareOfTotalTax)})
                        </span>
                      </span>
                    </div>
                    {topItems.length > 0 && (
                      <div className="text-[11px] text-[#78716C] mt-1 pl-5 truncate">
                        Dont :{' '}
                        {topItems
                          .map((it) => `${it.entry.shortName} (${formatEuros(it.amount)})`)
                          .join(' · ')}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Onglet 2 : Qui encaisse ? (4 caisses publiques) */}
        {structTab === 'beneficiaires' && (
          <div className="space-y-3">
            {(Object.keys(BENEFICIARIES) as BeneficiaryId[]).map((bid) => {
              const meta = BENEFICIARIES[bid];
              const amt = result.parBeneficiaire[bid] ?? 0;
              const share = (amt / totalBenef) * 100;
              return (
                <div key={bid} className="space-y-1.5">
                  <div className="flex items-baseline justify-between text-xs">
                    <div>
                      <span className="font-bold text-[#141413]">{meta.label}</span>
                      <span className="hidden sm:inline ml-2 text-[11px] text-[#78716C]">
                        {meta.detail}
                      </span>
                    </div>
                    <span className="font-mono-num font-extrabold text-[#141413] shrink-0 ml-2">
                      {formatEuros(amt)} ({formatPct(share)})
                    </span>
                  </div>
                  <div className="h-3.5 w-full rounded-lg bg-[#F2EFE8] overflow-hidden">
                    <div
                      className="h-full rounded-lg transition-all duration-300"
                      style={{ width: `${Math.max(2, share)}%`, backgroundColor: meta.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Onglet 3 : L'Iceberg caché */}
        {structTab === 'iceberg' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="rounded-xl border border-[#E4DFD5] bg-[#FAF8F4] p-4">
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#15803D]">
                  Surface visible ({formatPct((result.impotsVisibles / visTotal) * 100, 0)})
                </div>
                <div className="font-mono-num text-xl font-extrabold text-[#141413] mt-1">
                  {formatEuros(result.impotsVisibles)}
                </div>
                <p className="text-[11px] text-[#57534E] mt-1">
                  Ce que vous voyez passer sur votre avis d’impôt ou compte bancaire (IR, Taxe foncière, IFI, Cartes grises…).
                </p>
              </div>

              <div className="rounded-xl border border-[#FDE68A] bg-[#FFFBEB] p-4">
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#B45309]">
                  Semi-visibles ({formatPct((result.impotsSemiVisibles / visTotal) * 100, 0)})
                </div>
                <div className="font-mono-num text-xl font-extrabold text-[#141413] mt-1">
                  {formatEuros(result.impotsSemiVisibles)}
                </div>
                <p className="text-[11px] text-[#78350F] mt-1">
                  Prélevés à la source avant virement (cotisations salariales, CSG/CRDS, PFU bancaire, IS société).
                </p>
              </div>

              <div className="rounded-xl border border-[#FECDD3] bg-[#FFF1F2] p-4">
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#BE123C]">
                  100 % invisibles ({formatPct((result.impotsCaches / visTotal) * 100, 0)})
                </div>
                <div className="font-mono-num text-xl font-extrabold text-[#BE123C] mt-1">
                  {formatEuros(result.impotsCaches)}
                </div>
                <p className="text-[11px] text-[#9F1239] mt-1">
                  Patronales (maladie, famille, mobilité), TVA 20/10/5,5 % fondue dans les prix TTC, TICPE carburants, TSCA assurances, accises.
                </p>
              </div>
            </div>

            <div className="h-5 w-full rounded-xl overflow-hidden flex border border-[#E4DFD5]">
              <div
                style={{ width: `${(result.impotsVisibles / visTotal) * 100}%` }}
                className="bg-[#15803D] h-full"
                title={`Visibles : ${formatEuros(result.impotsVisibles)}`}
              />
              <div
                style={{ width: `${(result.impotsSemiVisibles / visTotal) * 100}%` }}
                className="bg-[#D97706] h-full border-l border-white"
                title={`Semi-visibles : ${formatEuros(result.impotsSemiVisibles)}`}
              />
              <div
                style={{ width: `${(result.impotsCaches / visTotal) * 100}%` }}
                className="bg-[#BE123C] h-full border-l border-white"
                title={`Cachés : ${formatEuros(result.impotsCaches)}`}
              />
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
