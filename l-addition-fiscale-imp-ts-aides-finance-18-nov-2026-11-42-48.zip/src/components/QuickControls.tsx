import React, { useState } from 'react';
import {
  SimulationResult,
  SimulationState,
  StatutLogement,
  StatutPrincipal,
  TypeVehicule,
  ZoneGeo,
} from '../types/fiscal';
import { formatEuros } from '../utils/formatters';

interface QuickControlsProps {
  state: SimulationState;
  result: SimulationResult;
  beginnerMode: boolean;
  onChange: (updater: (prev: SimulationState) => SimulationState) => void;
}

const STATUT_OPTIONS: { value: StatutPrincipal; label: string }[] = [
  { value: 'etudiant', label: 'Étudiant' },
  { value: 'apprenti', label: 'Apprenti / Alternant' },
  { value: 'rsa_inactif', label: 'RSA / Sans revenu d’activité' },
  { value: 'chomeur', label: 'Demandeur d’emploi (ARE)' },
  { value: 'salarie_non_cadre', label: 'Salarié (non-cadre)' },
  { value: 'salarie_cadre', label: 'Salarié cadre' },
  { value: 'fonctionnaire', label: 'Fonctionnaire' },
  { value: 'independant_tns', label: 'Indépendant / Artisan (TNS)' },
  { value: 'micro_entrepreneur', label: 'Micro-entrepreneur' },
  { value: 'dirigeant_sas', label: 'Dirigeant SAS / SASU' },
  { value: 'retraite', label: 'Retraité' },
  { value: 'rentier', label: 'Actionnaire / Rentier capital' },
];

export const QuickControls: React.FC<QuickControlsProps> = ({
  state,
  result,
  beginnerMode,
  onChange,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const isRetraite = state.statut === 'retraite';
  const isChomeur = state.statut === 'chomeur';
  const isRsa = state.statut === 'rsa_inactif';
  const isRentier = state.statut === 'rentier';
  const isCapitalOwner = state.statut === 'dirigeant_sas' || state.statut === 'rentier';

  const incomeLabel = isRetraite
    ? 'Pension retraite brute / an'
    : isChomeur
      ? 'Allocation chômage brute / an'
      : state.statut === 'micro_entrepreneur'
        ? 'Chiffre d’affaires annuel'
        : state.statut === 'independant_tns'
          ? 'Revenu pro brut (avant URSSAF)'
          : 'Salaire brut annuel';

  const incomeValue = isRetraite
    ? state.pensionRetraiteBruteAnnuelle
    : isChomeur
      ? state.allocationChomageBruteAnnuelle
      : state.salaireBrutAnnuel;

  const setIncomeValue = (v: number) => {
    onChange((prev) => {
      if (prev.statut === 'retraite') return { ...prev, pensionRetraiteBruteAnnuelle: v };
      if (prev.statut === 'chomeur') return { ...prev, allocationChomageBruteAnnuelle: v };
      return { ...prev, salaireBrutAnnuel: v };
    });
  };

  return (
    <aside className="rounded-xl border border-[#E4DFD5] bg-white p-4 shadow-xs space-y-4">
      <div className="flex items-center justify-between border-b border-[#E4DFD5] pb-3">
        <div>
          <h2 className="font-serif text-base font-bold text-[#141413]">
            2. Vos paramètres
          </h2>
          <p className="text-[11px] text-[#6B675E]">
            {beginnerMode ? 'Réglages simplifiés pour démarrer' : 'Paramètres détaillés du foyer'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowAdvanced((v) => !v)}
          className="text-xs font-semibold text-[#1E3A8A] hover:underline underline-offset-2 cursor-pointer whitespace-nowrap"
        >
          {showAdvanced ? 'Vue simple' : '+ d’options'}
        </button>
      </div>

      {/* Statut principal */}
      <div>
        <label htmlFor="statut-select" className="block text-xs font-semibold text-[#141413] mb-1">
          Situation professionnelle
        </label>
        <select
          id="statut-select"
          value={state.statut}
          onChange={(e) =>
            onChange((prev) => ({ ...prev, statut: e.target.value as StatutPrincipal }))
          }
          className="w-full rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2.5 py-2 text-xs font-medium text-[#141413] focus:border-[#141413] focus:outline-none"
        >
          {STATUT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Revenu principal (sauf RSA ou Rentier pur) */}
      {!isRsa && !isRentier && (
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <label htmlFor="income-slider" className="font-semibold text-[#141413]">
              {incomeLabel}
            </label>
            <span className="font-mono-num font-bold text-[#141413]">
              {formatEuros(incomeValue)}
            </span>
          </div>
          <input
            id="income-slider"
            type="range"
            min={0}
            max={state.statut === 'etudiant' ? 25000 : 180000}
            step={state.statut === 'etudiant' ? 500 : 1000}
            value={Math.min(incomeValue, state.statut === 'etudiant' ? 25000 : 180000)}
            onChange={(e) => setIncomeValue(Number(e.target.value))}
            className="w-full fiscal-slider"
          />
          <div className="flex justify-between text-[10px] text-[#7A756B] font-mono-num mt-0.5">
            <span>0 €</span>
            <span>{formatEuros(Math.round(incomeValue / 12))}/mois</span>
            <span>{state.statut === 'etudiant' ? '25 k€' : '180 k€'}</span>
          </div>
        </div>
      )}

      {/* Bourse CROUS si étudiant */}
      {state.statut === 'etudiant' && (
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <label htmlFor="crous-select" className="font-semibold text-[#141413]">
              Échelon Bourse CROUS
            </label>
            <span className="font-mono-num text-[#15803D] font-semibold">
              {state.echelonBourseCrous === 0
                ? 'Non boursier'
                : state.echelonBourseCrous === 1
                  ? 'Échelon 0 bis'
                  : `Échelon ${state.echelonBourseCrous - 1}`}
            </span>
          </div>
          <input
            id="crous-select"
            type="range"
            min={0}
            max={8}
            step={1}
            value={state.echelonBourseCrous}
            onChange={(e) =>
              onChange((prev) => ({ ...prev, echelonBourseCrous: Number(e.target.value) }))
            }
            className="w-full fiscal-slider"
          />
        </div>
      )}

      {/* Dividendes & Holding si dirigeant ou rentier */}
      {isCapitalOwner && (
        <div className="rounded-lg border border-amber-300 bg-amber-50/70 p-3 space-y-3">
          <div className="text-xs font-bold text-amber-950">
            Capital, Dividendes & Holding
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <label htmlFor="div-slider" className="font-medium text-[#141413]">
                Dividendes versés par la société
              </label>
              <span className="font-mono-num font-bold text-[#141413]">
                {formatEuros(result.effective.dividendesBrutsAnnuels)}
              </span>
            </div>
            <input
              id="div-slider"
              type="range"
              min={0}
              max={isRentier ? 3000000 : 300000}
              step={isRentier ? 50000 : 5000}
              value={Math.min(
                result.effective.dividendesBrutsAnnuels,
                isRentier ? 3000000 : 300000
              )}
              onChange={(e) =>
                onChange((prev) => ({
                  ...prev,
                  overrides: {
                    ...prev.overrides,
                    dividendesBrutsAnnuels: Number(e.target.value),
                  },
                }))
              }
              className="w-full fiscal-slider"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <label htmlFor="holding-pct-slider" className="font-medium text-[#141413]">
                Part remontée en Holding (en attente)
              </label>
              <span className="font-mono-num font-bold text-amber-900">
                {result.effective.partRemonteeHoldingPct} %
              </span>
            </div>
            <input
              id="holding-pct-slider"
              type="range"
              min={0}
              max={100}
              step={5}
              value={result.effective.partRemonteeHoldingPct}
              onChange={(e) =>
                onChange((prev) => ({
                  ...prev,
                  overrides: {
                    ...prev.overrides,
                    partRemonteeHoldingPct: Number(e.target.value),
                  },
                }))
              }
              className="w-full fiscal-slider"
            />
            <p className="mt-1 text-[11px] text-amber-950">
              {100 - result.effective.partRemonteeHoldingPct} % va en poche (PFU 31,4 % + CEHR/CDHR),{' '}
              {result.effective.partRemonteeHoldingPct} % reste en holding (1,25 % IS en attendant sortie).
            </p>
          </div>
        </div>
      )}

      {/* Foyer & Enfants */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="block text-xs font-semibold text-[#141413] mb-1">Foyer</label>
          <div className="grid grid-cols-2 rounded-lg border border-[#D6D0C4] p-0.5 bg-[#FAF8F4]">
            <button
              type="button"
              onClick={() =>
                onChange((prev) => ({
                  ...prev,
                  situationFamiliale: 'celibataire',
                  statutConjoint: 'aucun',
                }))
              }
              className={`rounded-md py-1 text-xs font-semibold cursor-pointer ${
                state.situationFamiliale === 'celibataire'
                  ? 'bg-[#141413] text-white shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              Seul(e)
            </button>
            <button
              type="button"
              onClick={() =>
                onChange((prev) => ({
                  ...prev,
                  situationFamiliale: 'couple',
                  statutConjoint:
                    prev.statutConjoint === 'aucun' ? 'salarie_non_cadre' : prev.statutConjoint,
                  salaireConjointBrutAnnuel:
                    prev.salaireConjointBrutAnnuel === 0 ? 28000 : prev.salaireConjointBrutAnnuel,
                }))
              }
              className={`rounded-md py-1 text-xs font-semibold cursor-pointer ${
                state.situationFamiliale === 'couple'
                  ? 'bg-[#141413] text-white shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              Couple
            </button>
          </div>
        </div>

        <div>
          <label htmlFor="enfants-input" className="block text-xs font-semibold text-[#141413] mb-1">
            Enfants ({result.nombrePartsFiscales} parts)
          </label>
          <div className="flex items-center justify-between rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2 py-1">
            <button
              type="button"
              aria-label="Retirer un enfant"
              onClick={() =>
                onChange((prev) => {
                  const nextKids = Math.max(0, prev.nbEnfants - 1);
                  return {
                    ...prev,
                    nbEnfants: nextKids,
                    nbEnfantsMoins3Ans: Math.min(prev.nbEnfantsMoins3Ans, nextKids),
                  };
                })
              }
              className="px-2 text-sm font-bold text-[#57534E] hover:text-[#141413] cursor-pointer"
            >
              −
            </button>
            <span id="enfants-input" className="font-mono-num text-xs font-bold text-[#141413]">
              {state.nbEnfants}
            </span>
            <button
              type="button"
              aria-label="Ajouter un enfant"
              onClick={() =>
                onChange((prev) => ({ ...prev, nbEnfants: Math.min(8, prev.nbEnfants + 1) }))
              }
              className="px-2 text-sm font-bold text-[#57534E] hover:text-[#141413] cursor-pointer"
            >
              +
            </button>
          </div>
        </div>
      </div>

      {/* Options rapides aides famille si enfants > 0 */}
      {state.nbEnfants > 0 && (
        <div className="rounded-lg border border-[#D1FAE5] bg-[#ECFDF5]/60 p-2.5 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-medium text-[#065F46]">
              Dont &lt; 3 ans (PAJE / Crèche / CMG)
            </span>
            <div className="flex items-center gap-2 rounded-md border border-[#A7F3D0] bg-white px-2 py-0.5">
              <button
                type="button"
                aria-label="Retirer un enfant de moins de 3 ans"
                onClick={() =>
                  onChange((prev) => ({
                    ...prev,
                    nbEnfantsMoins3Ans: Math.max(0, prev.nbEnfantsMoins3Ans - 1),
                  }))
                }
                className="font-bold text-[#065F46] cursor-pointer"
              >
                −
              </button>
              <span className="font-mono-num font-bold text-[#141413]">
                {state.nbEnfantsMoins3Ans}
              </span>
              <button
                type="button"
                aria-label="Ajouter un enfant de moins de 3 ans"
                onClick={() =>
                  onChange((prev) => ({
                    ...prev,
                    nbEnfantsMoins3Ans: Math.min(prev.nbEnfants, prev.nbEnfantsMoins3Ans + 1),
                  }))
                }
                className="font-bold text-[#065F46] cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          {state.situationFamiliale === 'celibataire' && (
            <label className="flex items-center gap-2 text-[#065F46] cursor-pointer">
              <input
                type="checkbox"
                checked={state.parentIsole}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, parentIsole: e.target.checked }))
                }
                className="rounded border-[#A7F3D0] accent-[#15803D]"
              />
              <span>Parent isolé (ASF CAF + ½ part fiscale)</span>
            </label>
          )}
        </div>
      )}

      {/* Revenu conjoint si couple */}
      {state.situationFamiliale === 'couple' && (
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <label htmlFor="conjoint-slider" className="font-semibold text-[#141413]">
              Revenu brut conjoint / an
            </label>
            <span className="font-mono-num font-bold text-[#141413]">
              {formatEuros(
                state.statutConjoint === 'retraite'
                  ? state.pensionConjointBruteAnnuelle
                  : state.salaireConjointBrutAnnuel
              )}
            </span>
          </div>
          <input
            id="conjoint-slider"
            type="range"
            min={0}
            max={120000}
            step={1000}
            value={
              state.statutConjoint === 'retraite'
                ? state.pensionConjointBruteAnnuelle
                : state.salaireConjointBrutAnnuel
            }
            onChange={(e) => {
              const val = Number(e.target.value);
              onChange((prev) =>
                prev.statutConjoint === 'retraite'
                  ? { ...prev, pensionConjointBruteAnnuelle: val }
                  : { ...prev, salaireConjointBrutAnnuel: val }
              );
            }}
            className="w-full fiscal-slider"
          />
        </div>
      )}

      {/* Logement & Zone */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label htmlFor="logement-select" className="block text-xs font-semibold text-[#141413] mb-1">
            Logement
          </label>
          <select
            id="logement-select"
            value={state.statutLogement}
            onChange={(e) =>
              onChange((prev) => ({ ...prev, statutLogement: e.target.value as StatutLogement }))
            }
            className="w-full rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2 py-1.5 text-xs text-[#141413]"
          >
            <option value="locataire">Locataire</option>
            <option value="proprietaire">Propriétaire</option>
            <option value="residence_crous">Résidence CROUS</option>
            <option value="heberge">Hébergé gratuit</option>
          </select>
        </div>

        <div>
          <label htmlFor="zone-select" className="block text-xs font-semibold text-[#141413] mb-1">
            Territoire
          </label>
          <select
            id="zone-select"
            value={state.zoneGeo}
            onChange={(e) =>
              onChange((prev) => ({ ...prev, zoneGeo: e.target.value as ZoneGeo }))
            }
            className="w-full rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2 py-1.5 text-xs text-[#141413]"
          >
            <option value="paris_idf">Paris / Île-de-France</option>
            <option value="grande_ville">Grande métropole</option>
            <option value="ville_moyenne">Ville moyenne</option>
            <option value="rural">Commune rurale</option>
          </select>
        </div>
      </div>

      {/* Voiture & Tabac */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label htmlFor="auto-select" className="block text-xs font-semibold text-[#141413] mb-1">
            Voiture
          </label>
          <select
            id="auto-select"
            value={state.typeVehicule}
            onChange={(e) => {
              const tv = e.target.value as TypeVehicule;
              onChange((prev) => ({
                ...prev,
                typeVehicule: tv,
                nbVehicules: tv === 'aucune' ? 0 : Math.max(1, prev.nbVehicules),
                kmAnnuels: tv === 'aucune' ? 0 : Math.max(8000, prev.kmAnnuels),
              }));
            }}
            className="w-full rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2 py-1.5 text-xs text-[#141413]"
          >
            <option value="aucune">Aucune voiture</option>
            <option value="essence">Essence</option>
            <option value="diesel">Diesel</option>
            <option value="hybride">Hybride</option>
            <option value="e85">Bioéthanol E85</option>
            <option value="electrique">100 % Électrique</option>
          </select>
        </div>

        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <label htmlFor="tabac-slider" className="font-semibold text-[#141413]">
              Tabac / sem.
            </label>
            <span className="font-mono-num text-[#141413] font-semibold">
              {state.fumeurPaquetsParSemaine} paq.
            </span>
          </div>
          <input
            id="tabac-slider"
            type="range"
            min={0}
            max={10}
            step={1}
            value={state.fumeurPaquetsParSemaine}
            onChange={(e) =>
              onChange((prev) => ({ ...prev, fumeurPaquetsParSemaine: Number(e.target.value) }))
            }
            className="w-full mt-1 fiscal-slider"
          />
        </div>
      </div>

      {/* Options avancées */}
      {showAdvanced && (
        <div className="space-y-3 border-t border-[#E4DFD5] pt-3">
          {state.typeVehicule !== 'aucune' && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <label htmlFor="km-slider" className="font-semibold text-[#141413]">
                  Kilomètres / an
                </label>
                <span className="font-mono-num font-bold text-[#141413]">
                  {state.kmAnnuels.toLocaleString('fr-FR')} km
                </span>
              </div>
              <input
                id="km-slider"
                type="range"
                min={0}
                max={40000}
                step={1000}
                value={state.kmAnnuels}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, kmAnnuels: Number(e.target.value) }))
                }
                className="w-full fiscal-slider"
              />
            </div>
          )}

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <label htmlFor="epargne-slider" className="font-semibold text-[#141413]">
                Taux d’épargne (non soumis à TVA)
              </label>
              <span className="font-mono-num font-bold text-[#141413]">{state.tauxEpargnePct} %</span>
            </div>
            <input
              id="epargne-slider"
              type="range"
              min={0}
              max={70}
              step={1}
              value={state.tauxEpargnePct}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, tauxEpargnePct: Number(e.target.value) }))
              }
              className="w-full fiscal-slider"
            />
          </div>

          {(state.statutLogement === 'locataire' || state.statutLogement === 'residence_crous') && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <label htmlFor="loyer-slider" className="font-semibold text-[#141413]">
                  Loyer mensuel hors charges
                </label>
                <span className="font-mono-num font-bold text-[#141413]">
                  {formatEuros(state.loyerMensuelHorsCharges)}
                </span>
              </div>
              <input
                id="loyer-slider"
                type="range"
                min={0}
                max={3000}
                step={25}
                value={state.loyerMensuelHorsCharges}
                onChange={(e) =>
                  onChange((prev) => ({
                    ...prev,
                    loyerMensuelHorsCharges: Number(e.target.value),
                  }))
                }
                className="w-full fiscal-slider"
              />
            </div>
          )}

          {state.statutLogement === 'locataire' && (
            <label className="flex items-center gap-2 text-xs text-[#44403C] cursor-pointer">
              <input
                type="checkbox"
                checked={state.logementSocialHlm}
                onChange={(e) =>
                  onChange((prev) => ({ ...prev, logementSocialHlm: e.target.checked }))
                }
                className="rounded border-[#D6D0C4] accent-[#15803D]"
              />
              <span>Logement social HLM (subvention loyer modéré)</span>
            </label>
          )}

          <label className="flex items-center gap-2 text-xs text-[#44403C] cursor-pointer">
            <input
              type="checkbox"
              checked={state.beneficiaireAah}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, beneficiaireAah: e.target.checked }))
              }
              className="rounded border-[#D6D0C4] accent-[#15803D]"
            />
            <span>Bénéficiaire AAH (handicap · déconjugalisée)</span>
          </label>

          {isCapitalOwner && (
            <label className="flex items-center gap-2 text-xs text-[#5B21B6] font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={state.inclureImpotsLatentsHolding}
                onChange={(e) =>
                  onChange((prev) => ({
                    ...prev,
                    inclureImpotsLatentsHolding: e.target.checked,
                  }))
                }
                className="rounded border-[#C4B5FD] accent-[#6D28D9]"
              />
              <span>Compter les impôts en attente (Holding &amp; Filiale)</span>
            </label>
          )}

          <label className="flex items-center gap-2 text-xs text-[#44403C] cursor-pointer">
            <input
              type="checkbox"
              checked={state.lisserTaxesPonctuelles}
              onChange={(e) =>
                onChange((prev) => ({ ...prev, lisserTaxesPonctuelles: e.target.checked }))
              }
              className="rounded border-[#D6D0C4] accent-[#1E3A8A]"
            />
            <span>Lisser les achats ponctuels (notaire, carte grise) sur 8 ans</span>
          </label>
        </div>
      )}
    </aside>
  );
};
