import React, { useState } from 'react';
import { SimulationResult, SimulationState } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface SankeyFlowChartProps {
  state: SimulationState;
  result: SimulationResult;
  beginnerMode: boolean;
}

interface SankeyNode {
  id: string;
  label: string;
  sub?: string;
  amount: number;
  color: string;
  yTop: number;
  yBot: number;
  h: number;
  labelY: number;
  isMobilisable?: boolean;
  isHoldingMuted?: boolean;
  isTax?: boolean;
}

interface SankeyRibbon {
  key: string;
  fromId: string;
  toId: string;
  stage: 1 | 2 | 3;
  y0Top: number;
  y0Bot: number;
  y1Top: number;
  y1Bot: number;
  color: string;
  isMobilisable?: boolean;
}

function buildRibbonPath(
  x0: number,
  y0Top: number,
  y0Bot: number,
  x1: number,
  y1Top: number,
  y1Bot: number
): string {
  const cx = (x0 + x1) / 2;
  return [
    `M ${x0} ${y0Top.toFixed(2)}`,
    `C ${cx} ${y0Top.toFixed(2)}, ${cx} ${y1Top.toFixed(2)}, ${x1} ${y1Top.toFixed(2)}`,
    `L ${x1} ${y1Bot.toFixed(2)}`,
    `C ${cx} ${y1Bot.toFixed(2)}, ${cx} ${y0Bot.toFixed(2)}, ${x0} ${y0Bot.toFixed(2)}`,
    'Z',
  ].join(' ');
}

function resolveLabelPositions(
  rawNodes: { yTop: number; h: number }[],
  heightsNeeded: number[],
  minTop: number,
  maxBot: number
): number[] {
  if (rawNodes.length === 0) return [];
  const ys = rawNodes.map((n) => n.yTop + n.h / 2);

  // Passe descendante : empêche tout chevauchement vers le bas
  for (let i = 0; i < ys.length; i++) {
    const halfH = heightsNeeded[i] / 2;
    if (i === 0) {
      ys[i] = Math.max(minTop + halfH, ys[i]);
    } else {
      const prevBottom = ys[i - 1] + heightsNeeded[i - 1] / 2 + 6;
      ys[i] = Math.max(ys[i], prevBottom + halfH);
    }
  }

  // Respect des bornes réelles (notamment pour les grandes barres/zones dont le cadre démarre à yTop)
  for (let i = 1; i < ys.length; i++) {
    if (rawNodes[i].h >= heightsNeeded[i]) {
      const blockTop = rawNodes[i].yTop;
      const prevBot = ys[i - 1] + heightsNeeded[i - 1] / 2 + 6;
      if (prevBot > blockTop) {
        const shift = prevBot - blockTop;
        for (let k = i - 1; k >= 0; k--) {
          ys[k] -= shift;
          if (k > 0) {
            const upperBot = ys[k - 1] + heightsNeeded[k - 1] / 2 + 6;
            if (upperBot <= ys[k] - heightsNeeded[k] / 2) break;
          }
        }
      }
    }
  }

  // Passe montante si le dernier élément dépasse maxBot
  const lastIdx = ys.length - 1;
  const maxLastCenter = maxBot - heightsNeeded[lastIdx] / 2;
  if (ys[lastIdx] > maxLastCenter) {
    ys[lastIdx] = maxLastCenter;
    for (let i = lastIdx - 1; i >= 0; i--) {
      const nextTop = ys[i + 1] - heightsNeeded[i + 1] / 2 - 6;
      ys[i] = Math.min(ys[i], nextTop - heightsNeeded[i] / 2);
    }
  }

  return ys;
}

function layoutColumnNodes(
  specs: Omit<SankeyNode, 'yTop' | 'yBot' | 'h' | 'labelY'>[],
  pxPerEuro: number,
  topPad: number,
  availH: number,
  gap: number,
  labelHeights: number[]
): SankeyNode[] {
  if (specs.length === 0) return [];
  const totalInkH = specs.reduce((s, n) => s + n.amount * pxPerEuro, 0);
  const totalGapH = gap * Math.max(0, specs.length - 1);
  const startY = topPad + Math.max(0, (availH - (totalInkH + totalGapH)) / 2);

  let curY = startY;
  const rawNodes = specs.map((sp) => {
    const h = sp.amount * pxPerEuro;
    const node = {
      ...sp,
      yTop: curY,
      yBot: curY + h,
      h,
      labelY: curY + h / 2,
    };
    curY += h + gap;
    return node;
  });

  const resolvedYs = resolveLabelPositions(
    rawNodes,
    labelHeights,
    topPad - 24,
    topPad + availH + 6
  );

  return rawNodes.map((n, idx) => ({
    ...n,
    labelY: resolvedYs[idx],
  }));
}

export const SankeyFlowChart: React.FC<SankeyFlowChartProps> = ({
  state,
  result,
  beginnerMode,
}) => {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [includeInKindInSankey, setIncludeInKindInSankey] = useState<boolean>(true);

  const inKindTotal = includeInKindInSankey
    ? result.aides.totalPrestationsEnNatureEtDroits
    : 0;

  // Ventilation exacte par étage ET par destinataire réel (Sécurité Sociale vs État & Collectivités)
  let s1Secu = 0;
  let s1EtatLoc = 0;
  let s2Secu = 0;
  let s2EtatLoc = 0;
  let s3Secu = 0;
  let s3EtatLoc = 0;

  for (const item of result.items) {
    if (item.entry.isMemoOnly || item.amount === 0) continue;
    const isCorpOrHolding =
      item.entry.incidence === 'entreprise_societe' ||
      item.entry.incidence === 'holding_en_attente';
    if (isCorpOrHolding && !state.inclureTaxesSocieteEtHolding) continue;
    if (item.entry.id === 'holding_impot_latent_sortie') continue;

    const isSecu = item.entry.beneficiary === 'secu';
    if (isCorpOrHolding || item.entry.family === 'patronales') {
      if (isSecu) s1Secu += item.amount;
      else s1EtatLoc += item.amount;
    } else if (
      item.entry.family === 'salariales_sociales' ||
      item.entry.family === 'revenu' ||
      item.entry.family === 'capital_entreprise'
    ) {
      if (isSecu) s2Secu += item.amount;
      else s2EtatLoc += item.amount;
    } else {
      if (isSecu) s3Secu += item.amount;
      else s3EtatLoc += item.amount;
    }
  }

  s1Secu = Math.max(0, s1Secu);
  s1EtatLoc = Math.max(0, s1EtatLoc);
  s2Secu = Math.max(0, s2Secu);
  s2EtatLoc = Math.max(0, s2EtatLoc);
  s3Secu = Math.max(0, s3Secu);
  s3EtatLoc = Math.max(0, s3EtatLoc);

  const taxesStage1 = s1Secu + s1EtatLoc;
  const taxesStage2 = s2Secu + s2EtatLoc;
  const taxesStage3 = s3Secu + s3EtatLoc;

  const totalSecu = s1Secu + s2Secu + s3Secu;
  const totalEtatLoc = s1EtatLoc + s2EtatLoc + s3EtatLoc;

  const impotsEnAttenteActifs =
    state.inclureTaxesSocieteEtHolding && state.inclureImpotsLatentsHolding
      ? result.impotsEnAttenteHolding
      : 0;
  const reservesBrutesSocieteEtHolding = state.inclureTaxesSocieteEtHolding
    ? result.holdingAndValuation.reserveRestantEnHolding +
      result.holdingAndValuation.beneficeRetenuEnFiliale
    : 0;
  const reservesNettesHolding = Math.max(
    0,
    reservesBrutesSocieteEtHolding - impotsEnAttenteActifs
  );

  const pochePure = Math.max(0, result.resteNetApresAidesEtTaxes);
  const financementExterne = Math.max(0, -result.resteNetApresAidesEtTaxes);

  const argentCompteBancaire = taxesStage3 + pochePure;
  const brutPersoAvecAides = taxesStage2 + argentCompteBancaire;

  // ======================== COLONNE 1 : SOURCE ========================
  const col1Specs = [
    ...(result.richesseCreeeTotale > 0
      ? [
          {
            id: 'c1_wealth',
            label: 'Richesse créée brute',
            sub: state.inclureTaxesSocieteEtHolding
              ? 'Travail + Capital + Société'
              : 'Travail + Capital perso',
            amount: result.richesseCreeeTotale,
            color: '#141413',
          },
        ]
      : []),
    ...(result.aides.totalAidesMonetaires > 0
      ? [
          {
            id: 'c1_aides',
            label: 'Aides en cash versées',
            sub: 'CAF, CROUS, APL, Prime…',
            amount: result.aides.totalAidesMonetaires,
            color: '#047857',
          },
        ]
      : []),
    ...(financementExterne > 0
      ? [
          {
            id: 'c1_epargne',
            label: 'Puisé sur épargne / crédit',
            sub: 'Dépenses > revenu annuel',
            amount: financementExterne,
            color: '#78716C',
          },
        ]
      : []),
    ...(inKindTotal > 0
      ? [
          {
            id: 'c1_inkind',
            label: 'Études, Santé & Droits',
            sub: 'Prestations en nature 100 %',
            amount: inKindTotal,
            color: '#1E3A8A',
          },
        ]
      : []),
  ];

  const totalFlow = Math.max(
    1,
    col1Specs.reduce((s, n) => s + n.amount, 0)
  );

  // ======================== COLONNE 2 : ÉTAGE 1 (ENTREPRISE & HOLDING) ========================
  const col2Specs = [
    ...(taxesStage1 > 0
      ? [
          {
            id: 'c2_emp_soc',
            label: state.inclureTaxesSocieteEtHolding
              ? 'Employeur, IS & Holding'
              : 'Charges employeur',
            sub: 'Étage 1 : retenu avant brut',
            amount: taxesStage1,
            color: '#D97706',
            isTax: true,
          },
        ]
      : []),
    ...(brutPersoAvecAides > 0
      ? [
          {
            id: 'c2_brut_perso',
            label: 'Revenu brut (+ aides)',
            sub: 'Brut paie / capital + aides cash',
            amount: brutPersoAvecAides,
            color: '#334155',
          },
        ]
      : []),
    ...(reservesBrutesSocieteEtHolding > 0
      ? [
          {
            id: 'c2_holding',
            label: 'Bloqué Société / Holding',
            sub: 'Valeur restée hors poche',
            amount: reservesBrutesSocieteEtHolding,
            color: '#7C3AED',
          },
        ]
      : []),
    ...(inKindTotal > 0
      ? [
          {
            id: 'c2_inkind',
            label: 'En nature & droits',
            sub: 'École, Sécu, Retraite',
            amount: inKindTotal,
            color: '#1E3A8A',
          },
        ]
      : []),
  ];

  // ======================== COLONNE 3 : ÉTAGE 2 (PAIE, IR & COMPTE) ========================
  const col3Specs = [
    ...(taxesStage1 > 0
      ? [
          {
            id: 'c3_emp_soc',
            label: state.inclureTaxesSocieteEtHolding
              ? 'Employeur, IS & Holding'
              : 'Charges employeur',
            sub: 'Déjà prélevé en amont (Étage 1)',
            amount: taxesStage1,
            color: '#D97706',
            isTax: true,
          },
        ]
      : []),
    ...(taxesStage2 > 0
      ? [
          {
            id: 'c3_sal_ir',
            label: 'Fiche de paie, IR & PFU',
            sub: 'Étage 2 : retenu avant compte',
            amount: taxesStage2,
            color: '#BE123C',
            isTax: true,
          },
        ]
      : []),
    ...(argentCompteBancaire > 0
      ? [
          {
            id: 'c3_compte',
            label: 'Arrivé sur votre compte',
            sub: 'Cash reçu avant TVA & foncier',
            amount: argentCompteBancaire,
            color: '#0F766E',
          },
        ]
      : []),
    ...(impotsEnAttenteActifs > 0
      ? [
          {
            id: 'c3_latent',
            label: 'Impôts en attente',
            sub: 'PFU + CEHR + CDHR si sortie',
            amount: impotsEnAttenteActifs,
            color: '#9333EA',
            isTax: true,
          },
        ]
      : []),
    ...(reservesNettesHolding > 0
      ? [
          {
            id: 'c3_holding_net',
            label: 'Réserves Société / Holding',
            sub: 'Net bloqué hors poche',
            amount: reservesNettesHolding,
            color: '#94A3B8',
            isHoldingMuted: true,
          },
        ]
      : []),
    ...(inKindTotal > 0
      ? [
          {
            id: 'c3_inkind',
            label: 'En nature & droits',
            sub: 'École, Sécu, Retraite',
            amount: inKindTotal,
            color: '#1E3A8A',
          },
        ]
      : []),
  ];

  // ======================== COLONNE 4 : DESTINATION FINALE (MÉLANGE & CONVERGENCE) ========================
  const col4Specs = [
    ...(totalSecu > 0
      ? [
          {
            id: 'c4_secu',
            label: 'Sécurité Sociale & Retraite',
            sub: 'URSSAF, AGIRC-ARRCO, CSG/CRDS (Étages 1+2+3)',
            amount: totalSecu,
            color: '#D97706',
            isTax: true,
          },
        ]
      : []),
    ...(totalEtatLoc > 0
      ? [
          {
            id: 'c4_etat_loc',
            label: 'État & Collectivités (IR, TVA, IS, Foncier)',
            sub: 'Dont TVA & achats depuis votre compte + IR + IS',
            amount: totalEtatLoc,
            color: '#BE123C',
            isTax: true,
          },
        ]
      : []),
    ...(pochePure > 0
      ? [
          {
            id: 'c4_poche',
            label: 'Pouvoir d’achat réellement mobilisable',
            sub: 'Votre vrai cash disponible (achats HT + épargne perso)',
            amount: pochePure,
            color: '#15803D',
            isMobilisable: true,
          },
        ]
      : []),
    ...(impotsEnAttenteActifs > 0
      ? [
          {
            id: 'c4_latent',
            label: 'Impôts en attente (Holding & Filiale)',
            sub: 'PFU 31,4 % + CEHR + CDHR dus à la sortie future',
            amount: impotsEnAttenteActifs,
            color: '#9333EA',
            isTax: true,
          },
        ]
      : []),
    ...(reservesNettesHolding > 0
      ? [
          {
            id: 'c4_holding_net',
            label: 'Valeur bloquée Société / Holding',
            sub: 'Pas de l’argent en poche · réinvesti dans l’entreprise',
            amount: reservesNettesHolding,
            color: '#94A3B8',
            isHoldingMuted: true,
          },
        ]
      : []),
    ...(inKindTotal > 0
      ? [
          {
            id: 'c4_inkind',
            label: 'Études, Santé, Retraite & Services',
            sub: 'Prestations en nature & droits sociaux acquis',
            amount: inKindTotal,
            color: '#1E3A8A',
          },
        ]
      : []),
  ];

  // Géométrie SVG 4 colonnes = 3 étages strictement proportionnels (1 px = même nb d'euros partout !)
  const svgW = 1320;
  const svgH = 602;
  const x1 = 192;
  const x2 = 468;
  const x3 = 744;
  const x4 = 1004;
  const barW = 12;
  const topPad = 82;
  const botPad = 24;
  const availH = svgH - topPad - botPad; // 496px

  const maxNodes = Math.max(
    col1Specs.length,
    col2Specs.length,
    col3Specs.length,
    col4Specs.length,
    1
  );
  const gap = 14;
  const totalEuroPx = Math.max(240, availH - (maxNodes - 1) * gap);
  const pxPerEuro = totalEuroPx / totalFlow;

  const nodes1 = layoutColumnNodes(
    col1Specs,
    pxPerEuro,
    topPad,
    availH,
    gap,
    col1Specs.map(() => 36)
  );
  const nodes2 = layoutColumnNodes(
    col2Specs,
    pxPerEuro,
    topPad,
    availH,
    gap,
    col2Specs.map(() => 42)
  );
  const nodes3 = layoutColumnNodes(
    col3Specs,
    pxPerEuro,
    topPad,
    availH,
    gap,
    col3Specs.map(() => 42)
  );
  const nodes4 = layoutColumnNodes(
    col4Specs,
    pxPerEuro,
    topPad,
    availH,
    gap,
    col4Specs.map((n) => (n.isMobilisable ? 64 : n.isHoldingMuted ? 44 : 38))
  );

  // ======================== CONSTRUCTION DES RUBANS (0 € PERDU) ========================
  const ribbons: SankeyRibbon[] = [];

  const connectStage = (
    stage: 1 | 2 | 3,
    fromNodes: SankeyNode[],
    toNodes: SankeyNode[],
    pairs: { fromId: string; toId: string; amount: number; color: string; isMobilisable?: boolean }[]
  ) => {
    const fromCursor = Object.fromEntries(fromNodes.map((n) => [n.id, n.yTop]));
    const toCursor = Object.fromEntries(toNodes.map((n) => [n.id, n.yTop]));

    for (const p of pairs) {
      if (p.amount <= 0.01) continue;
      if (fromCursor[p.fromId] === undefined || toCursor[p.toId] === undefined) continue;
      const dh = p.amount * pxPerEuro;
      ribbons.push({
        key: `s${stage}-${p.fromId}->${p.toId}`,
        fromId: p.fromId,
        toId: p.toId,
        stage,
        y0Top: fromCursor[p.fromId],
        y0Bot: fromCursor[p.fromId] + dh,
        y1Top: toCursor[p.toId],
        y1Bot: toCursor[p.toId] + dh,
        color: p.color,
        isMobilisable: p.isMobilisable,
      });
      fromCursor[p.fromId] += dh;
      toCursor[p.toId] += dh;
    }
  };

  // Étage 1 : Col 1 -> Col 2 (Richesse + Aides + Épargne se mélangent dans Revenu brut)
  {
    const c1Rem = Object.fromEntries(nodes1.map((n) => [n.id, n.amount]));
    const c2Rem = Object.fromEntries(nodes2.map((n) => [n.id, n.amount]));
    const stage1Pairs: { fromId: string; toId: string; amount: number; color: string }[] = [];

    const add12 = (fromId: string, toId: string, amount: number, color: string) => {
      if (amount <= 0.01) return;
      stage1Pairs.push({ fromId, toId, amount, color });
      c1Rem[fromId] -= amount;
      c2Rem[toId] -= amount;
    };

    if (c1Rem['c1_inkind'] > 0 && c2Rem['c2_inkind'] > 0) {
      add12('c1_inkind', 'c2_inkind', Math.min(c1Rem['c1_inkind'], c2Rem['c2_inkind']), '#1E3A8A');
    }
    if (c1Rem['c1_aides'] > 0 && c2Rem['c2_brut_perso'] > 0) {
      add12('c1_aides', 'c2_brut_perso', Math.min(c1Rem['c1_aides'], c2Rem['c2_brut_perso']), '#047857');
    }
    if (c1Rem['c1_epargne'] > 0 && c2Rem['c2_brut_perso'] > 0) {
      add12('c1_epargne', 'c2_brut_perso', Math.min(c1Rem['c1_epargne'], c2Rem['c2_brut_perso']), '#78716C');
    }
    for (const n1 of nodes1) {
      if (c1Rem[n1.id] <= 0.01) continue;
      for (const n2 of nodes2) {
        if (c2Rem[n2.id] <= 0.01) continue;
        const take = Math.min(c1Rem[n1.id], c2Rem[n2.id]);
        if (take > 0.01) add12(n1.id, n2.id, take, n2.color);
      }
    }
    connectStage(1, nodes1, nodes2, stage1Pairs);
  }

  // Étage 2 : Col 2 -> Col 3 (Revenu brut -> Paie/IR + Compte ; Holding -> Latent + Net)
  connectStage(2, nodes2, nodes3, [
    { fromId: 'c2_emp_soc', toId: 'c3_emp_soc', amount: taxesStage1, color: '#D97706' },
    { fromId: 'c2_brut_perso', toId: 'c3_sal_ir', amount: taxesStage2, color: '#BE123C' },
    { fromId: 'c2_brut_perso', toId: 'c3_compte', amount: argentCompteBancaire, color: '#0F766E' },
    { fromId: 'c2_holding', toId: 'c3_latent', amount: impotsEnAttenteActifs, color: '#9333EA' },
    { fromId: 'c2_holding', toId: 'c3_holding_net', amount: reservesNettesHolding, color: '#94A3B8' },
    { fromId: 'c2_inkind', toId: 'c3_inkind', amount: inKindTotal, color: '#1E3A8A' },
  ]);

  // Étage 3 : Col 3 -> Col 4 (Les prélèvements des 3 étages convergent vers Sécu & État/Collectivités, le reste reste en Pouvoir d'achat)
  connectStage(3, nodes3, nodes4, [
    { fromId: 'c3_emp_soc', toId: 'c4_secu', amount: s1Secu, color: '#D97706' },
    { fromId: 'c3_emp_soc', toId: 'c4_etat_loc', amount: s1EtatLoc, color: '#EA580C' },
    { fromId: 'c3_sal_ir', toId: 'c4_secu', amount: s2Secu, color: '#D97706' },
    { fromId: 'c3_sal_ir', toId: 'c4_etat_loc', amount: s2EtatLoc, color: '#BE123C' },
    { fromId: 'c3_compte', toId: 'c4_secu', amount: s3Secu, color: '#D97706' },
    { fromId: 'c3_compte', toId: 'c4_etat_loc', amount: s3EtatLoc, color: '#C2410C' },
    {
      fromId: 'c3_compte',
      toId: 'c4_poche',
      amount: pochePure,
      color: '#15803D',
      isMobilisable: true,
    },
    { fromId: 'c3_latent', toId: 'c4_latent', amount: impotsEnAttenteActifs, color: '#9333EA' },
    { fromId: 'c3_holding_net', toId: 'c4_holding_net', amount: reservesNettesHolding, color: '#94A3B8' },
    { fromId: 'c3_inkind', toId: 'c4_inkind', amount: inKindTotal, color: '#1E3A8A' },
  ]);

  const highlightedIds = new Set<string>();
  if (hoveredId) {
    highlightedIds.add(hoveredId);
    for (let pass = 0; pass < 3; pass++) {
      for (const r of ribbons) {
        if (highlightedIds.has(r.fromId) || highlightedIds.has(r.toId)) {
          highlightedIds.add(r.fromId);
          highlightedIds.add(r.toId);
        }
      }
    }
  }

  const allNodesMap = Object.fromEntries(
    [...nodes1, ...nodes2, ...nodes3, ...nodes4].map((n) => [n.id, n])
  );
  const inspectedNode = hoveredId ? allNodesMap[hoveredId] : undefined;

  const totalTaxesOut = taxesStage1 + taxesStage2 + taxesStage3 + impotsEnAttenteActifs;
  const totalCol4 = nodes4.reduce((s, n) => s + n.amount, 0);

  return (
    <section className="rounded-2xl border border-[#E4DFD5] bg-white shadow-xs overflow-hidden">
      <div className="p-5 sm:p-6 pb-3 flex flex-wrap items-start justify-between gap-3 border-b border-[#EFECE4]">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
            Schéma 1 · Pyramide fiscale en 3 étages (épaisseur 100 % proportionnelle, zéro euro perdu)
          </div>
          <h2 className="font-editorial text-xl sm:text-2xl font-bold text-[#141413] mt-0.5">
            Le Grand Fleuve de Votre Argent
          </h2>
          {beginnerMode && (
            <p className="text-xs text-[#57534E] mt-0.5 max-w-4xl">
              Chaque millimètre d’épaisseur garde exactement la même valeur en euros :{' '}
              <strong>Étage 1 (Entreprise)</strong> → <strong>Étage 2 (Paie &amp; IR)</strong> →{' '}
              <strong>Étage 3 (TVA, Essence &amp; Foncier depuis votre compte)</strong>, puis tous les
              flux convergent vers leurs vrais destinataires et votre{' '}
              <strong className="text-[#15803D]">pouvoir d’achat réellement mobilisable</strong>.
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="inline-flex rounded-xl bg-[#F2EFE8] p-1 gap-1 font-semibold">
            <button
              type="button"
              onClick={() => setIncludeInKindInSankey(true)}
              className={`px-3 py-1 rounded-lg transition cursor-pointer whitespace-nowrap ${
                includeInKindInSankey
                  ? 'bg-white text-[#141413] shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              Flux 100 % tout inclus
            </button>
            <button
              type="button"
              onClick={() => setIncludeInKindInSankey(false)}
              className={`px-3 py-1 rounded-lg transition cursor-pointer whitespace-nowrap ${
                !includeInKindInSankey
                  ? 'bg-white text-[#141413] shadow-xs'
                  : 'text-[#57534E] hover:text-[#141413]'
              }`}
            >
              Flux monétaires seuls
            </button>
          </div>
          <span className="font-mono-num font-bold text-[#141413]">
            Total : {formatEuros(totalFlow)}
          </span>
        </div>
      </div>

      <div className="px-2 sm:px-5 pt-4 pb-3 overflow-x-auto">
        <svg
          viewBox={`0 0 ${svgW} ${svgH}`}
          className="w-full min-w-[880px] h-auto select-none"
          role="img"
          aria-label="Diagramme de Sankey en 4 colonnes et 3 étages à épaisseur strictement proportionnelle montrant la convergence des prélèvements et le pouvoir d'achat mobilisable"
        >
          {/* Ligne 1 des en-têtes : 4 colonnes */}
          <text
            x={x1}
            y={16}
            textAnchor="end"
            className="fill-[#141413] text-[11px] font-bold uppercase tracking-wider"
          >
            1. Source ({includeInKindInSankey ? '100 %' : 'cash'})
          </text>
          <text
            x={x2 + barW / 2}
            y={16}
            textAnchor="middle"
            className="fill-[#141413] text-[11px] font-bold uppercase tracking-wider"
          >
            2. Brut &amp; Société
          </text>
          <text
            x={x3 + barW / 2}
            y={16}
            textAnchor="middle"
            className="fill-[#141413] text-[11px] font-bold uppercase tracking-wider"
          >
            3. Sur votre compte
          </text>
          <text
            x={x4 + barW + 14}
            y={16}
            textAnchor="start"
            className="fill-[#141413] text-[11px] font-bold uppercase tracking-wider"
          >
            4. Destination finale exacte
          </text>

          {/* Ligne 2 des en-têtes : les 3 étages entre colonnes (sans aucune collision) */}
          <g>
            <text
              x={(x1 + barW + x2) / 2}
              y={38}
              textAnchor="middle"
              className="fill-[#D97706] text-[10.5px] font-bold uppercase tracking-wider"
            >
              Étage 1 · Avant brut ({taxesStage1 > 0 ? `−${formatEuros(taxesStage1)}` : '0 €'})
            </text>
            <text
              x={(x2 + barW + x3) / 2}
              y={38}
              textAnchor="middle"
              className="fill-[#BE123C] text-[10.5px] font-bold uppercase tracking-wider"
            >
              Étage 2 · Paie &amp; IR ({taxesStage2 > 0 ? `−${formatEuros(taxesStage2)}` : '0 €'})
            </text>
            <text
              x={(x3 + barW + x4) / 2}
              y={38}
              textAnchor="middle"
              className="fill-[#C2410C] text-[10.5px] font-bold uppercase tracking-wider"
            >
              Étage 3 · TVA &amp; achats ({taxesStage3 > 0 ? `−${formatEuros(taxesStage3)}` : '0 €'})
            </text>
          </g>

          {/* Repères verticaux discrets des colonnes intermédiaires */}
          {[x2 + barW / 2, x3 + barW / 2].map((cx) => (
            <line
              key={cx}
              x1={cx}
              y1={48}
              x2={cx}
              y2={svgH - 12}
              stroke="#EFECE4"
              strokeDasharray="3 3"
              strokeWidth={1}
            />
          ))}

          {/* Rubans des 3 étages */}
          {ribbons.map((rb) => {
            const xFrom = rb.stage === 1 ? x1 + barW : rb.stage === 2 ? x2 + barW : x3 + barW;
            const xTo = rb.stage === 1 ? x2 : rb.stage === 2 ? x3 : x4;
            const isHighlighted =
              hoveredId !== null &&
              highlightedIds.has(rb.fromId) &&
              highlightedIds.has(rb.toId);
            const isDimmed = hoveredId !== null && !isHighlighted;

            return (
              <path
                key={rb.key}
                d={buildRibbonPath(xFrom, rb.y0Top, rb.y0Bot, xTo, rb.y1Top, rb.y1Bot)}
                fill={rb.color}
                fillOpacity={
                  isHighlighted
                    ? 0.56
                    : isDimmed
                      ? 0.06
                      : rb.isMobilisable
                        ? 0.36
                        : 0.25
                }
                className="transition-opacity duration-150 cursor-pointer"
                onMouseEnter={() => setHoveredId(rb.toId)}
                onMouseLeave={() => setHoveredId(null)}
              />
            );
          })}

          {/* Barres Colonne 1 + Labels à gauche */}
          {nodes1.map((n) => {
            const barCenter = n.yTop + n.h / 2;
            const visH = Math.max(2, n.h);
            return (
              <g
                key={n.id}
                onMouseEnter={() => setHoveredId(n.id)}
                onMouseLeave={() => setHoveredId(null)}
                className="cursor-pointer"
              >
                <rect x={x1} y={n.yTop} width={barW} height={visH} rx={3} fill={n.color} />
                {Math.abs(n.labelY - barCenter) > 8 && (
                  <line
                    x1={x1 - 4}
                    y1={barCenter}
                    x2={x1 - 12}
                    y2={n.labelY}
                    stroke={n.color}
                    strokeOpacity={0.5}
                    strokeWidth={1}
                  />
                )}
                <text
                  x={x1 - 14}
                  y={n.labelY - 3}
                  textAnchor="end"
                  className="fill-[#141413] text-[12px] font-bold"
                >
                  {n.label}
                </text>
                <text
                  x={x1 - 14}
                  y={n.labelY + 13}
                  textAnchor="end"
                  className="fill-[#57534E] text-[11.5px] font-extrabold font-mono-num"
                >
                  {formatEuros(n.amount)}
                </text>
              </g>
            );
          })}

          {/* Barres + Cartes Colonne 2 & Colonne 3 */}
          {[
            { nodes: nodes2, xPos: x2 },
            { nodes: nodes3, xPos: x3 },
          ].map(({ nodes, xPos }) =>
            nodes.map((n) => {
              const visH = Math.max(2, n.h);
              const boxW = 166;
              const boxH = 36;
              const cx = xPos + barW / 2;
              const isFocus = hoveredId !== null && highlightedIds.has(n.id);
              const isDim = hoveredId !== null && !isFocus;
              return (
                <g
                  key={n.id}
                  onMouseEnter={() => setHoveredId(n.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  className="cursor-pointer"
                  style={{ opacity: isDim ? 0.35 : 1 }}
                >
                  <rect x={xPos} y={n.yTop} width={barW} height={visH} rx={3} fill={n.color} />
                  <rect
                    x={cx - boxW / 2}
                    y={n.labelY - boxH / 2}
                    width={boxW}
                    height={boxH}
                    rx={7}
                    fill="#FFFFFF"
                    fillOpacity={0.96}
                    stroke={n.color}
                    strokeOpacity={isFocus ? 0.95 : 0.45}
                    strokeWidth={isFocus ? 1.8 : 1.1}
                  />
                  <text
                    x={cx}
                    y={n.labelY - 3}
                    textAnchor="middle"
                    className="fill-[#141413] text-[10.5px] font-bold"
                  >
                    {n.label}
                  </text>
                  <text
                    x={cx}
                    y={n.labelY + 11}
                    textAnchor="middle"
                    className="text-[11px] font-extrabold font-mono-num"
                    style={{ fill: n.color }}
                  >
                    {formatEuros(n.amount)}
                  </text>
                </g>
              );
            })
          )}

          {/* Barres + Labels Colonne 4 (Destination finale) */}
          {nodes4.map((n) => {
            const barCenter = n.yTop + n.h / 2;
            const visH = Math.max(2, n.h);
            const share = (n.amount / totalFlow) * 100;
            const labelX = x4 + barW + 14;
            const isFocus = hoveredId !== null && highlightedIds.has(n.id);
            const isDim = hoveredId !== null && !isFocus;

            if (n.isMobilisable) {
              const boxH = Math.max(58, n.h);
              const boxY = n.h >= 58 ? n.yTop : n.labelY - boxH / 2;
              const textCenterY = boxY + boxH / 2;
              return (
                <g
                  key={n.id}
                  onMouseEnter={() => setHoveredId(n.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  className="cursor-pointer"
                  style={{ opacity: isDim ? 0.35 : 1 }}
                >
                  <rect
                    x={x4 - 4}
                    y={boxY}
                    width={svgW - x4 - 4}
                    height={boxH}
                    rx={10}
                    fill="#ECFDF5"
                    stroke="#15803D"
                    strokeWidth={2}
                  />
                  <rect x={x4} y={n.yTop} width={barW} height={visH} rx={3} fill="#15803D" />
                  <text
                    x={labelX}
                    y={textCenterY - 14}
                    textAnchor="start"
                    className="fill-[#15803D] text-[9.5px] font-extrabold uppercase tracking-wider"
                  >
                    Zone cash réel disponible
                  </text>
                  <text
                    x={labelX}
                    y={textCenterY + 2}
                    textAnchor="start"
                    className="fill-[#065F46] text-[12.5px] font-extrabold"
                  >
                    {n.label}
                  </text>
                  <text
                    x={labelX}
                    y={textCenterY + 18}
                    textAnchor="start"
                    className="fill-[#141413] text-[12px] font-extrabold font-mono-num"
                  >
                    {formatEuros(n.amount)} ({formatPct(share)})
                  </text>
                </g>
              );
            }

            if (n.isHoldingMuted) {
              const boxH = Math.max(40, n.h);
              const boxY = n.h >= 40 ? n.yTop : n.labelY - boxH / 2;
              const textCenterY = boxY + boxH / 2;
              return (
                <g
                  key={n.id}
                  onMouseEnter={() => setHoveredId(n.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  className="cursor-pointer"
                  style={{ opacity: isDim ? 0.35 : 1 }}
                >
                  <rect
                    x={x4 - 4}
                    y={boxY}
                    width={svgW - x4 - 6}
                    height={boxH}
                    rx={8}
                    fill="#FAF8F4"
                    stroke="#CBD5E1"
                    strokeDasharray="4 3"
                    strokeWidth={1.1}
                  />
                  <rect x={x4} y={n.yTop} width={barW} height={visH} rx={3} fill={n.color} />
                  <text
                    x={labelX}
                    y={textCenterY - 3}
                    textAnchor="start"
                    className="fill-[#475569] text-[11.5px] font-semibold"
                  >
                    {n.label} (hors poche)
                  </text>
                  <text
                    x={labelX}
                    y={textCenterY + 12}
                    textAnchor="start"
                    className="fill-[#64748B] text-[11px] font-mono-num font-bold"
                  >
                    {formatEuros(n.amount)} ({formatPct(share)}) · pas du cash perso
                  </text>
                </g>
              );
            }

            return (
              <g
                key={n.id}
                onMouseEnter={() => setHoveredId(n.id)}
                onMouseLeave={() => setHoveredId(null)}
                className="cursor-pointer"
                style={{ opacity: isDim ? 0.35 : 1 }}
              >
                <rect x={x4} y={n.yTop} width={barW} height={visH} rx={3} fill={n.color} />
                {Math.abs(n.labelY - barCenter) > 8 && (
                  <line
                    x1={x4 + barW + 2}
                    y1={barCenter}
                    x2={labelX - 3}
                    y2={n.labelY}
                    stroke={n.color}
                    strokeOpacity={0.55}
                    strokeWidth={1}
                  />
                )}
                <text
                  x={labelX}
                  y={n.labelY - 3}
                  textAnchor="start"
                  className="fill-[#141413] text-[12px] font-bold"
                >
                  {n.label}
                </text>
                <text
                  x={labelX}
                  y={n.labelY + 12}
                  textAnchor="start"
                  className="fill-[#57534E] text-[11px] font-mono-num"
                >
                  {formatEuros(n.amount)} ({formatPct(share)})
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Inspecteur interactif en bas du Sankey */}
      <div className="px-5 py-2.5 bg-[#FAF8F4] border-t border-[#EFECE4] flex flex-wrap items-center justify-between gap-2 text-xs text-[#57534E]">
        {inspectedNode ? (
          <span>
            <strong className="text-[#141413]">{inspectedNode.label} :</strong>{' '}
            {inspectedNode.sub ?? 'Flux intermédiaire'} —{' '}
            <strong className="font-mono-num text-[#141413]">
              {formatEuros(inspectedNode.amount)}/an
            </strong>{' '}
            ({formatPct((inspectedNode.amount / totalFlow) * 100)} du flux total)
          </span>
        ) : (
          <span>
            Astuce : survolez n’importe quel bloc pour tracer son trajet exact à travers les 3 étages. Total impôts :{' '}
            <strong className="font-mono-num text-[#BE123C]">{formatEuros(totalTaxesOut)}</strong>.
          </span>
        )}
        <span className="font-mono-num text-[11px] font-semibold text-[#15803D]">
          Entrées ({formatEuros(totalFlow)}) = Sorties ({formatEuros(totalCol4)}) · 0 € évaporé
        </span>
      </div>
    </section>
  );
};
