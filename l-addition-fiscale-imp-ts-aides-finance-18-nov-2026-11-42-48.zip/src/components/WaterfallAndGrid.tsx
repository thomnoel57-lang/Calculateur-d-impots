import React, { useState } from 'react';
import { SimulationResult, SimulationState } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface WaterfallAndGridProps {
  state: SimulationState;
  result: SimulationResult;
  beginnerMode: boolean;
}

export const WaterfallAndGrid: React.FC<WaterfallAndGridProps> = ({
  state,
  result,
  beginnerMode,
}) => {
  const [hoveredSquareLabel, setHoveredSquareLabel] = useState<string | null>(null);

  const impotsEnAttenteActifs =
    state.inclureTaxesSocieteEtHolding && state.inclureImpotsLatentsHolding
      ? result.impotsEnAttenteHolding
      : 0;
  const reservesBrutesSocieteEtHolding = state.inclureTaxesSocieteEtHolding
    ? result.holdingAndValuation.reserveRestantEnHolding +
      result.holdingAndValuation.beneficeRetenuEnFiliale
    : 0;
  const reservesSocieteHolding = Math.max(
    0,
    reservesBrutesSocieteEtHolding - impotsEnAttenteActifs
  );

  const maxRef = Math.max(1, result.richesseCreeeTotale, result.etape4RevenuDisponibleNet + result.aides.totalAidesMonetaires);
  const argentCompteAvecAides = Math.max(
    0,
    result.etape4RevenuDisponibleNet + result.aides.totalAidesMonetaires
  );
  const taxesApresCompte =
    result.prelevEtape4PatrimoineLocaux + result.prelevEtape5ConsommationTvaAccises;

  const stages = [
    {
      id: 'st1',
      step: 'Étage 1',
      title: 'Richesse créée brute (Travail + Capital + Société)',
      remaining: result.etape1SuperBrutEtCreation,
      deducted: result.prelevEtape1SourceEntreprisePatronal + reservesSocieteHolding,
      subtitle: state.inclureTaxesSocieteEtHolding
        ? reservesBrutesSocieteEtHolding > 0
          ? `Patronales + IS/CFE/Holding (−${formatEuros(result.prelevEtape1SourceEntreprisePatronal)}) + valeur restée en société/holding (encadré discret en bas)`
          : `Retenu avant fiche de paie : cotisations patronales + IS/CFE/Holding (−${formatEuros(result.prelevEtape1SourceEntreprisePatronal)})`
        : `Retenu avant fiche de paie : cotisations patronales (−${formatEuros(result.prelevEtape1SourceEntreprisePatronal)})`,
      isFinal: false,
    },
    {
      id: 'st2',
      step: 'Étage 2',
      title: 'Revenu brut personnel versé',
      remaining: result.etape2RevenuBrutPersonnel,
      deducted: result.prelevEtape2CotisSalarialesCsgTns,
      subtitle: `Retenues sociales fiche de paie, retraite, CSG & CRDS (−${formatEuros(result.prelevEtape2CotisSalarialesCsgTns)})`,
      isFinal: false,
    },
    {
      id: 'st3',
      step: 'Étage 3',
      title: 'Revenu net avant impôts directs',
      remaining: result.etape3RevenuNetAvantImpots,
      deducted: result.prelevEtape3IrPfuCapitalTransmission,
      subtitle: `Impôt sur le revenu (IR), Flat Tax 31,4 %, CEHR/CDHR (−${formatEuros(result.prelevEtape3IrPfuCapitalTransmission)})`,
      isFinal: false,
    },
    {
      id: 'st4',
      step: 'Étage 4',
      title:
        result.aides.totalAidesMonetaires > 0
          ? 'Argent arrivé sur votre compte (+ aides cash)'
          : 'Argent net arrivé sur le compte bancaire',
      remaining: argentCompteAvecAides,
      deducted: taxesApresCompte,
      subtitle: `${
        result.aides.totalAidesMonetaires > 0
          ? `Inclut +${formatEuros(result.aides.totalAidesMonetaires)} d’aides reçues · `
          : ''
      }Payé depuis votre compte : Foncier/IFI + TVA & accises (−${formatEuros(taxesApresCompte)})`,
      isFinal: false,
    },
    {
      id: 'st5',
      step: 'Étage 5',
      title: 'Pouvoir d’achat réellement mobilisable',
      remaining: Math.max(0, result.resteNetApresAidesEtTaxes),
      deducted: 0,
      subtitle:
        'Votre vrai cash personnel disponible (achats hors taxes + épargne), 100 % net de tout impôt',
      isFinal: true,
    },
  ];

  // Grille 100 carrés = 100 € de richesse produite (Schéma 3 · Anatomie de 100 € créés)
  const familyBuckets: {
    label: string;
    color: string;
    share: number;
    annual: number;
    isNet: boolean;
  }[] = [];

  for (const fam of result.families) {
    if (fam.amount <= 0) continue;
    const share = (fam.amount / maxRef) * 100;
    if (share >= 0.4) {
      familyBuckets.push({
        label: fam.shortLabel,
        color: fam.color,
        share,
        annual: fam.amount,
        isNet: false,
      });
    }
  }
  if (reservesSocieteHolding > 0) {
    familyBuckets.push({
      label: 'Réserves Société/Holding',
      color: '#7C3AED',
      share: (reservesSocieteHolding / maxRef) * 100,
      annual: reservesSocieteHolding,
      isNet: false,
    });
  }
  const netShareRaw = Math.max(0, (Math.max(0, result.resteNetReelPur) / maxRef) * 100);
  if (netShareRaw > 0) {
    familyBuckets.push({
      label: 'Net pur en poche',
      color: '#15803D',
      share: netShareRaw,
      annual: Math.max(0, result.resteNetReelPur),
      isNet: true,
    });
  }

  // Attribution exacte des 100 carrés (méthode des plus forts restes -> somme === 100)
  const rawCounts = familyBuckets.map((b) => Math.floor(b.share));
  let remainder = 100 - rawCounts.reduce((s, c) => s + c, 0);
  const fracs = familyBuckets
    .map((b, i) => ({ i, frac: b.share - rawCounts[i] }))
    .sort((a, b) => b.frac - a.frac);
  for (let k = 0; k < fracs.length && remainder > 0; k++) {
    rawCounts[fracs[k].i]++;
    remainder--;
  }

  const squares: {
    index: number;
    label: string;
    color: string;
    euroPer100: number;
    annualAmount: number;
    isNet: boolean;
  }[] = [];

  familyBuckets.forEach((b, i) => {
    for (let c = 0; c < rawCounts[i]; c++) {
      squares.push({
        index: squares.length + 1,
        label: b.label,
        color: b.color,
        euroPer100: b.share,
        annualAmount: b.annual,
        isNet: b.isNet,
      });
    }
  });
  while (squares.length < 100) {
    squares.push({
      index: squares.length + 1,
      label: 'Net pur en poche',
      color: '#15803D',
      euroPer100: netShareRaw,
      annualAmount: Math.max(0, result.resteNetReelPur),
      isNet: true,
    });
  }

  const inspectedBucket = familyBuckets.find((b) => b.label === hoveredSquareLabel);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Schéma 2 · Les 5 étages de la fusée fiscale */}
      <section className="lg:col-span-7 bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6">
        <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
          Schéma 2 · Les 5 étages de la fusée fiscale
        </div>
        <h2 className="font-editorial text-xl font-bold text-[#141413] mt-0.5 mb-1">
          L’Érosion Étape par Étape de Votre Richesse
        </h2>
        {beginnerMode && (
          <p className="text-xs text-[#57534E] mb-4">
            Chaque barre montre ce qu’il reste après les retenues de l’étage, jusqu’au vrai pouvoir d’achat final.
          </p>
        )}

        <div className="space-y-3.5 mt-3">
          {stages.map((st, idx) => {
            const remPct = Math.max(0, Math.min(100, (st.remaining / maxRef) * 100));
            const dedPct = Math.max(0, Math.min(100, (st.deducted / maxRef) * 100));
            return (
              <div
                key={st.id}
                className={
                  st.isFinal
                    ? 'rounded-xl border-2 border-[#15803D]/35 bg-[#ECFDF5]/85 p-3'
                    : 'group'
                }
              >
                <div className="flex items-baseline justify-between gap-2 mb-1">
                  <div className="min-w-0">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded mr-2 ${
                        idx === 0
                          ? 'bg-[#141413] text-white'
                          : st.isFinal
                            ? 'bg-[#15803D] text-white'
                            : 'bg-[#F2EFE8] text-[#57534E]'
                      }`}
                    >
                      {st.step}
                    </span>
                    <span
                      className={`text-xs sm:text-sm font-bold ${
                        st.isFinal ? 'text-[#065F46]' : 'text-[#141413]'
                      }`}
                    >
                      {st.title}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2 shrink-0 font-mono-num">
                    {st.deducted > 0 && (
                      <span className="text-[11px] font-semibold text-[#BE123C]">
                        −{formatEuros(st.deducted)}
                      </span>
                    )}
                    <span
                      className={`font-extrabold ${
                        st.isFinal ? 'text-sm sm:text-base text-[#15803D]' : 'text-xs sm:text-sm text-[#141413]'
                      }`}
                    >
                      {formatEuros(st.remaining)}
                    </span>
                  </div>
                </div>

                <div className="h-6 w-full bg-[#F3F0E8] rounded-lg overflow-hidden flex items-center">
                  <div
                    className="h-full transition-all duration-300 flex items-center pl-2.5"
                    style={{
                      width: `${Math.max(2, remPct)}%`,
                      backgroundColor: st.isFinal ? '#15803D' : idx === 0 ? '#141413' : '#334155',
                    }}
                  >
                    {remPct >= 18 && (
                      <span className="text-[11px] font-mono-num font-bold text-white">
                        {formatPct(remPct, 0)}
                      </span>
                    )}
                  </div>
                  {st.deducted > 0 && dedPct >= 4 && (
                    <div
                      className="h-full bg-[#BE123C]/85 border-l border-white/60 flex items-center justify-center px-1"
                      style={{ width: `${Math.min(100 - remPct + dedPct, dedPct)}%` }}
                    >
                      {dedPct >= 8 && (
                        <span className="text-[10px] font-mono-num font-bold text-white whitespace-nowrap">
                          −{formatPct(dedPct, 0)}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                <p
                  className={`text-[11px] mt-1 ${
                    st.isFinal ? 'text-[#065F46] font-medium' : 'text-[#78716C] truncate'
                  }`}
                >
                  {st.subtitle}
                </p>
              </div>
            );
          })}
        </div>

        {/* Valeur gagnée en Holding & Société : volontairement en bas et plus discrète */}
        {state.inclureTaxesSocieteEtHolding && reservesBrutesSocieteEtHolding > 0 && (
          <div className="mt-3.5 rounded-xl border border-dashed border-[#D6D0C4] bg-[#FAF8F4]/70 px-3.5 py-2.5 text-xs text-[#57534E]">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <span className="font-semibold text-[#44403C]">
                À part · Valeur gagnée en Holding &amp; Société (hors poche)
              </span>
              <span className="font-mono-num font-bold text-[#475569]">
                {formatEuros(reservesSocieteHolding)} nets bloqués
              </span>
            </div>
            <p className="mt-1 text-[11px] text-[#78716C] leading-relaxed">
              <strong>Pour les débutants :</strong> ce n’est pas de l’argent disponible pour vivre. Cette richesse reste enfermée dans l’entreprise/holding ({formatEuros(reservesBrutesSocieteEtHolding)} bruts) et subira{' '}
              <span className="font-mono-num font-semibold text-[#6D28D9]">
                {formatEuros(result.holdingAndValuation.totalImpotsEnAttenteFlux)}
              </span>{' '}
              d’impôts en attente si elle sort un jour sur votre compte.
            </p>
          </div>
        )}

        {/* Bloc récapitulatif Aides & Droits 100 % inclus */}
        <div className="mt-4 pt-3 border-t border-[#EFECE4] grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
          <div className="rounded-xl bg-[#ECFDF5]/80 border border-[#A7F3D0] p-3">
            <div className="text-[#065F46] font-bold">
              + Aides en cash : {formatEuros(result.aides.totalAidesMonetaires, true)}
            </div>
            <div className="text-[11px] text-[#065F46]/80 mt-0.5">
              CROUS, APL, Mobili-Jeune, Prime d’activité, RSA, ASPA, ASF, PAJE, CMG, Chèque énergie
            </div>
          </div>
          <div className="rounded-xl bg-[#EFF6FF]/80 border border-[#BFDBFE] p-3">
            <div className="text-[#1E3A8A] font-bold">
              + Études, Santé, Retraite &amp; Tarifs sociaux : {formatEuros(result.aides.totalPrestationsEnNatureEtDroits, true)}
            </div>
            <div className="text-[11px] text-[#1E3A8A]/80 mt-0.5">
              École/fac/CFA gratuits, cantine, crèche, CNAM/CSS, droits retraite, CPF, HLM
            </div>
          </div>
        </div>
      </section>

      {/* Schéma 3 · Anatomie de 100 € créés */}
      <section className="lg:col-span-5 bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6 flex flex-col justify-between">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
            Schéma 3 · Anatomie de 100 € créés
          </div>
          <h2 className="font-editorial text-xl font-bold text-[#141413] mt-0.5 mb-1">
            Où Part Chaque Euro sur 100 € ?
          </h2>
          <p className="text-xs text-[#78716C] mb-4">
            Chaque carré = <strong className="text-[#141413]">1 €</strong> sur 100 € produits. Les carrés verts marqués <strong className="text-[#15803D]">€</strong> restent en poche.
          </p>

          <div
            className="grid grid-cols-10 gap-1.5 max-w-[330px] mx-auto my-2"
            role="img"
            aria-label="Grille de 100 carrés représentant la répartition de 100 euros de richesse créée"
          >
            {squares.map((sq) => {
              const isDim = hoveredSquareLabel !== null && hoveredSquareLabel !== sq.label;
              return (
                <div
                  key={sq.index}
                  onMouseEnter={() => setHoveredSquareLabel(sq.label)}
                  onMouseLeave={() => setHoveredSquareLabel(null)}
                  className={`aspect-square rounded-[5px] transition-all duration-150 cursor-pointer flex items-center justify-center text-[9px] font-mono-num font-bold ${
                    isDim ? 'opacity-20 scale-95' : 'opacity-100 hover:scale-110'
                  } ${sq.isNet ? 'ring-1 ring-[#166534]/30 text-white' : 'text-white/90'}`}
                  style={{ backgroundColor: sq.color }}
                  title={`${sq.label} : ${sq.euroPer100.toFixed(1).replace('.', ',')} € sur 100 €`}
                >
                  {sq.isNet ? '€' : ''}
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-[#EFECE4]">
          {inspectedBucket ? (
            <div className="p-2.5 rounded-xl bg-[#FAF8F4] border border-[#E4DFD5] flex items-center justify-between gap-2 mb-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-3 h-3 rounded-xs shrink-0"
                  style={{ backgroundColor: inspectedBucket.color }}
                />
                <span className="text-xs font-bold text-[#141413] truncate">
                  {inspectedBucket.label}
                </span>
              </div>
              <span className="text-xs font-mono-num font-extrabold text-[#141413] shrink-0">
                {inspectedBucket.share.toFixed(1).replace('.', ',')} € / 100 € ({formatEuros(inspectedBucket.annual)}/an)
              </span>
            </div>
          ) : (
            <div className="flex flex-wrap gap-x-3 gap-y-1.5 text-xs mb-2">
              {familyBuckets.map((b) => (
                <button
                  key={b.label}
                  type="button"
                  onMouseEnter={() => setHoveredSquareLabel(b.label)}
                  onMouseLeave={() => setHoveredSquareLabel(null)}
                  className="inline-flex items-center gap-1.5 text-[#44403C] hover:text-[#141413] cursor-pointer"
                >
                  <span
                    className="w-2.5 h-2.5 rounded-[2px] shrink-0"
                    style={{ backgroundColor: b.color }}
                  />
                  <span>
                    {b.label}{' '}
                    <strong className="font-mono-num">{b.share.toFixed(0)}%</strong>
                  </span>
                </button>
              ))}
            </div>
          )}

          <p className="text-[11px] text-[#57534E]">
            Après inclusion 100 % des aides &amp; droits acquis ({formatEuros(result.aides.totalAidesEtServicesComplet)}), le taux net intégral est de{' '}
            <strong
              className={`font-mono-num ${
                result.tauxNetApresAidesPct < 0 ? 'text-[#15803D]' : 'text-[#1E3A8A]'
              }`}
            >
              {formatPct(result.tauxNetApresAidesPct, 1, true)}
            </strong>
            .
          </p>
        </div>
      </section>
    </div>
  );
};
