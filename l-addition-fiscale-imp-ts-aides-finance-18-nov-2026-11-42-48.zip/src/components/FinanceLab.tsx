import React, { useMemo, useState } from 'react';
import { Building2, Lock, TrendingDown, Wallet } from 'lucide-react';
import { runSimulation } from '../engine/taxEngine';
import { SimulationResult, SimulationState } from '../types/fiscal';
import { formatEuros, formatPct } from '../utils/formatters';

interface FinanceLabProps {
  state: SimulationState;
  result: SimulationResult;
  onChange: (updater: (prev: SimulationState) => SimulationState) => void;
}

function computeProgressiveCehr(rfr: number, isCouple: boolean): number {
  const s1 = isCouple ? 500000 : 250000;
  const s2 = isCouple ? 1000000 : 500000;
  if (rfr <= s1) return 0;
  return rfr > s2
    ? (s2 - s1) * 0.03 + (rfr - s2) * 0.04
    : (rfr - s1) * 0.03;
}

function computeCapitalOutTax(amountBrut: number, baseOtherRfr: number, isCouple: boolean): number {
  if (amountBrut <= 0) return 0;
  const pfu = amountBrut * 0.314;
  const cehr =
    computeProgressiveCehr(baseOtherRfr + amountBrut, isCouple) -
    computeProgressiveCehr(baseOtherRfr, isCouple);
  const seuilCdhr = isCouple ? 500000 : 250000;
  const totalRfr = baseOtherRfr + amountBrut;
  let cdhr = 0;
  if (totalRfr > seuilCdhr) {
    const irPartOnAmount = amountBrut * 0.128 + cehr;
    const cible20 = amountBrut * 0.2;
    if (irPartOnAmount < cible20) {
      cdhr = cible20 - irPartOnAmount;
    }
  }
  return pfu + cehr + cdhr;
}

export const FinanceLab: React.FC<FinanceLabProps> = ({
  state,
  result,
  onChange,
}) => {
  const isCouple = state.situationFamiliale === 'couple';

  const [demoDividende, setDemoDividende] = useState<number>(
    result.effective.dividendesBrutsAnnuels > 0
      ? result.effective.dividendesBrutsAnnuels
      : 100000
  );
  const [demoHoldingPct, setDemoHoldingPct] = useState<number>(
    result.effective.partRemonteeHoldingPct > 0
      ? result.effective.partRemonteeHoldingPct
      : 60
  );
  const [demoValoM, setDemoValoM] = useState<number>(
    result.holdingAndValuation.valorisationPapierEstimee > 0
      ? Math.round(result.holdingAndValuation.valorisationPapierEstimee / 1_000_000)
      : 100
  );
  const [demoDecotePct, setDemoDecotePct] = useState<number>(
    result.effective.decoteLiquiditeCessionPct || 25
  );

  // Calculs Poche vs Holding (en €, barème progressif CEHR + CDHR exact)
  const beneficeAvantIs = Math.round(demoDividende / 0.75);
  const isPayeSociete =
    Math.min(beneficeAvantIs, 42500) * 0.15 +
    Math.max(0, beneficeAvantIs - 42500) * 0.25;
  const partEnHoldingBrut = demoDividende * (demoHoldingPct / 100);
  const partEnPocheBrut = demoDividende - partEnHoldingBrut;

  const impotDirectPoche = computeCapitalOutTax(partEnPocheBrut, 0, isCouple);
  const cashNetEnPocheImmediat = Math.max(0, partEnPocheBrut - impotDirectPoche);

  // En holding : 1,25 % d'impôt mère-fille (5 % QPFC x 25 % IS) -> argent bloqué
  const impotHoldingImmediat = partEnHoldingBrut * 0.0125;
  const reserveBloqueeHolding = Math.max(0, partEnHoldingBrut - impotHoldingImmediat);
  const impotLatentSortieHolding = computeCapitalOutTax(
    reserveBloqueeHolding,
    partEnPocheBrut,
    isCouple
  );
  const cashFinalSiSortieHolding = Math.max(
    0,
    reserveBloqueeHolding - impotLatentSortieHolding
  );

  // Calculs Effet Bernard Arnault (Valorisation papier en M€ -> Cash réel si tout vendu)
  const valoEuros = demoValoM * 1_000_000;
  const perteLiquidite = valoEuros * (demoDecotePct / 100);
  const prixVenteEffectif = Math.max(0, valoEuros - perteLiquidite);
  const impotPlusValueCession = computeCapitalOutTax(prixVenteEffectif, 0, isCouple);
  const cashReelArnault = Math.max(0, prixVenteEffectif - impotPlusValueCession);

  // Schéma 7 · Test du billet de +100 €
  const billetTest = useMemo(() => {
    const isPureCapital =
      state.statut === 'rentier' ||
      (state.statut === 'dirigeant_sas' &&
        state.salaireBrutAnnuel === 0 &&
        result.effective.dividendesBrutsAnnuels > 0);

    if (isPureCapital) {
      const baseDiv = Math.max(12000, result.effective.dividendesBrutsAnnuels);
      const baseBenef = Math.max(
        result.effective.beneficeSocieteAvantIs,
        Math.round(baseDiv / 0.75)
      );
      const baseState: SimulationState = {
        ...state,
        overrides: {
          ...state.overrides,
          beneficeSocieteAvantIs: baseBenef,
          dividendesBrutsAnnuels: baseDiv,
          partRemonteeHoldingPct: 0, // Test sur 100 € créés puis sortis en poche
        },
      };
      const r0 = runSimulation(baseState);
      const plusState: SimulationState = {
        ...baseState,
        overrides: {
          ...baseState.overrides,
          beneficeSocieteAvantIs: baseBenef + 1600,
          dividendesBrutsAnnuels: baseDiv + 1200,
          partRemonteeHoldingPct: 0,
        },
      };
      const r1 = runSimulation(plusState);
      const deltaRichesse = Math.max(100, r1.richesseCreeeTotale - r0.richesseCreeeTotale);
      const dCorp = Math.max(0, r1.impotsPayesParEntreprise - r0.impotsPayesParEntreprise);
      const dCapPerso = Math.max(
        0,
        (r1.families.find((f) => f.id === 'capital_entreprise')?.amount ?? 0) -
          (r0.families.find((f) => f.id === 'capital_entreprise')?.amount ?? 0) -
          dCorp +
          ((r1.families.find((f) => f.id === 'revenu')?.amount ?? 0) -
            (r0.families.find((f) => f.id === 'revenu')?.amount ?? 0))
      );
      const dConso = Math.max(0, r1.totalPrelevements - r0.totalPrelevements - dCorp - dCapPerso);
      const deltaNetPoche = Math.max(0, r1.resteNetApresAidesEtTaxes - r0.resteNetApresAidesEtTaxes);
      const to100 = (v: number) => Math.max(0, (v / deltaRichesse) * 100);
      const segments = [
        { label: 'Impôt Société (IS 25 %)', val: to100(dCorp), color: '#7C3AED' },
        { label: 'PFU 31,4 % + CEHR/CDHR', val: to100(dCapPerso), color: '#BE123C' },
        { label: 'TVA & taxes sur achats', val: to100(dConso), color: '#C2410C' },
      ].filter((s) => s.val >= 0.4);

      return {
        contextLabel: `${formatEuros(Math.round(baseDiv / 12))} de dividendes/mois (sortis en poche)`,
        deltaSuperBrut: deltaRichesse,
        deltaNetPoche,
        deltaDroitsRetraite: 0,
        resteNetPoche: Math.min(100, Math.max(0, (deltaNetPoche / deltaRichesse) * 100)),
        segments,
      };
    }

    const baseIncome =
      state.statut === 'retraite'
        ? state.pensionRetraiteBruteAnnuelle
        : state.statut === 'chomeur'
          ? state.allocationChomageBruteAnnuelle
          : state.salaireBrutAnnuel;
    const isZeroRsa = state.statut === 'rsa_inactif' && baseIncome === 0;
    const refIncome = isZeroRsa ? 0 : Math.max(1200, baseIncome);
    const baseState: SimulationState = {
      ...state,
      statut: isZeroRsa ? 'salarie_non_cadre' : state.statut,
      salaireBrutAnnuel: refIncome,
      pensionRetraiteBruteAnnuelle: refIncome,
      allocationChomageBruteAnnuelle: refIncome,
    };
    const r0 = runSimulation(baseState);
    const plusState: SimulationState = {
      ...baseState,
      salaireBrutAnnuel: refIncome + 1200,
      pensionRetraiteBruteAnnuelle: refIncome + 1200,
      allocationChomageBruteAnnuelle: refIncome + 1200,
    };
    const r1 = runSimulation(plusState);
    const deltaSuperBrut = Math.max(100, r1.richesseCreeeTotale - r0.richesseCreeeTotale);
    const dPat =
      (r1.families.find((f) => f.id === 'patronales')?.amount ?? 0) -
      (r0.families.find((f) => f.id === 'patronales')?.amount ?? 0);
    const dSal =
      (r1.families.find((f) => f.id === 'salariales_sociales')?.amount ?? 0) -
      (r0.families.find((f) => f.id === 'salariales_sociales')?.amount ?? 0);
    const dIr =
      (r1.families.find((f) => f.id === 'revenu')?.amount ?? 0) -
      (r0.families.find((f) => f.id === 'revenu')?.amount ?? 0);
    const dConso =
      r1.totalPrelevements - r0.totalPrelevements - dPat - dSal - dIr;
    const deltaAidesCash = r1.aides.totalAidesMonetaires - r0.aides.totalAidesMonetaires;
    const deltaDroitsRetraite =
      r1.aides.totalPrestationsEnNatureEtDroits - r0.aides.totalPrestationsEnNatureEtDroits;
    const deltaNetPoche = r1.resteNetApresAidesEtTaxes - r0.resteNetApresAidesEtTaxes;

    const to100 = (v: number) => Math.max(0, (v / deltaSuperBrut) * 100);
    const segments = [
      { label: 'Charges employeur', val: to100(dPat), color: '#D97706' },
      { label: 'Retenues fiche de paie & CSG', val: to100(dSal), color: '#B45309' },
      { label: 'Impôt sur le revenu (IR)', val: to100(dIr), color: '#BE123C' },
      { label: 'TVA & taxes sur achats', val: to100(dConso), color: '#C2410C' },
      ...(deltaAidesCash < -5
        ? [{ label: 'Baisse d’aides CAF/APL', val: to100(-deltaAidesCash), color: '#7C3AED' }]
        : []),
    ].filter((s) => s.val >= 0.4);

    const resteNetPoche = Math.max(0, (deltaNetPoche / deltaSuperBrut) * 100);

    return {
      contextLabel: isZeroRsa
        ? 'reprise d’activité depuis 0 €'
        : `${formatEuros(Math.round(refIncome / 12))} brut/mois`,
      deltaSuperBrut,
      deltaNetPoche,
      deltaDroitsRetraite,
      resteNetPoche,
      segments,
    };
  }, [state, result.effective.dividendesBrutsAnnuels]);

  // Schéma 8 · Courbe SVG complète 1 200 € -> 25 000 € brut/mois
  const curveData = useMemo(() => {
    const monthlySteps = [
      1200, 1500, 1802, 2100, 2500, 2883, 3500, 4500, 6000, 8000, 11000, 15000, 20000, 25000,
    ];
    return monthlySteps.map((m) => {
      const sim = runSimulation({
        ...state,
        statut: m >= 4500 ? 'salarie_cadre' : 'salarie_non_cadre',
        salaireBrutAnnuel: m * 12,
        situationFamiliale: 'celibataire',
        statutConjoint: 'aucun',
        nbEnfants: 0,
      });
      const consoTaxes =
        (sim.families.find((f) => f.id === 'tva_conso')?.amount ?? 0) +
        (sim.families.find((f) => f.id === 'energie_mobilite')?.amount ?? 0) +
        (sim.families.find((f) => f.id === 'accises_assurances')?.amount ?? 0);
      const tvaPct = (consoTaxes / Math.max(1, sim.richesseCreeeTotale)) * 100;
      const irPct =
        ((sim.families.find((f) => f.id === 'revenu')?.amount ?? 0) /
          Math.max(1, sim.richesseCreeeTotale)) *
        100;
      return {
        m,
        tauxBrut: sim.tauxPrelevementReelPct,
        tauxNet100: sim.tauxNetApresAidesPct,
        tvaPct,
        irPct,
      };
    });
  }, [state]);

  // Géométrie SVG Schéma 8
  const svgW = 640;
  const svgH = 235;
  const padL = 42;
  const padR = 18;
  const padT = 22;
  const padB = 30;
  const minLog = Math.log10(1200);
  const maxLog = Math.log10(25000);
  const mapX = (m: number) =>
    padL +
    ((Math.log10(Math.min(25000, Math.max(1200, m))) - minLog) / (maxLog - minLog)) *
      (svgW - padL - padR);
  const mapY = (pct: number) =>
    padT + ((68 - Math.max(-35, Math.min(68, pct))) / (68 - -35)) * (svgH - padT - padB);

  const buildPath = (accessor: (d: (typeof curveData)[number]) => number) =>
    curveData
      .map((d, i) => `${i === 0 ? 'M' : 'L'} ${mapX(d.m).toFixed(1)} ${mapY(accessor(d)).toFixed(1)}`)
      .join(' ');

  const pathBrut = buildPath((d) => d.tauxBrut);
  const pathNet100 = buildPath((d) => d.tauxNet100);
  const pathIr = buildPath((d) => d.irPct);
  const pathTva = buildPath((d) => d.tvaPct);
  const areaBrut = `${pathBrut} L ${mapX(25000).toFixed(1)} ${mapY(0).toFixed(1)} L ${mapX(1200).toFixed(1)} ${mapY(0).toFixed(1)} Z`;

  const xFillon = mapX(2883);
  const hasSalaryCurvePoint = result.brutFoyer >= 12000;
  const userMonthly = Math.min(25000, Math.max(1200, Math.round(result.brutFoyer / 12)));
  const userX = mapX(userMonthly);
  const userY = mapY(result.tauxPrelevementReelPct);

  const ev = result.everydayBreakdown;

  return (
    <div className="space-y-6">
      {/* Intro pédagogique */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs">
        <h2 className="font-editorial text-2xl font-bold text-[#141413]">
          Comprendre la Finance, les Holdings &amp; les Impôts Cachés
        </h2>
        <p className="mt-1 text-sm text-[#57534E] max-w-4xl">
          Pourquoi une holding ne paie que 1,25 % d’impôt en attendant ? Pourquoi la fortune boursière d’un grand patron n’est pas du cash ? Et combien vous reste-t-il vraiment sur +100 € gagnés ou sur un plein d’essence ?
        </p>
      </section>

      {/* SCHÉMA FINANCE 1 : POCHE PERSONNELLE VS HOLDING */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs space-y-5">
        <div className="border-b border-[#EFECE4] pb-3">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
            Finance d’entreprise · Holding vs Poche
          </div>
          <h3 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
            Argent en Poche vs Holding (« en attente d’être taxé »)
          </h3>
          <p className="text-xs text-[#57534E] mt-0.5">
            Tant que l’argent reste dans la holding, il ne peut servir qu’à réinvestir en entreprise — pas à payer vos courses ou votre résidence. Dès qu’il sort en poche, le PFU (31,4 %) + CEHR/CDHR s’appliquent intégralement.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="demo-div" className="font-semibold text-[#44403C]">
                Dividendes distribués par la filiale
              </label>
              <span className="font-mono-num font-bold text-[#141413]">
                {formatEuros(demoDividende)}
              </span>
            </div>
            <input
              id="demo-div"
              type="range"
              min={20000}
              max={2500000}
              step={10000}
              value={demoDividende}
              onChange={(e) => setDemoDividende(Number(e.target.value))}
              className="w-full fiscal-slider"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="demo-holding-pct" className="font-semibold text-[#44403C]">
                Part remontée en Holding vs Poche perso
              </label>
              <span className="font-mono-num font-bold text-[#B45309]">
                {demoHoldingPct} % Holding / {100 - demoHoldingPct} % Poche
              </span>
            </div>
            <input
              id="demo-holding-pct"
              type="range"
              min={0}
              max={100}
              step={5}
              value={demoHoldingPct}
              onChange={(e) => setDemoHoldingPct(Number(e.target.value))}
              className="w-full fiscal-slider"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 items-stretch">
          <div className="rounded-xl border border-[#E4DFD5] bg-[#FAF8F4] p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-[#57534E]">
                <Building2 className="h-4 w-4 text-[#141413]" />
                <span>1. La filiale paie d’abord l’IS</span>
              </div>
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#57534E]">Bénéfice avant IS</span>
                  <span className="font-mono-num font-semibold">{formatEuros(beneficeAvantIs)}</span>
                </div>
                <div className="flex justify-between text-[#BE123C]">
                  <span>− Impôt sur les Sociétés (15 / 25 %)</span>
                  <span className="font-mono-num font-bold">−{formatEuros(isPayeSociete)}</span>
                </div>
                <div className="pt-2 border-t border-[#E4DFD5] flex justify-between font-bold text-[#141413]">
                  <span>= Dividende distribuable</span>
                  <span className="font-mono-num">{formatEuros(demoDividende)}</span>
                </div>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-[#78716C]">
              Impôt payé par l’entreprise (inclus à 100 % dans le simulateur).
            </p>
          </div>

          <div className="rounded-xl border border-[#A7F3D0] bg-[#ECFDF5]/60 p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-[#065F46]">
                <Wallet className="h-4 w-4 text-[#15803D]" />
                <span>2A. En poche perso ({100 - demoHoldingPct} %)</span>
              </div>
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#44403C]">Versé sur compte perso</span>
                  <span className="font-mono-num font-semibold">{formatEuros(partEnPocheBrut)}</span>
                </div>
                <div className="flex justify-between text-[#BE123C]">
                  <span>− PFU 31,4 % + CEHR/CDHR</span>
                  <span className="font-mono-num font-bold">−{formatEuros(impotDirectPoche)}</span>
                </div>
                <div className="pt-2 border-t border-[#A7F3D0] flex justify-between text-sm font-extrabold text-[#065F46]">
                  <span>= Cash dépensable</span>
                  <span className="font-mono-num">{formatEuros(cashNetEnPocheImmediat)}</span>
                </div>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-[#065F46]/80">
              Disponible tout de suite sur votre compte courant (TVA ensuite à l’achat).
            </p>
          </div>

          <div className="rounded-xl border border-[#FDE68A] bg-[#FFFBEB]/80 p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-[#78350F]">
                <Lock className="h-4 w-4 text-[#B45309]" />
                <span>2B. En Holding ({demoHoldingPct} % bloqué)</span>
              </div>
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#44403C]">Remonté en holding</span>
                  <span className="font-mono-num font-semibold">{formatEuros(partEnHoldingBrut)}</span>
                </div>
                <div className="flex justify-between text-[#B45309]">
                  <span>− Mère-Fille (1,25 % immédiat)</span>
                  <span className="font-mono-num font-bold">−{formatEuros(impotHoldingImmediat)}</span>
                </div>
                <div className="flex justify-between font-bold text-[#141413]">
                  <span>= Réserve bloquée en holding</span>
                  <span className="font-mono-num">{formatEuros(reserveBloqueeHolding)}</span>
                </div>
                <div className="pt-2 border-t border-[#FDE68A] flex justify-between text-[#BE123C]">
                  <span>Impôt si sortie future vers poche :</span>
                  <span className="font-mono-num font-bold">−{formatEuros(impotLatentSortieHolding)}</span>
                </div>
                <div className="flex justify-between text-[11px] font-bold text-[#44403C]">
                  <span>Net final si tout est sorti :</span>
                  <span className="font-mono-num">{formatEuros(cashFinalSiSortieHolding)}</span>
                </div>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-[#78350F]">
              L’argent en holding n’est pas du pouvoir d’achat personnel : c’est un différé d’impôt pour réinvestir.
            </p>
          </div>
        </div>
      </section>

      {/* SCHÉMA FINANCE 2 : EFFET BERNARD ARNAULT */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs space-y-5">
        <div className="border-b border-[#EFECE4] pb-3">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
            Finance boursière · Valorisation ≠ Cash
          </div>
          <h3 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
            « L’Effet Bernard Arnault » : Pourquoi la Valeur d’une Entreprise ≠ du Vrai Argent
          </h3>
          <p className="text-xs text-[#57534E] mt-0.5">
            Si un fondateur tente de vendre 100 % de ses actions d’un coup, l’offre dépasse la demande (le cours chute) ET l’État prélève PFU + CEHR sur la cession réelle.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="valo-slider" className="font-semibold text-[#44403C]">
                Valorisation « papier » des actions
              </label>
              <span className="font-mono-num font-bold text-[#141413]">
                {demoValoM.toLocaleString('fr-FR')} M€
              </span>
            </div>
            <input
              id="valo-slider"
              type="range"
              min={1}
              max={500}
              step={1}
              value={demoValoM}
              onChange={(e) => setDemoValoM(Number(e.target.value))}
              className="w-full fiscal-slider"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="decote-slider" className="font-semibold text-[#44403C]">
                Décote de marché si vente massive
              </label>
              <span className="font-mono-num font-bold text-[#7C3AED]">
                −{demoDecotePct} %
              </span>
            </div>
            <input
              id="decote-slider"
              type="range"
              min={0}
              max={50}
              step={5}
              value={demoDecotePct}
              onChange={(e) => setDemoDecotePct(Number(e.target.value))}
              className="w-full fiscal-slider"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex h-10 w-full rounded-xl overflow-hidden border border-[#D6D0C4] text-xs font-bold">
            <div
              className="bg-[#15803D] text-white flex items-center justify-center px-2 transition-all duration-300"
              style={{ width: `${(cashReelArnault / valoEuros) * 100}%` }}
            >
              Vrai cash : {formatPct((cashReelArnault / valoEuros) * 100, 0)}
            </div>
            <div
              className="bg-[#BE123C] text-white flex items-center justify-center px-2 border-l border-white/50 transition-all duration-300"
              style={{ width: `${(impotPlusValueCession / valoEuros) * 100}%` }}
            >
              Impôt cession : {formatPct((impotPlusValueCession / valoEuros) * 100, 0)}
            </div>
            {demoDecotePct > 0 && (
              <div
                className="bg-[#7C3AED] text-white flex items-center justify-center px-2 border-l border-white/50 transition-all duration-300"
                style={{ width: `${demoDecotePct}%` }}
              >
                Décote : {demoDecotePct}%
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-4 text-xs">
            <div className="rounded-xl border border-[#E4DFD5] bg-[#FAF8F4] p-3">
              <div className="text-[#78716C]">1. Valeur papier affichée</div>
              <div className="font-mono-num text-base font-extrabold text-[#141413] mt-0.5">
                {formatEuros(valoEuros)}
              </div>
            </div>
            <div className="rounded-xl border border-[#DDD6FE] bg-[#F5F3FF] p-3">
              <div className="text-[#6D28D9] inline-flex items-center gap-1">
                <TrendingDown className="h-3.5 w-3.5" />
                <span>2. Décote liquidité (−{demoDecotePct}%)</span>
              </div>
              <div className="font-mono-num text-base font-extrabold text-[#5B21B6] mt-0.5">
                −{formatEuros(perteLiquidite)}
              </div>
            </div>
            <div className="rounded-xl border border-[#FECDD3] bg-[#FFF1F2] p-3">
              <div className="text-[#9F1239]">3. Impôt cession (PFU+CEHR)</div>
              <div className="font-mono-num text-base font-extrabold text-[#BE123C] mt-0.5">
                −{formatEuros(impotPlusValueCession)}
              </div>
            </div>
            <div className="rounded-xl border border-[#A7F3D0] bg-[#ECFDF5] p-3">
              <div className="text-[#065F46] font-bold">4. Vrai cash encaissé</div>
              <div className="font-mono-num text-base font-extrabold text-[#15803D] mt-0.5">
                {formatEuros(cashReelArnault)}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SCHÉMA 6 · Scanner des prix TTC en France (2026) */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 sm:p-6 shadow-xs">
        <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
          Schéma 6 · Scanner des prix TTC en France (2026)
        </div>
        <h3 className="font-editorial text-xl font-bold text-[#141413] mt-0.5 mb-4">
          Radiographie des Taxes Cachées dans Vos Achats Quotidiens
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Carburant */}
          <div className="p-4 rounded-xl bg-[#FAF8F4] border border-[#E4DFD5]">
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-[#141413]">
                1 litre de carburant ({ev.carburantPrixLitre.toFixed(2).replace('.', ',')} €)
              </span>
              <span className="text-xs font-mono-num font-extrabold text-[#BE123C]">
                {formatPct(ev.carburantTaxPct)} de taxes
              </span>
            </div>
            <div className="h-6 rounded-lg overflow-hidden flex text-[10px] font-mono-num font-bold text-white">
              <div
                style={{ width: `${(ev.carburantHtPur / ev.carburantPrixLitre) * 100}%` }}
                className="bg-[#15803D] flex items-center justify-center"
              >
                HT {(ev.carburantHtPur * 100).toFixed(0)}c
              </div>
              <div
                style={{ width: `${(ev.carburantAccise / ev.carburantPrixLitre) * 100}%` }}
                className="bg-[#D97706] border-l border-white flex items-center justify-center"
              >
                TICPE {(ev.carburantAccise * 100).toFixed(0)}c
              </div>
              <div
                style={{ width: `${((ev.carburantTvaSurAccise + ev.carburantTvaSurProduit) / ev.carburantPrixLitre) * 100}%` }}
                className="bg-[#BE123C] border-l border-white flex items-center justify-center"
              >
                TVA
              </div>
            </div>
            <p className="mt-2 text-[11px] text-[#57534E]">
              Dont TVA calculée y compris sur la taxe TICPE elle-même (+{(ev.carburantTvaSurAccise * 100).toFixed(0)} centimes de « taxe sur la taxe »).
            </p>
          </div>

          {/* Tabac */}
          <div className="p-4 rounded-xl bg-[#FAF8F4] border border-[#E4DFD5]">
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-[#141413]">
                1 paquet de tabac ({ev.tabacPrixPaquet.toFixed(2).replace('.', ',')} €)
              </span>
              <span className="text-xs font-mono-num font-extrabold text-[#BE123C]">
                {formatPct(ev.tabacTaxPct)} de taxes
              </span>
            </div>
            <div className="h-6 rounded-lg overflow-hidden flex text-[10px] font-mono-num font-bold text-white">
              <div
                style={{ width: `${(ev.tabacHtPur / ev.tabacPrixPaquet) * 100}%` }}
                className="bg-[#15803D] flex items-center justify-center"
              >
                HT
              </div>
              <div
                style={{ width: `${(ev.tabacAccise / ev.tabacPrixPaquet) * 100}%` }}
                className="bg-[#D97706] border-l border-white flex items-center justify-center"
              >
                Accise {ev.tabacAccise.toFixed(2)} €
              </div>
              <div
                style={{ width: `${(ev.tabacTva / ev.tabacPrixPaquet) * 100}%` }}
                className="bg-[#BE123C] border-l border-white flex items-center justify-center"
              >
                TVA
              </div>
            </div>
            <p className="mt-2 text-[11px] text-[#57534E]">
              Plus de 82 % du prix au bureau de tabac revient directement à la Sécu (CNAM) et à l’État.
            </p>
          </div>

          {/* Électricité */}
          <div className="p-4 rounded-xl bg-[#FAF8F4] border border-[#E4DFD5]">
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-[#141413]">
                Facture électricité annuelle ({formatEuros(ev.electriciteFactureTtc)})
              </span>
              <span className="text-xs font-mono-num font-extrabold text-[#BE123C]">
                {formatPct(ev.electriciteTaxPct)} de taxes
              </span>
            </div>
            <div className="h-6 rounded-lg overflow-hidden flex text-[10px] font-mono-num font-bold text-white">
              <div
                style={{ width: `${100 - ev.electriciteTaxPct}%` }}
                className="bg-[#15803D] flex items-center justify-center"
              >
                Énergie &amp; Réseau HT
              </div>
              <div
                style={{ width: `${ev.electriciteTaxPct}%` }}
                className="bg-[#BE123C] border-l border-white flex items-center justify-center"
              >
                Accise + CTA + TVA
              </div>
            </div>
            <p className="mt-2 text-[11px] text-[#57534E]">
              Accise 33,70 €/MWh + Contribution Tarifaire d’Acheminement + TVA 20 % sur conso et accise.
            </p>
          </div>

          {/* Assurances */}
          <div className="p-4 rounded-xl bg-[#FAF8F4] border border-[#E4DFD5]">
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-[#141413]">
                Assurances Auto, Habitation &amp; Mutuelle ({formatEuros(ev.assurancesTotalTtc)})
              </span>
              <span className="text-xs font-mono-num font-extrabold text-[#BE123C]">
                {formatPct(ev.assurancesTaxPct)} de taxes
              </span>
            </div>
            <div className="h-6 rounded-lg overflow-hidden flex text-[10px] font-mono-num font-bold text-white">
              <div
                style={{ width: `${100 - ev.assurancesTaxPct}%` }}
                className="bg-[#15803D] flex items-center justify-center"
              >
                Couverture HT
              </div>
              <div
                style={{ width: `${ev.assurancesTaxPct}%` }}
                className="bg-[#BE123C] border-l border-white flex items-center justify-center"
              >
                TSCA / TSA / Cat-Nat
              </div>
            </div>
            <p className="mt-2 text-[11px] text-[#57534E]">
              Pas de TVA sur les assurances, mais des taxes dédiées de 9 % à 33 % (TSCA, TSA mutuelles, Cat-Nat, attentats FGTI).
            </p>
          </div>
        </div>
      </section>

      {/* SCHÉMA 7 & SCHÉMA 8 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Schéma 7 · Le Test du Billet de +100 € */}
        <section className="lg:col-span-5 bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6 flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
              Schéma 7 · Taux marginal réel
            </div>
            <h3 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
              Le Test du Billet de +100 €
            </h3>
            <p className="text-xs text-[#57534E] mt-1">
              À votre niveau ({billetTest.contextLabel}), si l’entreprise ajoute <strong>+100 €</strong> de valeur sur la table :
            </p>

            <div className="mt-4 p-3.5 rounded-2xl bg-[#FAF8F4] border-2 border-[#D6D0C4]">
              <div className="flex items-baseline justify-between mb-2">
                <span className="text-[11px] font-bold uppercase text-[#57534E]">
                  +100 € créés en plus
                </span>
                <span className="text-xs font-mono-num font-extrabold text-[#15803D]">
                  = +{billetTest.resteNetPoche.toFixed(1).replace('.', ',')} € en poche
                </span>
              </div>

              <div className="h-11 w-full rounded-xl overflow-hidden flex border border-[#CBC4B6] shadow-inner">
                {billetTest.segments.map((seg) => (
                  <div
                    key={seg.label}
                    style={{ width: `${seg.val}%`, backgroundColor: seg.color }}
                    className="h-full border-r border-white/50 flex items-center justify-center overflow-hidden"
                    title={`${seg.label} : −${seg.val.toFixed(1).replace('.', ',')} €`}
                  >
                    {seg.val >= 9 && (
                      <span className="text-[10px] font-mono-num font-bold text-white">
                        −{Math.round(seg.val)}€
                      </span>
                    )}
                  </div>
                ))}
                <div
                  style={{ width: `${billetTest.resteNetPoche}%` }}
                  className="h-full bg-[#15803D] flex items-center justify-center overflow-hidden"
                >
                  <span className="text-xs font-mono-num font-extrabold text-white px-1">
                    +{Math.round(billetTest.resteNetPoche)}€
                  </span>
                </div>
              </div>

              <div className="mt-3 space-y-1.5">
                {billetTest.segments.map((seg) => (
                  <div
                    key={seg.label}
                    className="flex items-center justify-between text-[11.5px]"
                  >
                    <span className="flex items-center gap-1.5 text-[#44403C]">
                      <span
                        className="w-2.5 h-2.5 rounded-[3px] shrink-0"
                        style={{ backgroundColor: seg.color }}
                      />
                      {seg.label}
                    </span>
                    <span className="font-mono-num font-bold text-[#BE123C]">
                      −{seg.val.toFixed(1).replace('.', ',')} €
                    </span>
                  </div>
                ))}
                <div className="flex items-center justify-between text-xs font-extrabold pt-1.5 border-t border-[#E4DFD5] text-[#15803D]">
                  <span>Vrai gain net de pouvoir d’achat</span>
                  <span className="font-mono-num">
                    +{billetTest.resteNetPoche.toFixed(1).replace('.', ',')} € / 100 €
                  </span>
                </div>
                {billetTest.deltaDroitsRetraite > 0 && (
                  <div className="flex items-center justify-between text-[11px] text-[#1E3A8A] pt-1">
                    <span>+ Droits retraite/chômage acquis en plus</span>
                    <span className="font-mono-num font-bold">
                      +{((billetTest.deltaDroitsRetraite / billetTest.deltaSuperBrut) * 100).toFixed(1).replace('.', ',')} €
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <p className="mt-3 text-[11px] text-[#78716C]">
            Taux marginal réel sur le prochain euro :{' '}
            <strong className="font-mono-num text-[#141413]">
              {(100 - billetTest.resteNetPoche).toFixed(1).replace('.', ',')} %
            </strong>{' '}
            (contre {formatPct(result.tauxPrelevementReelPct)} en taux moyen global).
          </p>
        </section>

        {/* Schéma 8 · Courbe complète du travail en France (2026) */}
        <section className="lg:col-span-7 bg-white rounded-2xl border border-[#E4DFD5] shadow-xs p-5 sm:p-6 flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#78716C]">
              Schéma 8 · Courbe complète du travail en France (2026)
            </div>
            <h3 className="font-editorial text-xl font-bold text-[#141413] mt-0.5">
              Comment Évoluent les Impôts de 1 200 € à 25 000 € Brut/Mois
            </h3>
            <p className="text-xs text-[#57534E] mt-0.5 mb-3">
              Observez la <strong>TVA régressive</strong>, le <strong>bond des charges à 1,6 SMIC</strong> (fin Fillon), l’<strong>IR progressif</strong> et l’effet <strong>100 % aides/retraite/santé</strong>.
            </p>

            <svg
              viewBox={`0 0 ${svgW} ${svgH}`}
              className="w-full h-auto select-none"
              role="img"
              aria-label="Courbe du taux de prélèvement brut et net après aides et droits acquis de 1 200 € à 25 000 € brut/mois"
            >
              {[-20, 0, 20, 40, 60].map((val) => (
                <g key={val}>
                  <line
                    x1={padL}
                    y1={mapY(val)}
                    x2={svgW - padR}
                    y2={mapY(val)}
                    stroke={val === 0 ? '#CBC4B6' : '#ECE8DF'}
                    strokeWidth={val === 0 ? 1.5 : 1}
                  />
                  <text
                    x={padL - 6}
                    y={mapY(val) + 3.5}
                    textAnchor="end"
                    className="fill-[#78716C] text-[9.5px] font-mono-num"
                  >
                    {val}%
                  </text>
                </g>
              ))}

              <line
                x1={xFillon}
                y1={padT}
                x2={xFillon}
                y2={svgH - padB}
                stroke="#64748B"
                strokeWidth={1}
                strokeDasharray="3 3"
              />
              <text
                x={xFillon + 4}
                y={padT + 9}
                className="fill-[#475569] text-[9px] font-semibold"
              >
                1,6 SMIC (fin Fillon)
              </text>

              <path d={areaBrut} fill="#BE123C" fillOpacity={0.07} />
              <path d={pathTva} fill="none" stroke="#D97706" strokeWidth={2} strokeDasharray="4 3" />
              <path d={pathIr} fill="none" stroke="#7C3AED" strokeWidth={2} />
              <path d={pathNet100} fill="none" stroke="#15803D" strokeWidth={2.5} />
              <path d={pathBrut} fill="none" stroke="#BE123C" strokeWidth={3} />

              {hasSalaryCurvePoint && (
                <>
                  <circle
                    cx={userX}
                    cy={userY}
                    r={5.5}
                    fill="#141413"
                    stroke="#FFFFFF"
                    strokeWidth={2}
                  />
                  <rect
                    x={Math.min(svgW - 118, Math.max(padL + 2, userX - 54))}
                    y={Math.max(4, userY - 26)}
                    width={108}
                    height={18}
                    rx={6}
                    fill="#141413"
                  />
                  <text
                    x={Math.min(svgW - 64, Math.max(padL + 56, userX))}
                    y={Math.max(16, userY - 14)}
                    textAnchor="middle"
                    className="fill-white text-[9.5px] font-bold font-mono-num"
                  >
                    Vous : {formatPct(result.tauxPrelevementReelPct)}
                  </text>
                </>
              )}

              {[1200, 1802, 3000, 5000, 10000, 25000].map((m) => (
                <text
                  key={m}
                  x={mapX(m)}
                  y={svgH - 10}
                  textAnchor="middle"
                  className="fill-[#57534E] text-[9.5px] font-mono-num font-semibold"
                >
                  {m === 1802 ? 'SMIC' : formatEuros(m, true)}
                </text>
              ))}
            </svg>
          </div>

          <div className="flex flex-wrap gap-x-4 gap-y-1 pt-2 border-t border-[#EFECE4] text-[11px]">
            <span className="inline-flex items-center gap-1.5 font-bold text-[#BE123C]">
              <span className="w-4 h-0.5 bg-[#BE123C] inline-block" /> Taux brut total (%)
            </span>
            <span className="inline-flex items-center gap-1.5 font-bold text-[#15803D]">
              <span className="w-4 h-0.5 bg-[#15803D] inline-block" /> Taux net 100 % (après aides, santé, retraite)
            </span>
            <span className="inline-flex items-center gap-1.5 text-[#7C3AED] font-semibold">
              <span className="w-4 h-0.5 bg-[#7C3AED] inline-block" /> IR progressif
            </span>
            <span className="inline-flex items-center gap-1.5 text-[#D97706] font-semibold">
              <span className="w-4 h-0.5 bg-[#D97706] inline-block border-b border-dashed" /> TVA &amp; taxes conso
            </span>
          </div>
        </section>
      </div>

      {/* Séparation Société vs Perso sur le profil actif */}
      <section className="rounded-2xl border border-[#E4DFD5] bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-editorial text-lg font-bold text-[#141413]">
              Sur votre profil actif : Perso vs Société/Holding (100 % inclus par défaut)
            </h3>
            <p className="text-xs text-[#57534E]">
              Vous pouvez comparer ci-dessous la part personnelle et la part payée par l’entité économique.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="inline-flex items-center gap-2 rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-3 py-1.5 text-xs font-semibold text-[#141413] cursor-pointer">
              <input
                type="checkbox"
                checked={state.inclureTaxesSocieteEtHolding}
                onChange={(e) =>
                  onChange((prev) => ({
                    ...prev,
                    inclureTaxesSocieteEtHolding: e.target.checked,
                  }))
                }
                className="rounded border-[#CBC4B6] accent-[#1E3A8A]"
              />
              <span>Inclure à 100 % Société + Holding</span>
            </label>
            {state.inclureTaxesSocieteEtHolding && (
              <label className="inline-flex items-center gap-2 rounded-lg border border-[#DDD6FE] bg-[#F5F3FF] px-3 py-1.5 text-xs font-semibold text-[#5B21B6] cursor-pointer">
                <input
                  type="checkbox"
                  checked={state.inclureImpotsLatentsHolding}
                  onChange={(e) =>
                    onChange((prev) => ({
                      ...prev,
                      inclureImpotsLatentsHolding: e.target.checked,
                    }))
                  }
                  className="rounded border-[#C4B5FD] accent-[#6D28D9]"
                />
                <span>Compter impôts en attente</span>
              </label>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3 text-xs">
          <div className="rounded-xl border border-[#BFDBFE] bg-[#EFF6FF]/60 p-4">
            <div className="font-bold text-[#1E3A8A] text-sm">
              Impôts &amp; Cotisations Personnels
            </div>
            <div className="font-mono-num text-2xl font-extrabold text-[#1E3A8A] my-1">
              {formatEuros(result.impotsPersonnelsSeuls)}
            </div>
            <p className="text-[#44403C]">
              Cotisations travail, IR, Flat Tax sur dividendes sortis en poche, foncier, IFI et TVA.
            </p>
          </div>

          <div className="rounded-xl border border-[#FDE68A] bg-[#FFFBEB]/70 p-4">
            <div className="font-bold text-[#78350F] text-sm">
              Société &amp; Holding (immédiats)
            </div>
            <div className="font-mono-num text-2xl font-extrabold text-[#B45309] my-1">
              {formatEuros(result.impotsEntrepriseImmediats)}
            </div>
            <p className="text-[#78350F]">
              IS société, CFE/CVAE, QPFC 1,25 %, IS trésorerie holding (25 %) et taxe actifs passifs (2 %).
            </p>
          </div>

          <div className="rounded-xl border border-[#DDD6FE] bg-[#F5F3FF]/80 p-4">
            <div className="font-bold text-[#5B21B6] text-sm">
              Impôts en attente (Holding &amp; Filiale)
            </div>
            <div className="font-mono-num text-2xl font-extrabold text-[#6D28D9] my-1">
              {formatEuros(result.holdingAndValuation.totalImpotsEnAttenteFlux)}
            </div>
            <p className="text-[#5B21B6]">
              PFU 31,4 % + CEHR + CDHR latents sur réserves ; il reste{' '}
              <strong className="font-mono-num">
                {formatEuros(result.holdingAndValuation.reservesNettesApresImpotsEnAttente)}
              </strong>{' '}
              nets en société/holding
              {result.holdingAndValuation.impotLatentReport150OBTer > 0
                ? ` (+ ${formatEuros(result.holdingAndValuation.impotLatentReport150OBTer)} stock 150-0 B ter).`
                : '.'}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
