/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo, useState } from 'react';
import { ExpertAudit } from './components/ExpertAudit';
import { FinanceLab } from './components/FinanceLab';
import { AppViewTab, Header } from './components/Header';
import { HeroSummary } from './components/HeroSummary';
import { LiberationTimeline } from './components/LiberationTimeline';
import { PresetBar } from './components/PresetBar';
import { QuickControls } from './components/QuickControls';
import { SankeyFlowChart } from './components/SankeyFlowChart';
import { SocialPanorama } from './components/SocialPanorama';
import { TaxRegistry } from './components/TaxRegistry';
import { WaterfallAndGrid } from './components/WaterfallAndGrid';
import { PRESET_PROFILES } from './data/presets';
import { runSimulation } from './engine/taxEngine';
import { PresetProfile, SimulationState } from './types/fiscal';
import { formatEuros, formatPct } from './utils/formatters';

const DEFAULT_PRESET =
  PRESET_PROFILES.find((p) => p.id === 'salarie_median') ?? PRESET_PROFILES[0];

export default function App() {
  const [activeTab, setActiveTab] = useState<AppViewTab>('simulateur');
  const [activePresetId, setActivePresetId] = useState<string>(DEFAULT_PRESET.id);
  const [simState, setSimState] = useState<SimulationState>(DEFAULT_PRESET.state);
  const [beginnerMode, setBeginnerMode] = useState<boolean>(true);

  const result = useMemo(() => runSimulation(simState), [simState]);

  const handleSelectPreset = (preset: PresetProfile) => {
    setActivePresetId(preset.id);
    setSimState(preset.state);
  };

  const handleReset = () => {
    const currentPreset =
      PRESET_PROFILES.find((p) => p.id === activePresetId) ?? DEFAULT_PRESET;
    setSimState(currentPreset.state);
  };

  return (
    <div className="min-h-screen bg-[#F8F6F1] text-[#141413] flex flex-col">
      <Header
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        activeTaxCount={result.activeTaxCount}
        totalCatalogCount={result.totalCatalogCount}
        beginnerMode={beginnerMode}
        onToggleBeginnerMode={() => setBeginnerMode((b) => !b)}
        onReset={handleReset}
      />

      <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-5 sm:px-6 space-y-5">
        {activeTab === 'simulateur' ? (
          <>
            <PresetBar
              presets={PRESET_PROFILES}
              activePresetId={activePresetId}
              onSelectPreset={handleSelectPreset}
              beginnerMode={beginnerMode}
            />

            <HeroSummary
              state={simState}
              result={result}
              beginnerMode={beginnerMode}
              onToggleInclureSociete={(val) =>
                setSimState((prev) => ({ ...prev, inclureTaxesSocieteEtHolding: val }))
              }
              onToggleImpotsLatentsHolding={(val) =>
                setSimState((prev) => ({ ...prev, inclureImpotsLatentsHolding: val }))
              }
              onOpenFinanceLab={() => setActiveTab('finance')}
            />
          </>
        ) : (
          <div className="rounded-xl border border-[#E4DFD5] bg-white px-4 py-2.5 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="font-semibold text-[#6B675E]">Profil actif :</span>
              <select
                aria-label="Changer de profil actif"
                value={activePresetId}
                onChange={(e) => {
                  const found = PRESET_PROFILES.find((p) => p.id === e.target.value);
                  if (found) handleSelectPreset(found);
                }}
                className="rounded-lg border border-[#D6D0C4] bg-[#FAF8F4] px-2.5 py-1 text-xs font-bold text-[#141413]"
              >
                {PRESET_PROFILES.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono-num">
              <span>
                Impôts : <strong className="text-[#BE123C]">{formatEuros(result.totalPrelevements)}</strong> ({formatPct(result.tauxPrelevementReelPct)})
              </span>
              <span>
                Aides &amp; droits 100 % : <strong className="text-[#15803D]">{formatEuros(result.aides.totalAidesEtServicesComplet, true)}</strong>
              </span>
              <span>
                Taux net intégral :{' '}
                <strong className={result.tauxNetApresAidesPct < 0 ? 'text-[#15803D]' : 'text-[#1E3A8A]'}>
                  {formatPct(result.tauxNetApresAidesPct, 1, true)}
                </strong>
              </span>
              <span>
                Reste poche : <strong className="text-[#141413]">{formatEuros(result.resteNetApresAidesEtTaxes)}</strong>
              </span>
            </div>
          </div>
        )}

        {activeTab === 'simulateur' && (
          <>
            <SankeyFlowChart
              state={simState}
              result={result}
              beginnerMode={beginnerMode}
            />

            <div className="grid grid-cols-1 gap-5 xl:grid-cols-12 items-start">
              <div className="xl:col-span-4">
                <QuickControls
                  state={simState}
                  result={result}
                  beginnerMode={beginnerMode}
                  onChange={setSimState}
                />
              </div>

              <div className="xl:col-span-8 space-y-5">
                <WaterfallAndGrid
                  state={simState}
                  result={result}
                  beginnerMode={beginnerMode}
                />

              <LiberationTimeline
                result={result}
                beginnerMode={beginnerMode}
              />

              {/* Répartition rapide par 8 familles fiscales */}
              <section className="rounded-xl border border-[#E4DFD5] bg-white p-4 sm:p-5 shadow-xs">
                <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
                  <h3 className="font-serif text-base font-bold text-[#141413]">
                    Les 8 familles d’impôts sur votre profil
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActiveTab('registre')}
                    className="text-xs font-semibold text-[#1E3A8A] hover:underline underline-offset-2 cursor-pointer"
                  >
                    Voir les {result.totalCatalogCount} lignes détaillées
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
                  {result.families.map((fam) => (
                    <div
                      key={fam.id}
                      className="rounded-lg border border-[#E4DFD5] bg-[#FAF8F4]/70 p-3 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-bold text-[#141413]">
                            {fam.shortLabel}
                          </span>
                          <span
                            className="h-2.5 w-2.5 rounded-xs shrink-0"
                            style={{ backgroundColor: fam.color }}
                          />
                        </div>
                        <div className="mt-1 font-mono-num text-base font-bold text-[#141413]">
                          {formatEuros(fam.amount)}
                        </div>
                      </div>
                      <div className="mt-1 text-[11px] text-[#6B675E]">
                        {formatPct(fam.shareOfTotalTax)} des taxes ·{' '}
                        {formatPct(fam.shareOfWealth)} richesse
                      </div>
                    </div>
                  ))}
                </div>
              </section>
              </div>
            </div>
          </>
        )}

        {activeTab === 'finance' && (
          <FinanceLab
            state={simState}
            result={result}
            onChange={setSimState}
          />
        )}

        {activeTab === 'panorama' && (
          <SocialPanorama
            activePresetId={activePresetId}
            onSelectPreset={(preset) => {
              handleSelectPreset(preset);
              setActiveTab('simulateur');
            }}
          />
        )}

        {activeTab === 'audit' && (
          <ExpertAudit
            state={simState}
            result={result}
            onChange={setSimState}
          />
        )}

        {activeTab === 'registre' && (
          <TaxRegistry
            state={simState}
            result={result}
            beginnerMode={beginnerMode}
          />
        )}
      </main>

      <footer className="border-t border-[#E4DFD5] bg-[#FAF8F4] py-4 px-4 sm:px-6 text-xs text-[#6B675E] no-print">
        <div className="mx-auto max-w-[1440px] flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
          <p>
            L’Addition Fiscale — Simulateur pédagogique 2026 (barèmes IR, LFSS 2026, PFU 31,4 %, CAF/CROUS, services en nature &amp; fiscalité sociétés/holdings).
          </p>
          <p>
            Calculs indicatifs à vocation éducative ; équilibre comptable à 0 € ; ne remplace pas un avis officiel (impots.gouv.fr).
          </p>
        </div>
      </footer>
    </div>
  );
}
