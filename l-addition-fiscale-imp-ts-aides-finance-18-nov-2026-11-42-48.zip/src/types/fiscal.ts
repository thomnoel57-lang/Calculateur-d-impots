export type StatutPrincipal =
  | 'etudiant'
  | 'apprenti'
  | 'rsa_inactif'
  | 'chomeur'
  | 'salarie_non_cadre'
  | 'salarie_cadre'
  | 'fonctionnaire'
  | 'dirigeant_sas'
  | 'independant_tns'
  | 'micro_entrepreneur'
  | 'retraite'
  | 'rentier';

export type StatutConjoint =
  | 'aucun'
  | 'salarie_non_cadre'
  | 'salarie_cadre'
  | 'fonctionnaire'
  | 'independant_tns'
  | 'micro_entrepreneur'
  | 'retraite'
  | 'chomeur';

export type SituationFamiliale = 'celibataire' | 'couple';
export type StatutLogement = 'locataire' | 'proprietaire' | 'heberge' | 'residence_crous';
export type ZoneGeo = 'paris_idf' | 'grande_ville' | 'ville_moyenne' | 'rural';
export type TypeVehicule = 'aucune' | 'essence' | 'diesel' | 'hybride' | 'electrique' | 'e85';
export type TailleEntreprise = 'moins_11' | '11_49' | '50_plus';
export type ProfilConso = 'frugal' | 'equilibre' | 'bon_vivant' | 'intense';

export type TaxFamilyId =
  | 'patronales'
  | 'salariales_sociales'
  | 'revenu'
  | 'tva_conso'
  | 'energie_mobilite'
  | 'accises_assurances'
  | 'immobilier_patrimoine'
  | 'capital_entreprise';

export type BeneficiaryId = 'etat' | 'secu' | 'collectivites' | 'organismes';
export type VisibilityLevel = 'visible' | 'semi_visible' | 'cache';
export type TaxIncidence = 'personnel' | 'entreprise_societe' | 'holding_en_attente';

export type PillarId =
  | 'travail'
  | 'conso_tva'
  | 'energie_eau'
  | 'auto_transports'
  | 'habitudes_assurances'
  | 'immobilier'
  | 'capital_transmission'
  | 'entreprise';

export interface FiscalFamilyMeta {
  id: TaxFamilyId;
  label: string;
  shortLabel: string;
  plainExplanation: string;
  color: string;
  lightBg: string;
  borderColor: string;
  description: string;
}

export interface FiscalCatalogEntry {
  id: string;
  name: string;
  shortName: string;
  family: TaxFamilyId;
  pillar: PillarId;
  beneficiary: BeneficiaryId;
  visibility: VisibilityLevel;
  incidence: TaxIncidence;
  rate2026: string;
  legalRef: string;
  description: string;
  simpleSummary: string;
  isMemoOnly?: boolean;
  isOneOff?: boolean;
}

export interface ExpertOverrides {
  depensesTva20?: number;
  depensesTva10?: number;
  depensesTva55?: number;
  depensesTva21?: number;
  achatsHorsUeDouane?: number;
  achatsHighTechNeufs?: number;
  abonnementsTelecomStreaming?: number;
  achatsEquipementMaison?: number;

  consoElectriciteKwh?: number;
  abonnementElectriciteAnnuelHt?: number;
  consoGazKwh?: number;
  abonnementGazAnnuelHt?: number;
  consoFioulLitres?: number;
  consoEauM3?: number;
  teomAnnuelle?: number;
  reomAnnuelle?: number;
  taxeBalayageAnnuelle?: number;
  dechetsTonnesIndirects?: number;

  consoCarburantLitres100?: number;
  prixCarburantTtcLitre?: number;
  achatVehiculeCetteAnnee?: number;
  chevauxFiscauxVehicule?: number;
  emissionsCo2Gkm?: number;
  poidsVehiculeKg?: number;
  vehiculeNeuf?: number;
  peagesAutorouteAnnuelsTtc?: number;
  transportsCommunTrainTtc?: number;
  volsEuropeEcoNb?: number;
  volsLongCourrierEcoNb?: number;
  volsAffairesNb?: number;
  volsOspCorseNb?: number;
  traverseesMaritimesNb?: number;
  nuiteesHotelLocationFrance?: number;
  tarifTaxeSejourNuit?: number;
  timbresFiscauxAmendesAnnuels?: number;

  prixPaquetCigarettes?: number;
  consoVinLitresAn?: number;
  consoBiereLitresAn?: number;
  consoSpiritueuxLitresAn?: number;
  consoSodasSucresLitresAn?: number;
  consoSodasEdulcoresLitresAn?: number;
  consoEauxMineralesLitresAn?: number;
  primeAssuranceAutoTtc?: number;
  primeAssuranceHabitationTtc?: number;
  primeMutuelleSanteTtc?: number;
  primePrevoyanceAutresTtc?: number;
  nbContratsAssuranceBiens?: number;
  misesJeuxLoterieParisAn?: number;
  misesParisHippiquesCasinosAn?: number;
  depensesSpectaclesCinemaTtc?: number;

  taxeFonciereAnnuelle?: number;
  taxeHabitationSecondaire?: number;
  valeurLocativeLogementVacant?: number;
  anneesVacanceLogement?: number;
  patrimoineImmoNetIfi?: number;
  loyersNetsFonciersAnnuels?: number;
  regimeLocatifMeuble?: number;
  taxeMicroLogementsLoyersEleves?: number;
  plusValueImmoBrute?: number;
  dureeDetentionPvImmoAns?: number;
  achatImmobilierPrixAncien?: number;
  achatImmobilierPrixNeuf?: number;
  surfaceConstructionAmenagementM2?: number;
  cessionTerrainDevenuConstructibleGain?: number;
  taxeEnginsMaritimesLuxe?: number;

  optionBaremeCapital?: number;
  dividendesBrutsAnnuels?: number;
  interetsBrutsFiscalisesAnnuels?: number;
  gainsAssuranceVieRachat?: number;
  plusValuesMobilieresBrutes?: number;
  plusValuesCryptoBrutes?: number;
  achatsActionsFrancaisesTtf?: number;
  ventesMetauxPrecieuxOr?: number;
  montantSuccessionRecue?: number;
  lienSuccession?: number;
  assuranceVieDecesAvant70?: number;
  montantDonationRecue?: number;
  baseDroitsEnregistrementActes?: number;
  actifNetPartageDivorceIndivision?: number;
  exitTaxPlusValuesLatentes?: number;

  partDetentionSocietePct?: number;
  beneficeSocieteAvantIs?: number;
  chiffreAffairesEntreprise?: number;
  partRemonteeHoldingPct?: number;
  valorisationEntrepriseEstimee?: number;
  decoteLiquiditeCessionPct?: number;
  dividendesSortisDeHoldingPourPoche?: number;
  montantRachatActionsSociete?: number;
  cfeAnnuelle?: number;
  surfaceCommercialeTascomM2?: number;
  surfaceBureauxIdfPacaM2?: number;
  fraisChambreConsulaire?: number;
  tvsVehiculesSociete?: number;
  tgapActivitesPolluantesPro?: number;
  tlpePubliciteExterieure?: number;
  redevanceSacemPro?: number;
  iferReseauxEnergieTelecomPro?: number;
  actionsGratuitesBspceGains?: number;
  tauxVersementMobilitePct?: number;
  tresorerieAccumuleeHolding?: number;
  rendementTresorerieHoldingPct?: number;
  actifsNonOperationnelsHolding?: number;
  plusValuesEnReport150OBTer?: number;
  aidesPubliquesEntrepriseCirBpi?: number;
  gardeEnfantsFraisAnnuels?: number;
}

export interface SimulationState {
  statut: StatutPrincipal;
  salaireBrutAnnuel: number;
  salaireConjointBrutAnnuel: number;
  statutConjoint: StatutConjoint;
  situationFamiliale: SituationFamiliale;
  nbEnfants: number;
  nbEnfantsMoins3Ans: number;
  parentIsole: boolean;
  alsaceMoselle: boolean;
  tailleEntreprise: TailleEntreprise;
  employeurHorsTva: boolean;
  pensionRetraiteBruteAnnuelle: number;
  pensionConjointBruteAnnuelle: number;
  allocationChomageBruteAnnuelle: number;
  interessementParticipationAnnuel: number;
  reductionsCreditsImpot: number;
  echelonBourseCrous: number; // 0 = non boursier, 1..8 (0bis..7)
  ageMoins25Ans: boolean;
  beneficiaireAah: boolean;

  statutLogement: StatutLogement;
  logementSocialHlm: boolean;
  zoneGeo: ZoneGeo;
  surfaceLogementM2: number;
  loyerMensuelHorsCharges: number;
  mensualiteCreditImmo: number;
  chauffageGaz: boolean;
  chauffageFioul: boolean;

  typeVehicule: TypeVehicule;
  nbVehicules: number;
  kmAnnuels: number;

  tauxEpargnePct: number;
  fumeurPaquetsParSemaine: number;
  profilConso: ProfilConso;

  lisserTaxesPonctuelles: boolean;
  inclureTaxesSocieteEtHolding: boolean;
  inclureImpotsLatentsHolding: boolean;

  overrides: ExpertOverrides;
}

export interface ComputedTaxItem {
  entry: FiscalCatalogEntry;
  amount: number;
  baseAmount: number;
  effectiveRateOnBase: number;
  formulaNote: string;
}

export interface FamilyBreakdown {
  id: TaxFamilyId;
  label: string;
  shortLabel: string;
  color: string;
  lightBg: string;
  borderColor: string;
  amount: number;
  shareOfTotalTax: number;
  shareOfWealth: number;
  items: ComputedTaxItem[];
}

export interface AideItem {
  id: string;
  label: string;
  organisme: string;
  amount: number;
  explanation: string;
  category:
    | 'monetaire'
    | 'famille_logement'
    | 'education'
    | 'sante'
    | 'retraite_droits'
    | 'services_publics';
}

export interface AidesResult {
  totalAidesMonetaires: number;
  totalPrestationsEnNatureEtDroits: number;
  totalAidesEtServicesComplet: number;
  items: AideItem[];
  itemsEnNatureEtDroits: AideItem[];
  servicesPublicsEstimes: number;
  servicesPublicsNote: string;
}

export interface HoldingAndValuationBreakdown {
  beneficeAvantIs: number;
  impotSocietePayeParEntreprise: number;
  surtaxeIsGrandesEntreprises: number;
  taxesProductionEntreprise: number;
  beneficeNetApresIs: number;
  beneficeRetenuEnFiliale: number;
  montantRemonteEnHolding: number;
  impotMereFilleHolding: number;
  produitsFinanciersHoldingBruts: number;
  isSurProduitsFinanciersHolding: number;
  taxeActifsNonOperationnelsHolding: number;
  reserveRestantEnHolding: number;
  impotLatentSiSortieHolding: number;
  impotLatentSiSortieFiliale: number;
  impotLatentReport150OBTer: number;
  totalImpotsEnAttenteFlux: number;
  totalImpotsEnAttenteAvecStock150OBTer: number;
  reservesNettesApresImpotsEnAttente: number;
  montantSortiVersPoche: number;
  impotSortieFlatTaxCehr: number;
  cashNetRecuEnPocheDepuisCapital: number;
  valorisationPapierEstimee: number;
  decoteMarcheLiquiditeEuros: number;
  impotCessionSiVenteTotale: number;
  cashReelSiToutVendu: number;
  aidesPubliquesEntrepriseCirBpi: number;
}

export interface SimulationResult {
  richesseCreeeTotale: number;
  totalPrelevements: number;
  impotsPersonnelsSeuls: number;
  impotsEntrepriseImmediats: number;
  impotsEnAttenteHolding: number;
  impotsPayesParEntreprise: number;
  resteNetReelPur: number;
  resteNetApresAidesEtTaxes: number;
  tauxPrelevementReelPct: number;
  tauxNetApresAidesMonetairesPct: number;
  tauxNetApresAidesPct: number;
  ecartBalanceComptable: number;

  aides: AidesResult;
  holdingAndValuation: HoldingAndValuationBreakdown;

  etape1SuperBrutEtCreation: number;
  prelevEtape1SourceEntreprisePatronal: number;
  etape2RevenuBrutPersonnel: number;
  prelevEtape2CotisSalarialesCsgTns: number;
  etape3RevenuNetAvantImpots: number;
  prelevEtape3IrPfuCapitalTransmission: number;
  etape4RevenuDisponibleNet: number;
  prelevEtape4PatrimoineLocaux: number;
  prelevEtape5ConsommationTvaAccises: number;

  epargneNetteAnnuelle: number;
  consommationPureHorsTaxes: number;

  superBrutFoyer: number;
  brutFoyer: number;
  netAvantIrFoyer: number;
  netApresIrFoyer: number;
  reductionFillonAnnuelle: number;
  nombrePartsFiscales: number;
  revenuFiscalReference: number;
  tmiPct: number;
  tauxPasMoyenPct: number;
  pasMensuel: number;
  pfuTotalMemo: number;

  jourLiberationIndex: number;
  jourLiberationDate: string;
  joursPourEtat: number;
  joursPourVous: number;

  impotsVisibles: number;
  impotsSemiVisibles: number;
  impotsCaches: number;
  partImpotsCachesPct: number;

  parBeneficiaire: Record<BeneficiaryId, number>;
  families: FamilyBreakdown[];
  items: ComputedTaxItem[];
  itemsById: Record<string, ComputedTaxItem>;
  activeTaxCount: number;
  totalCatalogCount: number;

  effective: Required<ExpertOverrides>;
  overriddenKeys: Set<keyof ExpertOverrides>;

  everydayBreakdown: {
    carburantPrixLitre: number;
    carburantHtPur: number;
    carburantAccise: number;
    carburantTvaSurAccise: number;
    carburantTvaSurProduit: number;
    carburantTaxPct: number;
    electriciteFactureTtc: number;
    electriciteTaxesTotal: number;
    electriciteTaxPct: number;
    tabacPrixPaquet: number;
    tabacAccise: number;
    tabacTva: number;
    tabacHtPur: number;
    tabacTaxPct: number;
    assurancesTotalTtc: number;
    assurancesTaxesTotal: number;
    assurancesTaxPct: number;
  };
}

export interface PresetProfile {
  id: string;
  name: string;
  shortName: string;
  badge: string;
  incomeTag: string;
  category: 'modeste' | 'moyen' | 'aise' | 'riche' | 'special';
  accentColor: string;
  summary: string;
  fiscalInsight: string;
  state: SimulationState;
}
