import { ExpertOverrides, SimulationState } from '../types/fiscal';
import { clamp } from '../utils/formatters';

export interface EstimationContext {
  revenuNetDisponibleFoyer: number;
  revenuBrutReference: number;
}

export function computeInseeOverrides(
  state: SimulationState,
  ctx: EstimationContext
): Required<ExpertOverrides> {
  const { revenuNetDisponibleFoyer: net, revenuBrutReference: brut } = ctx;
  const isCouple = state.situationFamiliale === 'couple';
  const nbAdultes = isCouple ? 2 : 1;
  const nbEnfants = clamp(Math.round(state.nbEnfants), 0, 10);
  const uc = 1 + (isCouple ? 0.5 : 0) + nbEnfants * 0.35;

  const consoMult =
    state.profilConso === 'frugal'
      ? 0.78
      : state.profilConso === 'bon_vivant'
        ? 1.18
        : state.profilConso === 'intense'
          ? 1.38
          : 1.0;

  const epargneRatio = clamp(state.tauxEpargnePct / 100, 0, 0.85);
  const depenseTotaleTtc = Math.max(0, net * (1 - epargneRatio));

  const loyerOuCreditAnnuel =
    state.statutLogement === 'locataire' || state.statutLogement === 'residence_crous'
      ? state.loyerMensuelHorsCharges * 12
      : state.statutLogement === 'proprietaire'
        ? state.mensualiteCreditImmo * 12
        : 0;

  // Dépenses soumises à TVA (hors loyer exonéré, hors assurances sans TVA, hors tabac/énergie gérés à part)
  const budgetConsoCourante = Math.max(2200, depenseTotaleTtc - loyerOuCreditAnnuel * 0.92);

  // Répartition type INSEE selon niveau de vie et profil de consommation
  const partAlimentaire = clamp(0.32 - Math.min(0.18, net / 240000), 0.12, 0.38);
  const partRestauLoisirs =
    state.statut === 'rsa_inactif'
      ? 0.05
      : state.statut === 'etudiant'
        ? 0.12
        : 0.12 * consoMult;
  const partNormal20 = clamp(1 - partAlimentaire - partRestauLoisirs, 0.38, 0.74);

  const depensesTva20 = Math.round(budgetConsoCourante * partNormal20 * 0.74);
  const depensesTva10 = Math.round(budgetConsoCourante * partRestauLoisirs);
  const depensesTva55 = Math.round(budgetConsoCourante * partAlimentaire);
  const depensesTva21 = Math.round((450 + nbEnfants * 90) * nbAdultes * (net > 18000 ? 1 : 0.65));

  const achatsHorsUeDouane = Math.round(depensesTva20 * (state.statut === 'etudiant' ? 0.11 : 0.08));
  const achatsHighTechNeufs = Math.round(
    clamp(320 * uc + net * 0.008, 220, 4200) * consoMult
  );
  const abonnementsTelecomStreaming = Math.round(
    (state.statut === 'rsa_inactif' ? 320 : 540 * nbAdultes + 220) * consoMult
  );
  const achatsEquipementMaison = Math.round(clamp(net * 0.018, 180, 6500));

  // Énergie & Eau
  const surf = clamp(state.surfaceLogementM2, 12, 600);
  const surfCoeff = surf / 75;
  const kwhElecBase = state.chauffageGaz || state.chauffageFioul ? 2900 : 5800;
  const consoElectriciteKwh =
    state.statutLogement === 'heberge'
      ? 900
      : Math.round(kwhElecBase * surfCoeff * (0.75 + 0.25 * uc));
  const abonnementElectriciteAnnuelHt = state.statutLogement === 'heberge' ? 60 : 172;

  const consoGazKwh =
    state.chauffageGaz && state.statutLogement !== 'heberge'
      ? Math.round(9800 * surfCoeff * (0.85 + 0.15 * uc))
      : 0;
  const abonnementGazAnnuelHt = consoGazKwh > 0 ? 235 : 0;

  const consoFioulLitres =
    state.chauffageFioul && state.statutLogement !== 'heberge'
      ? Math.round(1350 * surfCoeff)
      : 0;

  const consoEauM3 =
    state.statutLogement === 'heberge' ? 28 : Math.round(42 * uc);

  const teomBase =
    state.zoneGeo === 'paris_idf'
      ? 290
      : state.zoneGeo === 'grande_ville'
        ? 250
        : state.zoneGeo === 'ville_moyenne'
          ? 210
          : 175;
  const teomAnnuelle =
    state.statutLogement === 'heberge' || state.statutLogement === 'residence_crous'
      ? 0
      : Math.round(teomBase * Math.max(0.65, surfCoeff));
  const reomAnnuelle = 0;
  const taxeBalayageAnnuelle =
    state.zoneGeo === 'paris_idf' && state.statutLogement === 'proprietaire' ? 65 : 0;
  const dechetsTonnesIndirects = Number((0.46 * uc).toFixed(2));

  // Auto, Carburants & Voyages
  const hasCar = state.typeVehicule !== 'aucune' && state.nbVehicules > 0;
  const consoCarburantLitres100 =
    state.typeVehicule === 'essence'
      ? 6.6
      : state.typeVehicule === 'diesel'
        ? 5.6
        : state.typeVehicule === 'hybride'
          ? 4.7
          : state.typeVehicule === 'e85'
            ? 8.4
            : 0;
  const prixCarburantTtcLitre =
    state.typeVehicule === 'essence'
      ? 1.79
      : state.typeVehicule === 'diesel'
        ? 1.71
        : state.typeVehicule === 'hybride'
          ? 1.79
          : state.typeVehicule === 'e85'
            ? 0.86
            : 0;

  const achatVehiculeCetteAnnee = hasCar && net > 22000 ? 1 : 0;
  const chevauxFiscauxVehicule =
    state.typeVehicule === 'electrique' ? 5 : net > 90000 ? 9 : 6;
  const emissionsCo2Gkm =
    state.typeVehicule === 'electrique'
      ? 0
      : state.typeVehicule === 'hybride'
        ? 102
        : net > 90000
          ? 142
          : 118;
  const poidsVehiculeKg =
    state.typeVehicule === 'electrique' ? 1820 : net > 90000 ? 1660 : 1340;
  const vehiculeNeuf = net > 65000 ? 1 : 0;

  const peagesAutorouteAnnuelsTtc = hasCar
    ? Math.round((state.kmAnnuels / 1000) * 18 * consoMult)
    : 0;

  const transportsCommunTrainTtc =
    state.zoneGeo === 'paris_idf'
      ? Math.round((state.statut === 'etudiant' ? 390 : 980) * nbAdultes)
      : state.zoneGeo === 'grande_ville'
        ? Math.round((state.statut === 'etudiant' ? 280 : 540) * nbAdultes)
        : Math.round(180 * nbAdultes);

  const volsEuropeEcoNb =
    net > 160000 ? 4 : net > 60000 ? 2 : net > 25000 ? 1 : 0;
  const volsLongCourrierEcoNb = net > 140000 ? 2 : net > 75000 ? 1 : 0;
  const volsAffairesNb = net > 250000 ? 2 : 0;
  const volsOspCorseNb = 0;
  const traverseesMaritimesNb = net > 45000 ? 1 : 0;
  const nuiteesHotelLocationFrance =
    state.statut === 'rsa_inactif'
      ? 0
      : net > 120000
        ? 18
        : net > 40000
          ? 8
          : 3;
  const tarifTaxeSejourNuit = net > 120000 ? 4.8 : 2.6;
  const timbresFiscauxAmendesAnnuels =
    state.statut === 'rsa_inactif' || state.statut === 'etudiant'
      ? 25
      : hasCar
        ? 95
        : 35;

  // Habitudes & Assurances
  const prixPaquetCigarettes = 13.0;
  const consoVinLitresAn =
    state.statut === 'rsa_inactif' ? 8 : Math.round(28 * nbAdultes * consoMult);
  const consoBiereLitresAn =
    state.statut === 'etudiant'
      ? Math.round(36 * consoMult)
      : Math.round(26 * nbAdultes * consoMult);
  const consoSpiritueuxLitresAn =
    state.statut === 'rsa_inactif'
      ? 0.5
      : Number((2.2 * nbAdultes * consoMult).toFixed(1));
  const consoSodasSucresLitresAn = Math.round(35 * uc * consoMult);
  const consoSodasEdulcoresLitresAn = Math.round(18 * uc * consoMult);
  const consoEauxMineralesLitresAn = Math.round(95 * uc);

  const primeAssuranceAutoTtc = hasCar ? Math.round(620 * state.nbVehicules) : 0;
  const primeAssuranceHabitationTtc =
    state.statutLogement === 'heberge'
      ? 0
      : state.statutLogement === 'residence_crous'
        ? 65
        : Math.round((state.statutLogement === 'proprietaire' ? 440 : 240) * Math.max(0.7, surfCoeff));
  const primeMutuelleSanteTtc =
    state.statut === 'rsa_inactif'
      ? 0 // Complémentaire Santé Solidaire (CSS) gratuite
      : state.statut === 'etudiant'
        ? 290
        : Math.round((state.statut === 'retraite' ? 1480 : 620) * nbAdultes + nbEnfants * 210);
  const primePrevoyanceAutresTtc = net > 55000 ? 320 : 90;
  const nbContratsAssuranceBiens =
    (hasCar ? state.nbVehicules : 0) + (state.statutLogement === 'heberge' ? 0 : 1);

  const misesJeuxLoterieParisAn = Math.round(
    (state.statut === 'etudiant' ? 60 : 210) * nbAdultes * consoMult
  );
  const misesParisHippiquesCasinosAn = Math.round(80 * nbAdultes * (net > 30000 ? 1 : 0.3));
  const depensesSpectaclesCinemaTtc = Math.round(
    (state.statut === 'etudiant' ? 140 : 240 * nbAdultes + nbEnfants * 70) * consoMult
  );

  // Immobilier & Patrimoine
  const multZoneImmo =
    state.zoneGeo === 'paris_idf'
      ? 1.55
      : state.zoneGeo === 'grande_ville'
        ? 1.25
        : state.zoneGeo === 'ville_moyenne'
          ? 1.0
          : 0.82;

  const taxeFonciereAnnuelle =
    state.statutLogement === 'proprietaire'
      ? Math.round(1280 * surfCoeff * multZoneImmo)
      : 0;
  const taxeHabitationSecondaire = net > 220000 ? 2400 : 0;
  const valeurLocativeLogementVacant = 0;
  const anneesVacanceLogement = 1;
  const patrimoineImmoNetIfi =
    state.statut === 'rentier'
      ? 2400000
      : net > 350000
        ? 1850000
        : 0;
  const loyersNetsFonciersAnnuels =
    state.statut === 'rentier' ? 36000 : net > 180000 ? 14400 : 0;
  const regimeLocatifMeuble = 0;
  const taxeMicroLogementsLoyersEleves = 0;
  const plusValueImmoBrute = 0;
  const dureeDetentionPvImmoAns = 8;
  const achatImmobilierPrixAncien =
    state.statutLogement === 'proprietaire' && net > 30000 && brut > 22000
      ? Math.round(clamp(net * 4.2, 160000, 650000))
      : 0;
  const achatImmobilierPrixNeuf = 0;
  const surfaceConstructionAmenagementM2 = 0;
  const cessionTerrainDevenuConstructibleGain = 0;
  const taxeEnginsMaritimesLuxe = 0;

  // Capital, Holding & Transmission
  const optionBaremeCapital = 0;
  const dividendesBrutsAnnuels =
    state.statut === 'dirigeant_sas'
      ? Math.round(Math.max(0, brut * 0.45))
      : state.statut === 'rentier'
        ? Math.round(Math.max(45000, brut * 0.7))
        : net > 120000
          ? 12000
          : 0;
  const interetsBrutsFiscalisesAnnuels =
    net > 100000 ? Math.round(net * 0.03) : net > 35000 ? 350 : 0;
  const gainsAssuranceVieRachat = state.statut === 'retraite' && net > 45000 ? 3200 : 0;
  const plusValuesMobilieresBrutes =
    state.statut === 'rentier' ? 28000 : net > 150000 ? 12000 : 0;
  const plusValuesCryptoBrutes =
    state.statut === 'etudiant' ? 0 : net > 55000 ? 1800 : 0;
  const achatsActionsFrancaisesTtf =
    state.statut === 'rentier' ? 60000 : net > 120000 ? 15000 : 0;
  const ventesMetauxPrecieuxOr = 0;
  const montantSuccessionRecue = 0;
  const lienSuccession = 1;
  const assuranceVieDecesAvant70 = 0;
  const montantDonationRecue = 0;
  const baseDroitsEnregistrementActes = 0;
  const actifNetPartageDivorceIndivision = 0;
  const exitTaxPlusValuesLatentes = 0;

  // Entreprise & Holding (séparés par incidence)
  const isPro =
    state.statut === 'dirigeant_sas' ||
    state.statut === 'independant_tns' ||
    state.statut === 'micro_entrepreneur';
  const isUltraActionnaire = state.statut === 'rentier' && dividendesBrutsAnnuels >= 80000;

  const partDetentionSocietePct =
    state.statut === 'dirigeant_sas' ? 100 : isUltraActionnaire ? 100 : 0;
  const beneficeSocieteAvantIs =
    state.statut === 'dirigeant_sas'
      ? Math.round(Math.max(60000, brut * 1.4))
      : isUltraActionnaire
        ? Math.round(dividendesBrutsAnnuels * 2.4)
        : 0;
  const chiffreAffairesEntreprise =
    state.statut === 'micro_entrepreneur'
      ? brut
      : state.statut === 'independant_tns'
        ? Math.round(brut * 1.45)
        : state.statut === 'dirigeant_sas'
          ? Math.round(beneficeSocieteAvantIs * 4.5)
          : isUltraActionnaire
            ? Math.round(beneficeSocieteAvantIs * 6)
            : 0;

  const partRemonteeHoldingPct =
    state.statut === 'dirigeant_sas' ? 40 : isUltraActionnaire ? 65 : 0;
  const valorisationEntrepriseEstimee =
    state.statut === 'dirigeant_sas'
      ? Math.round(beneficeSocieteAvantIs * 7)
      : isUltraActionnaire
        ? Math.round(beneficeSocieteAvantIs * 14)
        : 0;
  const decoteLiquiditeCessionPct = isUltraActionnaire ? 25 : 20;
  const dividendesSortisDeHoldingPourPoche = 0;
  const montantRachatActionsSociete = 0;

  const cfeAnnuelle = isPro
    ? state.statut === 'micro_entrepreneur'
      ? 380
      : state.zoneGeo === 'paris_idf'
        ? 1150
        : 690
    : isUltraActionnaire
      ? 2800
      : 0;
  const surfaceCommercialeTascomM2 = 0;
  const surfaceBureauxIdfPacaM2 =
    state.statut === 'dirigeant_sas' && state.zoneGeo === 'paris_idf' ? 45 : 0;
  const fraisChambreConsulaire = isPro ? (state.statut === 'micro_entrepreneur' ? 75 : 240) : 0;
  const tvsVehiculesSociete = state.statut === 'dirigeant_sas' ? 680 : 0;
  const tgapActivitesPolluantesPro = 0;
  const tlpePubliciteExterieure = 0;
  const redevanceSacemPro = state.statut === 'independant_tns' ? 0 : 0;
  const iferReseauxEnergieTelecomPro = 0;
  const actionsGratuitesBspceGains = 0;
  const tauxVersementMobilitePct =
    state.tailleEntreprise === 'moins_11'
      ? 0
      : state.zoneGeo === 'paris_idf'
        ? 3.2
        : state.zoneGeo === 'grande_ville'
          ? 2.0
          : 0.9;

  const dividendesEnHoldingEst = dividendesBrutsAnnuels * (partRemonteeHoldingPct / 100);
  const tresorerieAccumuleeHolding =
    dividendesEnHoldingEst > 0 ? Math.round(dividendesEnHoldingEst * 3) : 0;
  const rendementTresorerieHoldingPct = dividendesEnHoldingEst > 0 ? 3.2 : 0;
  const actifsNonOperationnelsHolding = isUltraActionnaire ? 6500000 : 0;
  const plusValuesEnReport150OBTer = isUltraActionnaire ? 12000000 : 0;
  const aidesPubliquesEntrepriseCirBpi = 0;
  const gardeEnfantsFraisAnnuels =
    state.nbEnfantsMoins3Ans > 0 ? state.nbEnfantsMoins3Ans * 6500 : 0;

  return {
    depensesTva20,
    depensesTva10,
    depensesTva55,
    depensesTva21,
    achatsHorsUeDouane,
    achatsHighTechNeufs,
    abonnementsTelecomStreaming,
    achatsEquipementMaison,
    consoElectriciteKwh,
    abonnementElectriciteAnnuelHt,
    consoGazKwh,
    abonnementGazAnnuelHt,
    consoFioulLitres,
    consoEauM3,
    teomAnnuelle,
    reomAnnuelle,
    taxeBalayageAnnuelle,
    dechetsTonnesIndirects,
    consoCarburantLitres100,
    prixCarburantTtcLitre,
    achatVehiculeCetteAnnee,
    chevauxFiscauxVehicule,
    emissionsCo2Gkm,
    poidsVehiculeKg,
    vehiculeNeuf,
    peagesAutorouteAnnuelsTtc,
    transportsCommunTrainTtc,
    volsEuropeEcoNb,
    volsLongCourrierEcoNb,
    volsAffairesNb,
    volsOspCorseNb,
    traverseesMaritimesNb,
    nuiteesHotelLocationFrance,
    tarifTaxeSejourNuit,
    timbresFiscauxAmendesAnnuels,
    prixPaquetCigarettes,
    consoVinLitresAn,
    consoBiereLitresAn,
    consoSpiritueuxLitresAn,
    consoSodasSucresLitresAn,
    consoSodasEdulcoresLitresAn,
    consoEauxMineralesLitresAn,
    primeAssuranceAutoTtc,
    primeAssuranceHabitationTtc,
    primeMutuelleSanteTtc,
    primePrevoyanceAutresTtc,
    nbContratsAssuranceBiens,
    misesJeuxLoterieParisAn,
    misesParisHippiquesCasinosAn,
    depensesSpectaclesCinemaTtc,
    taxeFonciereAnnuelle,
    taxeHabitationSecondaire,
    valeurLocativeLogementVacant,
    anneesVacanceLogement,
    patrimoineImmoNetIfi,
    loyersNetsFonciersAnnuels,
    regimeLocatifMeuble,
    taxeMicroLogementsLoyersEleves,
    plusValueImmoBrute,
    dureeDetentionPvImmoAns,
    achatImmobilierPrixAncien,
    achatImmobilierPrixNeuf,
    surfaceConstructionAmenagementM2,
    cessionTerrainDevenuConstructibleGain,
    taxeEnginsMaritimesLuxe,
    optionBaremeCapital,
    dividendesBrutsAnnuels,
    interetsBrutsFiscalisesAnnuels,
    gainsAssuranceVieRachat,
    plusValuesMobilieresBrutes,
    plusValuesCryptoBrutes,
    achatsActionsFrancaisesTtf,
    ventesMetauxPrecieuxOr,
    montantSuccessionRecue,
    lienSuccession,
    assuranceVieDecesAvant70,
    montantDonationRecue,
    baseDroitsEnregistrementActes,
    actifNetPartageDivorceIndivision,
    exitTaxPlusValuesLatentes,
    partDetentionSocietePct,
    beneficeSocieteAvantIs,
    chiffreAffairesEntreprise,
    partRemonteeHoldingPct,
    valorisationEntrepriseEstimee,
    decoteLiquiditeCessionPct,
    dividendesSortisDeHoldingPourPoche,
    montantRachatActionsSociete,
    cfeAnnuelle,
    surfaceCommercialeTascomM2,
    surfaceBureauxIdfPacaM2,
    fraisChambreConsulaire,
    tvsVehiculesSociete,
    tgapActivitesPolluantesPro,
    tlpePubliciteExterieure,
    redevanceSacemPro,
    iferReseauxEnergieTelecomPro,
    actionsGratuitesBspceGains,
    tauxVersementMobilitePct,
    tresorerieAccumuleeHolding,
    rendementTresorerieHoldingPct,
    actifsNonOperationnelsHolding,
    plusValuesEnReport150OBTer,
    aidesPubliquesEntrepriseCirBpi,
    gardeEnfantsFraisAnnuels,
  };
}
