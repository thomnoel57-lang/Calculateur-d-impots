import {
  BeneficiaryId,
  ComputedTaxItem,
  ExpertOverrides,
  FamilyBreakdown,
  HoldingAndValuationBreakdown,
  SimulationResult,
  SimulationState,
  StatutPrincipal,
  TaxFamilyId,
} from '../types/fiscal';
import { FISCAL_CATALOG, TAX_FAMILIES } from '../data/taxCatalog';
import { clamp, formatFrenchDateFromDayIndex } from '../utils/formatters';
import { computeInseeOverrides } from './inseeEstimator';
import { computeAides2026 } from './aidesCalculator';

// Constantes officielles 2026 (barèmes indexés LF 2025/2026)
export const SMIC_ANNUEL_BRUT_2026 = 21622; // ~1 801,80 €/mois
export const PASS_2026 = 48060; // Plafond Annuel Sécurité Sociale 2026

const IR_TRANCHES_2026 = [
  { max: 11520, rate: 0 },
  { max: 29373, rate: 0.11 },
  { max: 83988, rate: 0.30 },
  { max: 180648, rate: 0.41 },
  { max: Infinity, rate: 0.45 },
];

export function computeIrParts(state: SimulationState): number {
  const isCouple = state.situationFamiliale === 'couple';
  let parts = isCouple ? 2 : 1;
  const kids = clamp(Math.round(state.nbEnfants), 0, 10);
  if (kids === 1) parts += 0.5;
  else if (kids === 2) parts += 1;
  else if (kids >= 3) parts += 1 + (kids - 2);

  if (!isCouple && state.parentIsole && kids > 0) {
    parts += 0.5;
  }
  return parts;
}

function computeBaremeIr(revenuImposable: number, parts: number): {
  impotBrut: number;
  tmiPct: number;
} {
  if (revenuImposable <= 0) return { impotBrut: 0, tmiPct: 0 };
  const quotient = revenuImposable / parts;
  let impotParPart = 0;
  let prev = 0;
  let tmiPct = 0;

  for (const tranche of IR_TRANCHES_2026) {
    if (quotient > prev) {
      const slice = Math.min(quotient, tranche.max) - prev;
      impotParPart += slice * tranche.rate;
      if (slice > 0) tmiPct = tranche.rate * 100;
      prev = tranche.max;
    } else {
      break;
    }
  }

  let impotAvantDecote = impotParPart * parts;

  // Plafonnement du quotient familial (approx. 1 794 € par demi-part additionnelle)
  const partsBase = parts >= 2 && parts % 1 !== 0.5 ? 2 : parts >= 2 ? 2 : 1;
  if (parts > partsBase) {
    const qBase = revenuImposable / partsBase;
    let impBaseParPart = 0;
    let p2 = 0;
    for (const tranche of IR_TRANCHES_2026) {
      if (qBase > p2) {
        const s = Math.min(qBase, tranche.max) - p2;
        impBaseParPart += s * tranche.rate;
        p2 = tranche.max;
      }
    }
    const impotBase = impBaseParPart * partsBase;
    const demiPartsSup = (parts - partsBase) * 2;
    const gainMax = demiPartsSup * 1794;
    if (impotBase - impotAvantDecote > gainMax) {
      impotAvantDecote = impotBase - gainMax;
    }
  }

  // Décote 2026 pour impôts modestes
  const isCouple = parts >= 2;
  const seuilDecote = isCouple ? 3248 : 1965;
  if (impotAvantDecote > 0 && impotAvantDecote < seuilDecote) {
    const decote = (isCouple ? 1470 : 889) - 0.4525 * impotAvantDecote;
    if (decote > 0) impotAvantDecote = Math.max(0, impotAvantDecote - decote);
  }

  return {
    impotBrut: Math.max(0, impotAvantDecote),
    tmiPct,
  };
}

function computeCehr(rfr: number, isCouple: boolean): number {
  const s1 = isCouple ? 500000 : 250000;
  const s2 = isCouple ? 1000000 : 500000;
  if (rfr <= s1) return 0;
  let tax = 0;
  if (rfr > s2) {
    tax += (s2 - s1) * 0.03 + (rfr - s2) * 0.04;
  } else {
    tax += (rfr - s1) * 0.03;
  }
  return tax;
}

function computeMarginalExitTax(
  amount: number,
  baseRfr: number,
  baseIrPart: number,
  isCouple: boolean
): { totalTax: number; newRfr: number; newIrPart: number } {
  if (amount <= 0) {
    return { totalTax: 0, newRfr: baseRfr, newIrPart: baseIrPart };
  }
  const pfu = amount * 0.314;
  const irFromPfu = amount * 0.128;
  const marginalCehr =
    computeCehr(baseRfr + amount, isCouple) - computeCehr(baseRfr, isCouple);
  const newRfr = baseRfr + amount;
  const seuilCdhr = isCouple ? 500000 : 250000;
  const totalIrWithoutNewCdhr = baseIrPart + irFromPfu + marginalCehr;
  const floor20 = newRfr > seuilCdhr ? newRfr * 0.2 : 0;
  const marginalCdhr = Math.max(0, floor20 - totalIrWithoutNewCdhr);
  const newIrPart = totalIrWithoutNewCdhr + marginalCdhr;
  return {
    totalTax: pfu + marginalCehr + marginalCdhr,
    newRfr,
    newIrPart,
  };
}

interface CotisAdultResult {
  brut: number;
  superBrut: number;
  patMaladie: number;
  patVieillessePlaf: number;
  patVieillesseDeplaf: number;
  patFamille: number;
  patAtMp: number;
  patChomageAgs: number;
  patAgircT1: number;
  patAgircT2: number;
  patFnal: number;
  patCsa: number;
  patFormation: number;
  patVersementMobilite: number;
  patForfaitSocialTaxeSalaires: number;
  reductionFillon: number;
  salVieillessePlaf: number;
  salVieillesseDeplaf: number;
  salAgircT1: number;
  salAgircT2: number;
  salCsgDed: number;
  salCsgNonDed: number;
  salCrds: number;
  salApecAlsace: number;
  salCasa: number;
  tnsUrssafMicro: number;
  netAvantIr: number;
  revenuImposableActivite: number;
}

function computeAdultCotisations(
  statut: StatutPrincipal | string,
  brutSalaire: number,
  pensionBrute: number,
  chomageBrut: number,
  interessement: number,
  state: SimulationState,
  tauxVmPct: number
): CotisAdultResult {
  const res: CotisAdultResult = {
    brut: 0,
    superBrut: 0,
    patMaladie: 0,
    patVieillessePlaf: 0,
    patVieillesseDeplaf: 0,
    patFamille: 0,
    patAtMp: 0,
    patChomageAgs: 0,
    patAgircT1: 0,
    patAgircT2: 0,
    patFnal: 0,
    patCsa: 0,
    patFormation: 0,
    patVersementMobilite: 0,
    patForfaitSocialTaxeSalaires: 0,
    reductionFillon: 0,
    salVieillessePlaf: 0,
    salVieillesseDeplaf: 0,
    salAgircT1: 0,
    salAgircT2: 0,
    salCsgDed: 0,
    salCsgNonDed: 0,
    salCrds: 0,
    salApecAlsace: 0,
    salCasa: 0,
    tnsUrssafMicro: 0,
    netAvantIr: 0,
    revenuImposableActivite: 0,
  };

  const isSalarieLike =
    statut === 'salarie_non_cadre' ||
    statut === 'salarie_cadre' ||
    statut === 'fonctionnaire' ||
    statut === 'dirigeant_sas' ||
    statut === 'apprenti' ||
    (statut === 'etudiant' && brutSalaire > 0);

  if (isSalarieLike && brutSalaire > 0) {
    const t1 = Math.min(brutSalaire, PASS_2026);
    const t2 = Math.max(0, Math.min(brutSalaire, PASS_2026 * 8) - PASS_2026);
    const ratioSmic = brutSalaire / SMIC_ANNUEL_BRUT_2026;
    const isFonctionnaire = statut === 'fonctionnaire';
    const isDirigeantSas = statut === 'dirigeant_sas';
    const isApprenti = statut === 'apprenti';

    // Patronales
    res.patMaladie =
      brutSalaire * (ratioSmic <= 2.5 ? 0.07 : 0.13) +
      (state.alsaceMoselle ? brutSalaire * 0.018 : 0);
    res.patVieillessePlaf = t1 * 0.0855;
    res.patVieillesseDeplaf = brutSalaire * 0.0211;
    res.patFamille = brutSalaire * (ratioSmic <= 3.3 ? 0.0345 : 0.0525);
    res.patAtMp = brutSalaire * (isFonctionnaire ? 0.004 : 0.019);
    res.patChomageAgs =
      isFonctionnaire || isDirigeantSas
        ? 0
        : Math.min(brutSalaire, PASS_2026 * 4) * 0.0425;
    res.patAgircT1 = t1 * (isFonctionnaire ? 0.049 : 0.0601);
    res.patAgircT2 = t2 * 0.1478;
    res.patFnal = brutSalaire * (state.tailleEntreprise === '50_plus' ? 0.005 : 0.001);
    res.patCsa = brutSalaire * 0.003;
    res.patFormation =
      brutSalaire *
      ((state.tailleEntreprise === 'moins_11' ? 0.0055 : 0.01) + 0.0068 + 0.00016);
    res.patVersementMobilite =
      state.tailleEntreprise === 'moins_11' ? 0 : brutSalaire * (tauxVmPct / 100);

    let taxeSalaires = 0;
    if (state.employeurHorsTva) {
      taxeSalaires =
        Math.min(brutSalaire, 8950) * 0.0425 +
        Math.max(0, Math.min(brutSalaire, 17875) - 8950) * 0.085 +
        Math.max(0, brutSalaire - 17875) * 0.136;
    }
    res.patForfaitSocialTaxeSalaires =
      taxeSalaires +
      (state.tailleEntreprise === '50_plus' ? interessement * 0.2 : 0) +
      brutSalaire * 0.003;

    // Réduction générale (ex-Fillon) < 1,6 SMIC ou exonération apprenti
    if (isApprenti) {
      res.reductionFillon = Math.min(
        res.patMaladie + res.patVieillessePlaf + res.patFamille,
        brutSalaire * 0.27
      );
    } else if (!isFonctionnaire && ratioSmic > 0 && ratioSmic < 1.6) {
      const coeff = clamp((0.3206 / 0.6) * (1.6 / ratioSmic - 1), 0, 0.3206);
      res.reductionFillon = brutSalaire * coeff;
    }

    const totalPatronalNet = Math.max(
      0,
      res.patMaladie +
        res.patVieillessePlaf +
        res.patVieillesseDeplaf +
        res.patFamille +
        res.patAtMp +
        res.patChomageAgs +
        res.patAgircT1 +
        res.patAgircT2 +
        res.patFnal +
        res.patCsa +
        res.patFormation +
        res.patVersementMobilite +
        res.patForfaitSocialTaxeSalaires -
        res.reductionFillon
    );

    // Salariales (Apprentis exonérés sous 50 % SMIC en 2025/2026)
    const exoApprentiPart = isApprenti
      ? Math.max(0, brutSalaire - SMIC_ANNUEL_BRUT_2026 * 0.5) / Math.max(1, brutSalaire)
      : 1;

    res.salVieillessePlaf = t1 * 0.069 * exoApprentiPart;
    res.salVieillesseDeplaf = brutSalaire * 0.004 * exoApprentiPart;
    res.salAgircT1 = t1 * (isFonctionnaire ? 0.032 : 0.0401) * exoApprentiPart;
    res.salAgircT2 = t2 * 0.0986 * exoApprentiPart;

    const baseCsg = brutSalaire * 0.9825 * (isApprenti ? exoApprentiPart : 1);
    res.salCsgDed = baseCsg * 0.068;
    res.salCsgNonDed = baseCsg * 0.024;
    res.salCrds = baseCsg * 0.005;

    res.salApecAlsace =
      (statut === 'salarie_cadre' ? Math.min(brutSalaire, PASS_2026 * 4) * 0.00024 : 0) +
      (state.alsaceMoselle ? brutSalaire * 0.013 : 0);

    const totalSal =
      res.salVieillessePlaf +
      res.salVieillesseDeplaf +
      res.salAgircT1 +
      res.salAgircT2 +
      res.salCsgDed +
      res.salCsgNonDed +
      res.salCrds +
      res.salApecAlsace;

    res.brut = brutSalaire + interessement;
    res.superBrut = res.brut + totalPatronalNet;
    res.netAvantIr = Math.max(0, brutSalaire - totalSal) + interessement * 0.903;

    // Exonérations IR spécifiques Apprenti (1 SMIC) et Étudiant <= 25 ans (3 SMIC mensuels)
    let brutPourIr = brutSalaire;
    if (isApprenti) {
      brutPourIr = Math.max(0, brutSalaire - SMIC_ANNUEL_BRUT_2026);
    } else if (statut === 'etudiant' && state.ageMoins25Ans) {
      brutPourIr = Math.max(0, brutSalaire - 5405);
    }
    const deducCotis =
      res.salVieillessePlaf +
      res.salVieillesseDeplaf +
      res.salAgircT1 +
      res.salAgircT2 +
      res.salCsgDed +
      res.salApecAlsace;
    const ratioIr = brutSalaire > 0 ? brutPourIr / brutSalaire : 0;
    const netImposableSalaire = Math.max(0, (brutSalaire - deducCotis) * ratioIr);
    // Abattement forfaitaire de 10 % pour frais pro (plancher 495 €, plafond 14 426 €)
    const abatt10 =
      netImposableSalaire > 0
        ? clamp(netImposableSalaire * 0.1, Math.min(netImposableSalaire, 495), 14426)
        : 0;
    res.revenuImposableActivite = Math.max(0, netImposableSalaire - abatt10);
  } else if (statut === 'independant_tns' && brutSalaire > 0) {
    // brutSalaire = revenu professionnel + cotisations (~CA - frais)
    const cotisTns = brutSalaire * 0.305; // ~44 % du net TNS ≈ 30,5 % du super-brut pro
    res.tnsUrssafMicro = cotisTns;
    res.brut = brutSalaire;
    res.superBrut = brutSalaire;
    res.netAvantIr = Math.max(0, brutSalaire - cotisTns);
    res.revenuImposableActivite = res.netAvantIr * 0.96; // petite part CSG non déductible
  } else if (statut === 'micro_entrepreneur' && brutSalaire > 0) {
    // Micro-entreprise : cotisations 23,1 % du CA (BNC/services), abattement fiscal 34 % (ou 50 % BIC)
    const cotisMicro = brutSalaire * 0.231;
    res.tnsUrssafMicro = cotisMicro;
    res.brut = brutSalaire;
    res.superBrut = brutSalaire;
    res.netAvantIr = Math.max(0, brutSalaire - cotisMicro);
    res.revenuImposableActivite = brutSalaire * 0.66;
  } else if (statut === 'retraite' && pensionBrute > 0) {
    // Taux CSG retraite selon niveau de pension
    const tauxCsgDed = pensionBrute > 26000 ? 0.059 : pensionBrute > 16000 ? 0.038 : 0;
    const tauxCsgNonDed = pensionBrute > 26000 ? 0.024 : 0;
    const tauxCrds = pensionBrute > 12500 ? 0.005 : 0;
    const tauxCasa = pensionBrute > 16000 ? 0.003 : 0;

    res.salCsgDed = pensionBrute * tauxCsgDed;
    res.salCsgNonDed = pensionBrute * tauxCsgNonDed;
    res.salCrds = pensionBrute * tauxCrds;
    res.salCasa = pensionBrute * tauxCasa;

    const totalRet = res.salCsgDed + res.salCsgNonDed + res.salCrds + res.salCasa;
    res.brut = pensionBrute;
    res.superBrut = pensionBrute;
    res.netAvantIr = Math.max(0, pensionBrute - totalRet);
    const netImposablePension = pensionBrute - res.salCsgDed;
    const abatt10Ret = clamp(netImposablePension * 0.1, Math.min(netImposablePension, 442), 4321);
    res.revenuImposableActivite = Math.max(0, netImposablePension - abatt10Ret);
  } else if (statut === 'chomeur' && chomageBrut > 0) {
    const exoAre = chomageBrut <= 13500;
    res.salCsgDed = exoAre ? 0 : chomageBrut * 0.038;
    res.salCsgNonDed = exoAre ? 0 : chomageBrut * 0.024;
    res.salCrds = exoAre ? 0 : chomageBrut * 0.005;
    const totalAre = res.salCsgDed + res.salCsgNonDed + res.salCrds;
    res.brut = chomageBrut;
    res.superBrut = chomageBrut;
    res.netAvantIr = Math.max(0, chomageBrut - totalAre);
    const netImpAre = chomageBrut - res.salCsgDed;
    res.revenuImposableActivite = Math.max(
      0,
      netImpAre - clamp(netImpAre * 0.1, Math.min(netImpAre, 495), 14426)
    );
  }

  return res;
}

export function runSimulation(state: SimulationState): SimulationResult {
  const vmDefault =
    state.zoneGeo === 'paris_idf'
      ? 3.2
      : state.zoneGeo === 'grande_ville'
        ? 2.0
        : state.zoneGeo === 'ville_moyenne'
          ? 0.9
          : 0.6;
  const tauxVm = state.overrides.tauxVersementMobilitePct ?? vmDefault;

  // 1. Calcul cotisations Adulte 1 + Conjoint
  const a1 = computeAdultCotisations(
    state.statut,
    state.statut === 'retraite' || state.statut === 'chomeur' || state.statut === 'rsa_inactif' || state.statut === 'rentier'
      ? 0
      : state.salaireBrutAnnuel,
    state.statut === 'retraite' ? state.pensionRetraiteBruteAnnuelle : 0,
    state.statut === 'chomeur' ? state.allocationChomageBruteAnnuelle : 0,
    state.interessementParticipationAnnuel,
    state,
    tauxVm
  );

  const hasCouple = state.situationFamiliale === 'couple' && state.statutConjoint !== 'aucun';
  const a2 = hasCouple
    ? computeAdultCotisations(
        state.statutConjoint,
        state.statutConjoint === 'retraite' || state.statutConjoint === 'chomeur'
          ? 0
          : state.salaireConjointBrutAnnuel,
        state.statutConjoint === 'retraite' ? state.pensionConjointBruteAnnuelle : 0,
        state.statutConjoint === 'chomeur' ? state.salaireConjointBrutAnnuel : 0,
        0,
        state,
        tauxVm
      )
    : computeAdultCotisations('aucun', 0, 0, 0, 0, state, 0);

  const superBrutFoyer = a1.superBrut + a2.superBrut;
  const brutFoyer = a1.brut + a2.brut;
  const netAvantIrFoyer = a1.netAvantIr + a2.netAvantIr;
  const partsFiscales = computeIrParts(state);

  // Estimation préliminaire INSEE (sera affinée avec le net après IR réel)
  const prelimOverrides = computeInseeOverrides(state, {
    revenuNetDisponibleFoyer: Math.max(8000, netAvantIrFoyer + (state.statut === 'rentier' ? 95000 : 0)),
    revenuBrutReference: Math.max(brutFoyer, state.salaireBrutAnnuel),
  });
  const effPreview: Required<ExpertOverrides> = {
    ...prelimOverrides,
    ...Object.fromEntries(
      Object.entries(state.overrides).filter(([, v]) => v !== undefined && Number.isFinite(v))
    ),
  };

  // Revenus fonciers imposables (abattement 30 % nu ou 50 % meublé)
  const loyersImposables =
    effPreview.loyersNetsFonciersAnnuels * (effPreview.regimeLocatifMeuble ? 0.5 : 0.7);

  // Part des dividendes sortis en poche personnelle vs remontés en holding
  const partHolding = clamp(effPreview.partRemonteeHoldingPct / 100, 0, 1);
  const dividendesEnPocheBruts =
    effPreview.dividendesBrutsAnnuels * (1 - partHolding) + effPreview.dividendesSortisDeHoldingPourPoche;
  const dividendesEnHoldingBruts = effPreview.dividendesBrutsAnnuels * partHolding;

  const revenuImposableActiviteFoyer = a1.revenuImposableActivite + a2.revenuImposableActivite + loyersImposables;
  const revenusCapitalPocheBruts =
    dividendesEnPocheBruts +
    effPreview.interetsBrutsFiscalisesAnnuels +
    effPreview.gainsAssuranceVieRachat +
    effPreview.plusValuesMobilieresBrutes +
    effPreview.plusValuesCryptoBrutes +
    effPreview.actionsGratuitesBspceGains;

  // Calcul IR (barème progressif)
  const irTravResult = computeBaremeIr(
    revenuImposableActiviteFoyer +
      (effPreview.optionBaremeCapital ? dividendesEnPocheBruts * 0.6 : 0),
    partsFiscales
  );
  const irNetApresCredits = Math.max(0, irTravResult.impotBrut - state.reductionsCreditsImpot);

  // RFR (Revenu Fiscal de Référence)
  const revenuFiscalReference = Math.round(
    revenuImposableActiviteFoyer + revenusCapitalPocheBruts
  );

  // CEHR & CDHR (2026)
  const isCouple = state.situationFamiliale === 'couple';
  const cehrTotal = computeCehr(revenuFiscalReference, isCouple);

  // Flat Tax 2026 = 31,4 % (12,8 % IR + 18,6 % PS) sur revenus capital sortis en poche
  const pfuDividendes = effPreview.optionBaremeCapital
    ? dividendesEnPocheBruts * 0.186
    : dividendesEnPocheBruts * 0.314;
  const pfuInterets = effPreview.interetsBrutsFiscalisesAnnuels * 0.314;
  const pfuAssuranceVie =
    Math.max(0, effPreview.gainsAssuranceVieRachat - (isCouple ? 9200 : 4600)) * 0.075 +
    effPreview.gainsAssuranceVieRachat * 0.172;
  const pfuPvMobilieres = effPreview.plusValuesMobilieresBrutes * 0.314;
  const pfuCrypto = Math.max(0, effPreview.plusValuesCryptoBrutes) * (effPreview.plusValuesCryptoBrutes > 305 ? 0.314 : 0);
  const agaBspceImpots = effPreview.actionsGratuitesBspceGains * 0.38;

  // CDHR 2026 : garantit IR + part IR du PFU (12,8 %) >= 20 % du RFR si > 250k€ / 500k€
  const seuilCdhr = isCouple ? 500000 : 250000;
  const irDejaPayeAvantCdhr =
    irNetApresCredits +
    cehrTotal +
    (effPreview.optionBaremeCapital ? 0 : dividendesEnPocheBruts * 0.128) +
    effPreview.interetsBrutsFiscalisesAnnuels * 0.128 +
    effPreview.plusValuesMobilieresBrutes * 0.128 +
    (effPreview.plusValuesCryptoBrutes > 305 ? effPreview.plusValuesCryptoBrutes * 0.128 : 0);
  let cdhrMontant = 0;
  if (revenuFiscalReference > seuilCdhr) {
    const cible20 = revenuFiscalReference * 0.2;
    if (irDejaPayeAvantCdhr < cible20) {
      cdhrMontant = cible20 - irDejaPayeAvantCdhr;
    }
  }
  const irPartFoyerApresCdhr = irDejaPayeAvantCdhr + cdhrMontant;

  // Cotisations ouvrant réellement des droits personnels (retraite plafonnée/complémentaire + chômage)
  // Hors CSG/CRDS/vieillesse déplafonnée qui sont de la solidarité pure
  const cotisationsRetraiteContributives =
    a1.patVieillessePlaf +
    a1.patAgircT1 +
    a1.patAgircT2 +
    a1.salVieillessePlaf +
    a1.salAgircT1 +
    a1.salAgircT2 +
    a1.tnsUrssafMicro * 0.55 +
    a2.patVieillessePlaf +
    a2.patAgircT1 +
    a2.patAgircT2 +
    a2.salVieillessePlaf +
    a2.salAgircT1 +
    a2.salAgircT2 +
    a2.tnsUrssafMicro * 0.55;
  const cotisationsChomageContributives = a1.patChomageAgs + a2.patChomageAgs;

  // Aides sociales monétaires + prestations en nature & droits sociaux 2026 (100 % inclus)
  const aides = computeAides2026({
    state,
    revenuNetActiviteFoyer: netAvantIrFoyer,
    revenuTotalNetAvantIr: netAvantIrFoyer + dividendesEnPocheBruts,
    revenuFiscalReference,
    cotisationsRetraiteContributives,
    cotisationsChomageContributives,
    gardeEnfantsFraisAnnuels: effPreview.gardeEnfantsFraisAnnuels,
    taxeFonciereAnnuelle: effPreview.taxeFonciereAnnuelle,
  });

  // Net en poche après IR, prélèvements sociaux sur loyers (17,2 %) et dividendes nets
  const cashCapitalNetPoche = Math.max(
    0,
    revenusCapitalPocheBruts -
      pfuDividendes -
      pfuInterets -
      pfuAssuranceVie -
      pfuPvMobilieres -
      pfuCrypto -
      agaBspceImpots
  );
  const psLoyersPreview = effPreview.loyersNetsFonciersAnnuels * 0.172;
  const netApresIrFoyer = Math.max(
    0,
    netAvantIrFoyer +
      effPreview.loyersNetsFonciersAnnuels -
      psLoyersPreview -
      irNetApresCredits -
      cehrTotal -
      cdhrMontant
  );
  const revenuDisponiblePourConso =
    netApresIrFoyer + cashCapitalNetPoche + aides.totalAidesMonetaires;

  // Estimation finale INSEE calée sur le vrai revenu disponible (en respectant les overrides manuels)
  const autoOverrides = computeInseeOverrides(state, {
    revenuNetDisponibleFoyer: revenuDisponiblePourConso,
    revenuBrutReference: Math.max(brutFoyer, state.salaireBrutAnnuel),
  });
  const overriddenKeys = new Set<keyof ExpertOverrides>();
  const eff: Required<ExpertOverrides> = { ...autoOverrides };
  (Object.keys(state.overrides) as (keyof ExpertOverrides)[]).forEach((k) => {
    const val = state.overrides[k];
    if (val !== undefined && Number.isFinite(val)) {
      eff[k] = val;
      overriddenKeys.add(k);
    }
  });

  // ======================== CALCUL DÉTAILLÉ DES TAXES ========================
  const oneOffFactor = state.lisserTaxesPonctuelles ? 0.12 : 1; // lissage sur ~8 ans si activé

  // Loyers IR + PS 17,2 %
  const irSurLoyers =
    loyersImposables * (irTravResult.tmiPct / 100) + eff.loyersNetsFonciersAnnuels * 0.172;
  const irHorsLoyers = Math.max(0, irNetApresCredits - loyersImposables * (irTravResult.tmiPct / 100));

  // TVA (à partir de montants TTC : TVA = TTC * taux / (1 + taux))
  const tva20 = (eff.depensesTva20 * 0.2) / 1.2;
  const tva10 = (eff.depensesTva10 * 0.1) / 1.1;
  const tva55 = (eff.depensesTva55 * 0.055) / 1.055;
  const tva21 = (eff.depensesTva21 * 0.021) / 1.021;

  const douaneHorsUe = eff.achatsHorsUeDouane * 0.068;
  const copiePrivee = Math.min(85, (eff.achatsHighTechNeufs / 650) * 14);
  const ecoRep = eff.achatsEquipementMaison * 0.018 + (eff.depensesTva55 * 0.004);
  const taxeTelecom = eff.abonnementsTelecomStreaming * 0.55 * 0.013;
  const taxeStreamingCnc = eff.abonnementsTelecomStreaming * 0.45 * 0.0515;

  // Énergie & Eau
  const acciseElec = eff.consoElectriciteKwh * 0.0337;
  const ctaElec = eff.abonnementElectriciteAnnuelHt * 0.2193;
  const baseElecConsoHt = eff.consoElectriciteKwh * 0.145 + acciseElec;
  const tvaElec = baseElecConsoHt * 0.2 + (eff.abonnementElectriciteAnnuelHt + ctaElec) * 0.055;
  const factureElecTtc =
    baseElecConsoHt + eff.abonnementElectriciteAnnuelHt + ctaElec + tvaElec;

  const acciseGaz = eff.consoGazKwh * 0.01716;
  const ctaGaz = eff.abonnementGazAnnuelHt * 0.208;
  const baseGazConsoHt = eff.consoGazKwh * 0.082 + acciseGaz;
  const tvaGaz = baseGazConsoHt * 0.2 + (eff.abonnementGazAnnuelHt + ctaGaz) * 0.055;

  const acciseFioul = eff.consoFioulLitres * 0.1562;
  const tvaFioul = eff.consoFioulLitres * 1.18 * (0.2 / 1.2);
  const taxesFioulTotal = acciseFioul + tvaFioul;

  const redevancesEau = eff.consoEauM3 * 0.62;
  const tvaEau = eff.consoEauM3 * 2.1 * 0.055 + eff.consoEauM3 * 2.4 * 0.1;

  const teomReom = eff.teomAnnuelle + eff.reomAnnuelle;
  const taxeBalayage = eff.taxeBalayageAnnuelle;
  const tgapDechets = eff.dechetsTonnesIndirects * 42;

  // Auto, Carburants & Voyages
  const hasCar = state.typeVehicule !== 'aucune' && state.nbVehicules > 0 && state.kmAnnuels > 0;
  const litresCarburant = hasCar
    ? (state.kmAnnuels / 100) * eff.consoCarburantLitres100
    : 0;
  const tauxTicpe =
    state.typeVehicule === 'diesel'
      ? 0.6075
      : state.typeVehicule === 'e85'
        ? 0.1183
        : state.typeVehicule === 'electrique' || state.typeVehicule === 'aucune'
          ? 0
          : 0.672;
  const acciseCarburant = litresCarburant * tauxTicpe;
  const prixLitre = eff.prixCarburantTtcLitre || 1.79;
  const tvaCarburant = litresCarburant * prixLitre * (0.2 / 1.2);

  // L'achat véhicule ponctuel
  const achatVehiculeActive = eff.achatVehiculeCetteAnnee > 0 && state.typeVehicule !== 'aucune';
  const carteGriseRaw = achatVehiculeActive
    ? eff.chevauxFiscauxVehicule * 51 + 13.76
    : 0;
  const malusCo2Raw =
    achatVehiculeActive && eff.vehiculeNeuf > 0 && eff.emissionsCo2Gkm > 108
      ? clamp((eff.emissionsCo2Gkm - 108) * 95, 50, 45000)
      : 0;
  const malusPoidsRaw =
    achatVehiculeActive && eff.vehiculeNeuf > 0 && eff.poidsVehiculeKg > 1500
      ? (eff.poidsVehiculeKg - 1500) * 10 * (state.typeVehicule === 'electrique' ? 0.1 : 1)
      : 0;

  const peagesTva = eff.peagesAutorouteAnnuelsTtc * (0.2 / 1.2);
  const peagesTat = eff.peagesAutorouteAnnuelsTtc * 0.088;
  const tvaTransportsCommun = eff.transportsCommunTrainTtc * (0.1 / 1.1);
  const taxesAeriennes =
    eff.volsEuropeEcoNb * 22 +
    eff.volsLongCourrierEcoNb * 62 +
    eff.volsAffairesNb * 135 +
    eff.volsOspCorseNb * 12;
  const taxeMaritime = eff.traverseesMaritimesNb * 2.8;
  const taxeSejour = eff.nuiteesHotelLocationFrance * eff.tarifTaxeSejourNuit;
  const timbresFiscaux = eff.timbresFiscauxAmendesAnnuels * 0.45;
  const amendesFps = eff.timbresFiscauxAmendesAnnuels * 0.55;

  // Tabac, Boissons, Assurances, Jeux
  const paquetsAn = Math.max(0, state.fumeurPaquetsParSemaine) * 52;
  const depenseTabac = paquetsAn * eff.prixPaquetCigarettes;
  const acciseTabac = depenseTabac * 0.655;
  const tvaTabac = depenseTabac * (0.2 / 1.2);

  const accisesVinsBieres = eff.consoVinLitresAn * 0.04 + eff.consoBiereLitresAn * 0.39;
  const accisesSpiritueux = eff.consoSpiritueuxLitresAn * 0.4 * (18.6 + 5.9);
  const taxeSodasSucres = eff.consoSodasSucresLitresAn * 0.21;
  const taxeSodasEdulcores = eff.consoSodasEdulcoresLitresAn * 0.035;
  const surtaxeEaux = eff.consoEauxMineralesLitresAn * 0.0058;

  const tscaAuto = eff.primeAssuranceAutoTtc * 0.195;
  const tscaHabitation = eff.primeAssuranceHabitationTtc * 0.09 + eff.primePrevoyanceAutresTtc * 0.09;
  const tsaMutuelle = eff.primeMutuelleSanteTtc * 0.1327;
  const taxeCatNat = eff.primeAssuranceHabitationTtc * 0.167 + eff.primeAssuranceAutoTtc * 0.025;
  const taxeAttentatsFgti = eff.nbContratsAssuranceBiens * 6.5;
  const taxeFgao = eff.primeAssuranceAutoTtc * 0.012;
  const totalAssurancesTtc =
    eff.primeAssuranceAutoTtc +
    eff.primeAssuranceHabitationTtc +
    eff.primeMutuelleSanteTtc +
    eff.primePrevoyanceAutresTtc;
  const totalAssurancesTaxes =
    tscaAuto + tscaHabitation + tsaMutuelle + taxeCatNat + taxeAttentatsFgti + taxeFgao;

  const taxesFdjParis = eff.misesJeuxLoterieParisAn * 0.24;
  const taxesHippiquesCasinos = eff.misesParisHippiquesCasinosAn * 0.15;
  const taxesSpectacles = eff.depensesSpectaclesCinemaTtc * 0.092;

  // Immobilier & Patrimoine
  const taxeFonciere = eff.taxeFonciereAnnuelle;
  const thSecondaire = eff.taxeHabitationSecondaire;
  const taxeVacants =
    eff.valeurLocativeLogementVacant * (eff.anneesVacanceLogement >= 2 ? 0.34 : 0.17);

  let ifiMontant = 0;
  if (eff.patrimoineImmoNetIfi > 1300000) {
    const p = eff.patrimoineImmoNetIfi;
    if (p > 800000) ifiMontant += (Math.min(p, 1300000) - 800000) * 0.005;
    if (p > 1300000) ifiMontant += (Math.min(p, 2570000) - 1300000) * 0.007;
    if (p > 2570000) ifiMontant += (Math.min(p, 5000000) - 2570000) * 0.01;
    if (p > 5000000) ifiMontant += (Math.min(p, 10000000) - 5000000) * 0.0125;
    if (p > 10000000) ifiMontant += (p - 10000000) * 0.015;
  }

  const taxeMicroLogements = eff.taxeMicroLogementsLoyersEleves;
  const dmtoNotaireRaw =
    eff.achatImmobilierPrixAncien * 0.059 + eff.achatImmobilierPrixNeuf * 0.00715;
  const tvaImmoNeufRaw = eff.achatImmobilierPrixNeuf * (0.2 / 1.2);
  const taxeAmenagementRaw = eff.surfaceConstructionAmenagementM2 * 930 * 0.075;
  const pvImmoAbatt = clamp(1 - Math.max(0, eff.dureeDetentionPvImmoAns - 5) * 0.05, 0, 1);
  const pvImmoRaw = eff.plusValueImmoBrute * pvImmoAbatt * 0.362;
  const taxeTerrainBateauRaw =
    eff.cessionTerrainDevenuConstructibleGain * 0.08 + eff.taxeEnginsMaritimesLuxe;

  // Capital & Transmission
  const ttfBourse = eff.achatsActionsFrancaisesTtf * 0.004;
  const metauxPrecieuxRaw = eff.ventesMetauxPrecieuxOr * 0.115;
  const droitsSuccessionRaw =
    Math.max(0, eff.montantSuccessionRecue - (eff.lienSuccession === 1 ? 100000 : 1594)) *
    (eff.lienSuccession === 1 ? 0.2 : 0.55);
  const avDecesRaw = Math.max(0, eff.assuranceVieDecesAvant70 - 152500) * 0.2;
  const droitsDonationRaw = Math.max(0, eff.montantDonationRecue - 100000) * 0.18;
  const droitsEnregistrementRaw =
    eff.baseDroitsEnregistrementActes * 0.04 + eff.actifNetPartageDivorceIndivision * 0.011;
  const exitTaxRaw = eff.exitTaxPlusValuesLatentes * 0.314;

  // Entreprise & Holding (séparés par incidence : immédiats vs impôts en attente)
  const isEstime =
    eff.beneficeSocieteAvantIs > 0
      ? Math.min(eff.beneficeSocieteAvantIs, 42500) * 0.15 +
        Math.max(0, eff.beneficeSocieteAvantIs - 42500) * 0.25
      : 0;
  const surtaxeIsGrandesEntreprises =
    eff.chiffreAffairesEntreprise >= 3_000_000_000
      ? isEstime * 0.412
      : eff.chiffreAffairesEntreprise >= 1_000_000_000
        ? isEstime * 0.206
        : 0;
  const impotMereFilleHolding = dividendesEnHoldingBruts * 0.0125;
  const produitsFinanciersHoldingBruts =
    eff.tresorerieAccumuleeHolding * (clamp(eff.rendementTresorerieHoldingPct, 0, 25) / 100);
  const isSurProduitsFinanciersHolding = produitsFinanciersHoldingBruts * 0.25;
  const taxeActifsNonOperationnelsHolding =
    eff.actifsNonOperationnelsHolding > 5_000_000
      ? eff.actifsNonOperationnelsHolding * 0.02
      : 0;

  const taxeRachatActions = eff.montantRachatActionsSociete * 0.08;
  const cfeMontant = eff.cfeAnnuelle;
  const cvaeMontant =
    eff.chiffreAffairesEntreprise > 500000
      ? eff.chiffreAffairesEntreprise * 0.0014
      : 0;
  const c3sTascomBureaux =
    (eff.chiffreAffairesEntreprise > 19000000 ? eff.chiffreAffairesEntreprise * 0.0016 : 0) +
    eff.surfaceCommercialeTascomM2 * 18 +
    eff.surfaceBureauxIdfPacaM2 * 21;
  const cciCma = eff.fraisChambreConsulaire;
  const tvsMontant = eff.tvsVehiculesSociete;
  const tlpeIferSacem =
    eff.tlpePubliciteExterieure +
    eff.iferReseauxEnergieTelecomPro +
    eff.redevanceSacemPro +
    eff.tgapActivitesPolluantesPro;

  const isEstimeRounded = Math.round(isEstime);
  const surtaxeIsRounded = Math.round(surtaxeIsGrandesEntreprises);
  const impotMereFilleRounded = Math.round(impotMereFilleHolding);
  const prodFinHoldingRounded = Math.round(produitsFinanciersHoldingBruts);
  const isProdFinHoldingRounded = Math.round(isSurProduitsFinanciersHolding);
  const taxeActifsNonOpRounded = Math.round(taxeActifsNonOperationnelsHolding);

  const beneficeAvantIs = Math.round(eff.beneficeSocieteAvantIs);
  const beneficeNetApresIs = Math.max(0, beneficeAvantIs - isEstimeRounded - surtaxeIsRounded);
  const dividendesEnHoldingRounded = Math.round(dividendesEnHoldingBruts);
  const fluxNetHoldingAvantTaxe2Pct = Math.max(
    0,
    dividendesEnHoldingRounded -
      impotMereFilleRounded +
      prodFinHoldingRounded -
      isProdFinHoldingRounded
  );
  const reserveRestantEnHolding = Math.max(0, fluxNetHoldingAvantTaxe2Pct - taxeActifsNonOpRounded);
  const beneficeRetenuEnFiliale = Math.max(
    0,
    beneficeNetApresIs - Math.round(eff.dividendesBrutsAnnuels)
  );

  // Calcul des impôts en attente (passif fiscal latent : PFU 31,4 % + CEHR + CDHR 20 %)
  const exitHoldingRes = computeMarginalExitTax(
    reserveRestantEnHolding,
    revenuFiscalReference,
    irPartFoyerApresCdhr,
    isCouple
  );
  const impotLatentSiSortieHolding = Math.min(
    reserveRestantEnHolding,
    Math.round(exitHoldingRes.totalTax)
  );
  const exitFilialeRes = computeMarginalExitTax(
    beneficeRetenuEnFiliale,
    exitHoldingRes.newRfr,
    exitHoldingRes.newIrPart,
    isCouple
  );
  const impotLatentSiSortieFiliale = Math.min(
    beneficeRetenuEnFiliale,
    Math.round(exitFilialeRes.totalTax)
  );
  const totalImpotsEnAttenteFlux = impotLatentSiSortieHolding + impotLatentSiSortieFiliale;

  const exit150OBTerRes = computeMarginalExitTax(
    eff.plusValuesEnReport150OBTer,
    exitFilialeRes.newRfr,
    exitFilialeRes.newIrPart,
    isCouple
  );
  const impotLatentReport150OBTer = Math.round(exit150OBTerRes.totalTax);

  const inclureLatents = state.inclureImpotsLatentsHolding ?? true;

  // ======================== MAP MONTANTS PAR ID DE CATALOGUE ========================
  const amountMap: Record<string, { amount: number; base: number; note: string }> = {
    // 1. Patronales
    pat_maladie: {
      amount: a1.patMaladie + a2.patMaladie,
      base: brutFoyer,
      note: '7 % ≤ 2,5 SMIC puis 13 % (+ Alsace-Moselle)',
    },
    pat_vieillesse_plaf: {
      amount: a1.patVieillessePlaf + a2.patVieillessePlaf,
      base: brutFoyer,
      note: '8,55 % jusqu’au PASS (48 060 €)',
    },
    pat_vieillesse_deplaf: {
      amount: a1.patVieillesseDeplaf + a2.patVieillesseDeplaf,
      base: brutFoyer,
      note: '2,11 % sur 100 % du brut',
    },
    pat_famille: {
      amount: a1.patFamille + a2.patFamille,
      base: brutFoyer,
      note: '3,45 % ≤ 3,3 SMIC / 5,25 % au-delà',
    },
    pat_at_mp: {
      amount: a1.patAtMp + a2.patAtMp,
      base: brutFoyer,
      note: 'Taux moyen 1,9 % (0,4 % fonctionnaires)',
    },
    pat_chomage_ags: {
      amount: a1.patChomageAgs + a2.patChomageAgs,
      base: brutFoyer,
      note: '4,00 % Unédic + 0,25 % AGS',
    },
    pat_agirc_arrco_t1: {
      amount: a1.patAgircT1 + a2.patAgircT1,
      base: brutFoyer,
      note: '4,72 % + CEG 1,29 % (≤ 1 PASS)',
    },
    pat_agirc_arrco_t2: {
      amount: a1.patAgircT2 + a2.patAgircT2,
      base: brutFoyer,
      note: '12,95 % T2 + CEG 1,62 % + CET 0,21 %',
    },
    pat_fnal: {
      amount: a1.patFnal + a2.patFnal,
      base: brutFoyer,
      note: '0,10 % ou 0,50 % selon effectif',
    },
    pat_csa_autonomie: {
      amount: a1.patCsa + a2.patCsa,
      base: brutFoyer,
      note: '0,30 % solidarité autonomie',
    },
    pat_formation_apprentissage: {
      amount: a1.patFormation + a2.patFormation,
      base: brutFoyer,
      note: 'CFP + Taxe apprentissage 0,68 % + Dialogue',
    },
    pat_versement_mobilite: {
      amount: a1.patVersementMobilite + a2.patVersementMobilite,
      base: brutFoyer,
      note: `${tauxVm.toFixed(1)} % (≥ 11 salariés)`,
    },
    pat_forfait_social_taxe_salaires: {
      amount: a1.patForfaitSocialTaxeSalaires + a2.patForfaitSocialTaxeSalaires,
      base: brutFoyer,
      note: 'Forfait social / mutuelle / taxe sur salaires',
    },
    pat_reduction_fillon: {
      amount: -(a1.reductionFillon + a2.reductionFillon),
      base: brutFoyer,
      note: 'Allégement automatique bas salaires (< 1,6 SMIC) ou apprenti',
    },

    // 2. Salariales & Sociales
    sal_vieillesse_plaf: {
      amount: a1.salVieillessePlaf + a2.salVieillessePlaf,
      base: brutFoyer,
      note: '6,90 % ≤ PASS (réduit apprentis)',
    },
    sal_vieillesse_deplaf: {
      amount: a1.salVieillesseDeplaf + a2.salVieillesseDeplaf,
      base: brutFoyer,
      note: '0,40 % sur tout le salaire brut',
    },
    sal_agirc_arrco_t1: {
      amount: a1.salAgircT1 + a2.salAgircT1,
      base: brutFoyer,
      note: '3,15 % + CEG 0,86 %',
    },
    sal_agirc_arrco_t2: {
      amount: a1.salAgircT2 + a2.salAgircT2,
      base: brutFoyer,
      note: '8,64 % T2 + CEG 1,08 % + CET 0,14 %',
    },
    sal_csg_deductible: {
      amount: a1.salCsgDed + a2.salCsgDed,
      base: brutFoyer,
      note: '6,8 % salaire ou 3,8 %–5,9 % pension/chômage',
    },
    sal_csg_non_deductible: {
      amount: a1.salCsgNonDed + a2.salCsgNonDed,
      base: brutFoyer,
      note: '2,40 % soumise elle-même à l’IR',
    },
    sal_crds: {
      amount: a1.salCrds + a2.salCrds,
      base: brutFoyer,
      note: '0,50 % dette sociale (CADES)',
    },
    sal_apec_alsace: {
      amount: a1.salApecAlsace + a2.salApecAlsace,
      base: brutFoyer,
      note: '0,024 % cadres APEC + 1,3 % Alsace-Moselle',
    },
    sal_casa_retraites: {
      amount: a1.salCasa + a2.salCasa,
      base: brutFoyer,
      note: '0,30 % sur pensions imposables CSG',
    },
    tns_urssaf_micro: {
      amount: a1.tnsUrssafMicro + a2.tnsUrssafMicro,
      base: brutFoyer,
      note: 'Cotisations sociales TNS ou Micro-entrepreneur',
    },

    // 3. Revenu
    ir_bareme_travail: {
      amount: irHorsLoyers,
      base: revenuImposableActiviteFoyer,
      note: `${partsFiscales} part(s) · TMI ${irTravResult.tmiPct} %`,
    },
    ir_cehr: {
      amount: cehrTotal,
      base: revenuFiscalReference,
      note: '3 % à 4 % au-dessus de 250k€ / 500k€ RFR',
    },
    ir_cdhr_2025: {
      amount: cdhrMontant,
      base: revenuFiscalReference,
      note: 'Plancher minimal 20 % IR/PFU (> 250k€ / 500k€)',
    },
    pas_info: {
      amount: 0,
      base: irNetApresCredits,
      note: 'Mémo collecte mensuelle à la source (inclus dans IR)',
    },

    // 4. TVA, Douane & Achats
    tva_20: { amount: tva20, base: eff.depensesTva20, note: '20 % HT (16,67 % TTC)' },
    tva_10: { amount: tva10, base: eff.depensesTva10, note: '10 % HT (9,09 % TTC)' },
    tva_55: { amount: tva55, base: eff.depensesTva55, note: '5,5 % HT (5,21 % TTC)' },
    tva_21: { amount: tva21, base: eff.depensesTva21, note: '2,1 % HT (2,06 % TTC)' },
    droits_douane_ue: {
      amount: douaneHorsUe,
      base: eff.achatsHorsUeDouane,
      note: '~6,8 % moyen sur biens/colis hors UE',
    },
    copie_privee: {
      amount: copiePrivee,
      base: eff.achatsHighTechNeufs,
      note: 'Barème matériel numérique à mémoire',
    },
    eco_contributions_rep: {
      amount: ecoRep,
      base: eff.achatsEquipementMaison,
      note: 'DEEE, mobilier, emballages Citeo',
    },
    taxe_telecom_arcep: {
      amount: taxeTelecom,
      base: eff.abonnementsTelecomStreaming,
      note: '1,30 % sur forfaits fibre/mobile',
    },
    taxe_streaming_svod_cnc: {
      amount: taxeStreamingCnc,
      base: eff.abonnementsTelecomStreaming,
      note: '5,15 % sur plateformes vidéo (CNC)',
    },
    redevance_tv_abrogee_memo: {
      amount: 0,
      base: 0,
      note: 'Supprimée (0 €) — remplacée par fraction TVA',
    },

    // 5. Énergie, Eau & Déchets
    accise_elec_ticfe: {
      amount: acciseElec,
      base: eff.consoElectriciteKwh,
      note: `${eff.consoElectriciteKwh} kWh × 0,0337 €`,
    },
    cta_elec: {
      amount: ctaElec,
      base: eff.abonnementElectriciteAnnuelHt,
      note: '21,93 % acheminement fixe',
    },
    tva_elec: {
      amount: tvaElec,
      base: factureElecTtc,
      note: '20 % conso + 5,5 % abo (inclut TVA sur accise)',
    },
    accise_gaz_ticgn: {
      amount: acciseGaz,
      base: eff.consoGazKwh,
      note: `${eff.consoGazKwh} kWh × 0,01716 €`,
    },
    cta_gaz: {
      amount: ctaGaz,
      base: eff.abonnementGazAnnuelHt,
      note: '20,8 % acheminement gaz',
    },
    tva_gaz: {
      amount: tvaGaz,
      base: baseGazConsoHt + eff.abonnementGazAnnuelHt,
      note: '20 % conso + 5,5 % abo',
    },
    accise_tva_fioul: {
      amount: taxesFioulTotal,
      base: eff.consoFioulLitres,
      note: `${eff.consoFioulLitres} L fioul domestique`,
    },
    redevances_agences_eau: {
      amount: redevancesEau,
      base: eff.consoEauM3,
      note: `${eff.consoEauM3} m³ × 0,62 €`,
    },
    tva_eau: {
      amount: tvaEau,
      base: eff.consoEauM3 * 4.5,
      note: '5,5 % eau potable + 10 % assainissement',
    },
    teom_reom: {
      amount: teomReom,
      base: teomReom,
      note: 'Taxe/Redevance ordures ménagères',
    },
    taxe_balayage: {
      amount: taxeBalayage,
      base: taxeBalayage,
      note: 'Nettoyage trottoirs et voiries',
    },
    tgap_dechets: {
      amount: tgapDechets,
      base: eff.dechetsTonnesIndirects,
      note: `${eff.dechetsTonnesIndirects} t enfouissement/incinération`,
    },

    // 6. Auto, Carburants & Voyages
    accise_carburant_ticpe: {
      amount: acciseCarburant,
      base: litresCarburant,
      note: `${Math.round(litresCarburant)} L × ${tauxTicpe.toFixed(2)} €`,
    },
    tva_carburant: {
      amount: tvaCarburant,
      base: litresCarburant * prixLitre,
      note: '20 % HT sur carburant + TICPE',
    },
    carte_grise: {
      amount: carteGriseRaw * oneOffFactor,
      base: eff.chevauxFiscauxVehicule,
      note: `${eff.chevauxFiscauxVehicule} CV (${state.lisserTaxesPonctuelles ? 'lissé 8 ans' : 'année achat'})`,
    },
    malus_co2: {
      amount: malusCo2Raw * oneOffFactor,
      base: eff.emissionsCo2Gkm,
      note: `${eff.emissionsCo2Gkm} g/km CO₂`,
    },
    malus_poids_tmom: {
      amount: malusPoidsRaw * oneOffFactor,
      base: eff.poidsVehiculeKg,
      note: `${eff.poidsVehiculeKg} kg`,
    },
    peages_tva: {
      amount: peagesTva,
      base: eff.peagesAutorouteAnnuelsTtc,
      note: '20 % HT sur péages autoroutiers',
    },
    peages_tat_domaniale: {
      amount: peagesTat,
      base: eff.peagesAutorouteAnnuelsTtc,
      note: '~8,8 % taxes TAT & redevance domaniale',
    },
    tva_transports_commun: {
      amount: tvaTransportsCommun,
      base: eff.transportsCommunTrainTtc,
      note: '10 % HT sur train, métro, bus',
    },
    taxes_aeriennes_tsba: {
      amount: taxesAeriennes,
      base: eff.volsEuropeEcoNb + eff.volsLongCourrierEcoNb + eff.volsAffairesNb,
      note: 'TSBA « Chirac » 2026 + TAC + sûreté',
    },
    taxe_maritime_barnier: {
      amount: taxeMaritime,
      base: eff.traverseesMaritimesNb,
      note: 'Loi Barnier traversées maritimes',
    },
    taxe_sejour: {
      amount: taxeSejour,
      base: eff.nuiteesHotelLocationFrance,
      note: `${eff.nuiteesHotelLocationFrance} nuitées × ${eff.tarifTaxeSejourNuit.toFixed(1)} €`,
    },
    timbres_fiscaux_admin: {
      amount: timbresFiscaux,
      base: eff.timbresFiscauxAmendesAnnuels,
      note: 'Passeport, titre séjour, justice',
    },
    amendes_fps: {
      amount: amendesFps,
      base: eff.timbresFiscauxAmendesAnnuels,
      note: 'Contraventions & FPS stationnement',
    },

    // 7. Tabac, Boissons, Assurances & Jeux
    accise_tabac: {
      amount: acciseTabac,
      base: depenseTabac,
      note: `${paquetsAn} paquets/an (~65,5 % accise)`,
    },
    tva_tabac: {
      amount: tvaTabac,
      base: depenseTabac,
      note: '16,67 % du prix du paquet',
    },
    accise_vins_bieres: {
      amount: accisesVinsBieres,
      base: eff.consoVinLitresAn + eff.consoBiereLitresAn,
      note: 'Droits de circulation vins & bières',
    },
    accise_spiritueux_vignette: {
      amount: accisesSpiritueux,
      base: eff.consoSpiritueuxLitresAn,
      note: 'Accises + vignette Sécu > 18°',
    },
    taxe_sodas_sucres: {
      amount: taxeSodasSucres,
      base: eff.consoSodasSucresLitresAn,
      note: 'Barème sucre ajouté renforcé',
    },
    taxe_sodas_edulcores: {
      amount: taxeSodasEdulcores,
      base: eff.consoSodasEdulcoresLitresAn,
      note: 'Boissons light / zéro',
    },
    surtaxe_eaux_minerales: {
      amount: surtaxeEaux,
      base: eff.consoEauxMineralesLitresAn,
      note: '0,58 €/hL eaux embouteillées',
    },
    tsca_auto: {
      amount: tscaAuto,
      base: eff.primeAssuranceAutoTtc,
      note: '18 % à 33 % sur prime auto',
    },
    tsca_habitation: {
      amount: tscaHabitation,
      base: eff.primeAssuranceHabitationTtc,
      note: '9 % MRH & prévoyance',
    },
    tsca_mutuelle_tsa: {
      amount: tsaMutuelle,
      base: eff.primeMutuelleSanteTtc,
      note: '13,27 % TSA mutuelle santé',
    },
    taxe_catnat: {
      amount: taxeCatNat,
      base: eff.primeAssuranceHabitationTtc,
      note: '20 % Cat-Nat habitation',
    },
    taxe_attentats_fgti: {
      amount: taxeAttentatsFgti,
      base: eff.nbContratsAssuranceBiens,
      note: `${eff.nbContratsAssuranceBiens} contrats × 6,50 €`,
    },
    taxe_fgao_garantie_auto: {
      amount: taxeFgao,
      base: eff.primeAssuranceAutoTtc,
      note: '1,2 % Fonds garantie auto',
    },
    taxes_fdj_loto_paris: {
      amount: taxesFdjParis,
      base: eff.misesJeuxLoterieParisAn,
      note: 'FDJ, Loto, paris sportifs',
    },
    taxes_hippiques_casinos: {
      amount: taxesHippiquesCasinos,
      base: eff.misesParisHippiquesCasinosAn,
      note: 'PMU & casinos',
    },
    taxe_spectacles_cinema: {
      amount: taxesSpectacles,
      base: eff.depensesSpectaclesCinemaTtc,
      note: 'CNC 10,72 % & CNM 3,5 %',
    },

    // 8. Immobilier & Patrimoine
    taxe_fonciere: {
      amount: taxeFonciere,
      base: taxeFonciere,
      note: 'TFPB + GEMAPI',
    },
    taxe_habitation_secondaire: {
      amount: thSecondaire,
      base: thSecondaire,
      note: 'Résidence secondaire uniquement',
    },
    taxe_logements_vacants: {
      amount: taxeVacants,
      base: eff.valeurLocativeLogementVacant,
      note: '17 % à 34 % valeur locative',
    },
    ifi: {
      amount: ifiMontant,
      base: eff.patrimoineImmoNetIfi,
      note: 'Patrimoine immo net > 1,3 M€',
    },
    ir_revenus_fonciers: {
      amount: irSurLoyers,
      base: eff.loyersNetsFonciersAnnuels,
      note: 'TMI + 17,2 % prélèvements sociaux',
    },
    taxe_micro_logements_art234: {
      amount: taxeMicroLogements,
      base: taxeMicroLogements,
      note: 'Surtaxe Art. 234 (< 14 m²)',
    },
    dmto_frais_notaire: {
      amount: dmtoNotaireRaw * oneOffFactor,
      base: eff.achatImmobilierPrixAncien + eff.achatImmobilierPrixNeuf,
      note: `~5,9 % ancien (${state.lisserTaxesPonctuelles ? 'lissé 8 ans' : 'année achat'})`,
    },
    tva_immo_neuf: {
      amount: tvaImmoNeufRaw * oneOffFactor,
      base: eff.achatImmobilierPrixNeuf,
      note: '20 % HT sur VEFA',
    },
    taxe_amenagement_immo: {
      amount: taxeAmenagementRaw * oneOffFactor,
      base: eff.surfaceConstructionAmenagementM2,
      note: 'Construction / extension / piscine',
    },
    pv_immobiliere: {
      amount: pvImmoRaw * oneOffFactor,
      base: eff.plusValueImmoBrute,
      note: '19 % IR + 17,2 % PS hors RP',
    },
    taxe_terrain_constructible_luxe: {
      amount: taxeTerrainBateauRaw * oneOffFactor,
      base: eff.cessionTerrainDevenuConstructibleGain + eff.taxeEnginsMaritimesLuxe,
      note: 'Terrain constructible / DAFN bateau',
    },

    // 9. Capital, Transmission, Entreprise & Holding
    pfu_dividendes_poche: {
      amount: pfuDividendes,
      base: dividendesEnPocheBruts,
      note:
        dividendesEnHoldingBruts > 0
          ? `31,4 % uniquement sur les ${Math.round(dividendesEnPocheBruts).toLocaleString('fr-FR')} € sortis en poche`
          : '12,8 % IR + 18,6 % PS (LFSS 2026)',
    },
    pfu_interets_fiscalises: {
      amount: pfuInterets,
      base: eff.interetsBrutsFiscalisesAnnuels,
      note: '31,4 % sur comptes fiscalisés (Livret A = 0 %)',
    },
    pfu_assurance_vie_rachat: {
      amount: pfuAssuranceVie,
      base: eff.gainsAssuranceVieRachat,
      note: 'PS 17,2 % + PFL/PFU après abattement',
    },
    pfu_plus_values_mobilieres: {
      amount: pfuPvMobilieres,
      base: eff.plusValuesMobilieresBrutes,
      note: '31,4 % à la vente effective',
    },
    pfu_plus_values_crypto: {
      amount: pfuCrypto,
      base: eff.plusValuesCryptoBrutes,
      note: '31,4 % sur gains convertis > 305 €',
    },
    aga_bspce_gains: {
      amount: agaBspceImpots,
      base: eff.actionsGratuitesBspceGains,
      note: 'Contribution salariale + PFU/IR',
    },
    pfu_total_memo: {
      amount: 0,
      base: 31.4,
      note: 'Mémo taux PFU 2026 = 31,4 % (non cumulé deux fois)',
    },
    ttf_bourse: {
      amount: ttfBourse,
      base: eff.achatsActionsFrancaisesTtf,
      note: '0,40 % à l’achat actions FR',
    },
    taxe_metaux_precieux: {
      amount: metauxPrecieuxRaw * oneOffFactor,
      base: eff.ventesMetauxPrecieuxOr,
      note: '11,5 % à la revente d’or/métaux',
    },
    droits_succession: {
      amount: droitsSuccessionRaw * oneOffFactor,
      base: eff.montantSuccessionRecue,
      note: 'Après abattement 100k€ enfant',
    },
    assurance_vie_deces: {
      amount: avDecesRaw * oneOffFactor,
      base: eff.assuranceVieDecesAvant70,
      note: '20 % au-delà de 152 500 €',
    },
    droits_donation: {
      amount: droitsDonationRaw * oneOffFactor,
      base: eff.montantDonationRecue,
      note: 'Barème après abattements',
    },
    droits_enregistrement_partage: {
      amount: droitsEnregistrementRaw * oneOffFactor,
      base: eff.baseDroitsEnregistrementActes + eff.actifNetPartageDivorceIndivision,
      note: '1,1 % partage / 4 % actes',
    },
    exit_tax_latentes: {
      amount: exitTaxRaw * oneOffFactor,
      base: eff.exitTaxPlusValuesLatentes,
      note: '31,4 % sur PV latentes si expatriation',
    },
    impot_societes_is: {
      amount: isEstimeRounded,
      base: eff.beneficeSocieteAvantIs,
      note: '15 % ≤ 42,5k€ puis 25 % (payé par la société)',
    },
    surtaxe_is_grandes_entreprises: {
      amount: surtaxeIsRounded,
      base: eff.chiffreAffairesEntreprise,
      note:
        eff.chiffreAffairesEntreprise >= 3_000_000_000
          ? '+41,2 % surtaxe IS (CA ≥ 3 Md€)'
          : eff.chiffreAffairesEntreprise >= 1_000_000_000
            ? '+20,6 % surtaxe IS (CA ≥ 1 Md€)'
            : 'Sous seuil 1 Md€ CA',
    },
    holding_mere_fille_qpfc: {
      amount: impotMereFilleRounded,
      base: dividendesEnHoldingBruts,
      note: '1,25 % immédiat sur remontée en holding (argent bloqué)',
    },
    holding_is_produits_financiers: {
      amount: isProdFinHoldingRounded,
      base: prodFinHoldingRounded,
      note: `25 % d’IS sur ${prodFinHoldingRounded.toLocaleString('fr-FR')} € de rendement trésorerie holding`,
    },
    holding_taxe_patrimoniale_2pct: {
      amount: taxeActifsNonOpRounded,
      base: eff.actifsNonOperationnelsHolding,
      note:
        eff.actifsNonOperationnelsHolding > 5_000_000
          ? '2 % LF 2026 sur actifs non opérationnels (> 5 M€)'
          : 'Sous seuil 5 M€ actifs passifs',
    },
    holding_impot_latent_sortie: {
      amount: inclureLatents ? totalImpotsEnAttenteFlux : 0,
      base: reserveRestantEnHolding + beneficeRetenuEnFiliale,
      note: inclureLatents
        ? `PFU 31,4 % + CEHR + CDHR en attente (Holding ${impotLatentSiSortieHolding.toLocaleString('fr-FR')} € + Filiale ${impotLatentSiSortieFiliale.toLocaleString('fr-FR')} €)`
        : 'Passif latent non provisionné (option décochée)',
    },
    taxe_rachat_actions: {
      amount: taxeRachatActions,
      base: eff.montantRachatActionsSociete,
      note: '8 % sur rachat d’actions (> 1 Md€ CA)',
    },
    cfe: {
      amount: cfeMontant,
      base: eff.chiffreAffairesEntreprise,
      note: 'Cotisation foncière des entreprises',
    },
    cvae: {
      amount: cvaeMontant,
      base: eff.chiffreAffairesEntreprise,
      note: 'Entreprises > 500 k€ CA',
    },
    c3s_tascom_bureaux: {
      amount: c3sTascomBureaux,
      base: eff.chiffreAffairesEntreprise,
      note: 'C3S + TASCOM + Taxe bureaux',
    },
    chambres_consulaires_cma_cci: {
      amount: cciCma,
      base: eff.chiffreAffairesEntreprise,
      note: 'CCI / Chambre des Métiers',
    },
    tvs_vehicules_societe: {
      amount: tvsMontant,
      base: eff.tvsVehiculesSociete,
      note: 'Taxes véhicules de société',
    },
    tlpe_sacem_ifer_tgap_pro: {
      amount: tlpeIferSacem,
      base: tlpeIferSacem,
      note: 'Enseignes, réseaux, SACEM, TGAP pro',
    },
  };

  // ======================== CONSTRUCTION ITEMS & SÉPARATION INCIDENCE ========================
  const items: ComputedTaxItem[] = [];
  const itemsById: Record<string, ComputedTaxItem> = {};

  let impotsPersonnelsSeuls = 0;
  let impotsEntrepriseImmediats = 0;
  let impotsEnAttenteHolding = 0;
  let impotsPayesParEntreprise = 0;

  let impotsVisibles = 0;
  let impotsSemiVisibles = 0;
  let impotsCaches = 0;

  const parBeneficiaire: Record<BeneficiaryId, number> = {
    etat: 0,
    secu: 0,
    collectivites: 0,
    organismes: 0,
  };

  const familyTotals: Record<TaxFamilyId, { amount: number; items: ComputedTaxItem[] }> = {
    patronales: { amount: 0, items: [] },
    salariales_sociales: { amount: 0, items: [] },
    revenu: { amount: 0, items: [] },
    tva_conso: { amount: 0, items: [] },
    energie_mobilite: { amount: 0, items: [] },
    accises_assurances: { amount: 0, items: [] },
    immobilier_patrimoine: { amount: 0, items: [] },
    capital_entreprise: { amount: 0, items: [] },
  };

  let activeTaxCount = 0;

  for (const entry of FISCAL_CATALOG) {
    const raw = amountMap[entry.id] ?? { amount: 0, base: 0, note: '' };
    const isMemo = Boolean(entry.isMemoOnly);
    const amount = isMemo ? 0 : Math.round(raw.amount);

    const item: ComputedTaxItem = {
      entry,
      amount,
      baseAmount: Math.round(raw.base),
      effectiveRateOnBase:
        raw.base > 0 && !isMemo ? Number(((amount / raw.base) * 100).toFixed(2)) : 0,
      formulaNote: raw.note,
    };

    items.push(item);
    itemsById[entry.id] = item;

    if (isMemo) continue;

    const isCorpOrHolding =
      entry.incidence === 'entreprise_societe' || entry.incidence === 'holding_en_attente';
    const isLatentProvision = entry.id === 'holding_impot_latent_sortie';

    if (isCorpOrHolding) {
      impotsPayesParEntreprise += amount;
      if (isLatentProvision) {
        impotsEnAttenteHolding += amount;
      } else {
        impotsEntrepriseImmediats += amount;
      }
    } else {
      impotsPersonnelsSeuls += amount;
    }

    // Est-ce inclus dans le total affiché ?
    const includedInHeadline = !isCorpOrHolding || state.inclureTaxesSocieteEtHolding;

    if (includedInHeadline) {
      if (amount > 0) activeTaxCount++;

      familyTotals[entry.family].amount += amount;
      familyTotals[entry.family].items.push(item);
      parBeneficiaire[entry.beneficiary] += Math.max(0, amount);

      if (entry.visibility === 'visible') impotsVisibles += amount;
      else if (entry.visibility === 'semi_visible') impotsSemiVisibles += amount;
      else impotsCaches += amount;
    }
  }

  const taxesProdRounded =
    impotsEntrepriseImmediats -
    isEstimeRounded -
    surtaxeIsRounded -
    impotMereFilleRounded -
    isProdFinHoldingRounded -
    taxeActifsNonOpRounded;

  const cehrPartDividendes =
    revenuFiscalReference > 0
      ? Math.round(
          (cehrTotal + cdhrMontant) *
            clamp(dividendesEnPocheBruts / Math.max(1, revenuFiscalReference), 0, 1)
        )
      : 0;
  const cashNetRecuEnPocheDepuisCapital = Math.max(
    0,
    Math.round(dividendesEnPocheBruts - pfuDividendes - cehrPartDividendes)
  );

  const valorisationPapierEstimee = eff.valorisationEntrepriseEstimee;
  const decoteLiquiditeCessionEuros = Math.round(
    valorisationPapierEstimee * (clamp(eff.decoteLiquiditeCessionPct, 0, 65) / 100)
  );
  const prixVenteReelAvantImpot = Math.max(
    0,
    valorisationPapierEstimee - decoteLiquiditeCessionEuros
  );
  const cessionExitRes = computeMarginalExitTax(prixVenteReelAvantImpot, 0, 0, isCouple);
  const impotCessionSiVenteTotale = Math.round(cessionExitRes.totalTax);
  const cashReelSiToutVendu = Math.max(0, prixVenteReelAvantImpot - impotCessionSiVenteTotale);

  const reservesBrutesSocieteEtHolding = reserveRestantEnHolding + beneficeRetenuEnFiliale;
  const reservesNettesApresImpotsEnAttente = Math.max(
    0,
    reservesBrutesSocieteEtHolding - totalImpotsEnAttenteFlux
  );

  const holdingAndValuation: HoldingAndValuationBreakdown = {
    beneficeAvantIs,
    impotSocietePayeParEntreprise: isEstimeRounded,
    surtaxeIsGrandesEntreprises: surtaxeIsRounded,
    taxesProductionEntreprise: taxesProdRounded,
    beneficeNetApresIs,
    beneficeRetenuEnFiliale,
    montantRemonteEnHolding: dividendesEnHoldingRounded,
    impotMereFilleHolding: impotMereFilleRounded,
    produitsFinanciersHoldingBruts: prodFinHoldingRounded,
    isSurProduitsFinanciersHolding: isProdFinHoldingRounded,
    taxeActifsNonOperationnelsHolding: taxeActifsNonOpRounded,
    reserveRestantEnHolding,
    impotLatentSiSortieHolding,
    impotLatentSiSortieFiliale,
    impotLatentReport150OBTer,
    totalImpotsEnAttenteFlux,
    totalImpotsEnAttenteAvecStock150OBTer: totalImpotsEnAttenteFlux + impotLatentReport150OBTer,
    reservesNettesApresImpotsEnAttente,
    montantSortiVersPoche: Math.round(dividendesEnPocheBruts),
    impotSortieFlatTaxCehr: Math.round(pfuDividendes + cehrPartDividendes),
    cashNetRecuEnPocheDepuisCapital,
    valorisationPapierEstimee: Math.round(valorisationPapierEstimee),
    decoteMarcheLiquiditeEuros: decoteLiquiditeCessionEuros,
    impotCessionSiVenteTotale,
    cashReelSiToutVendu,
    aidesPubliquesEntrepriseCirBpi: Math.round(eff.aidesPubliquesEntrepriseCirBpi),
  };

  // Totaux généraux (100 % inclus si state.inclureTaxesSocieteEtHolding)
  const impotsEnAttenteActifs = state.inclureTaxesSocieteEtHolding ? impotsEnAttenteHolding : 0;
  const totalPrelevements = state.inclureTaxesSocieteEtHolding
    ? impotsPersonnelsSeuls + impotsPayesParEntreprise
    : impotsPersonnelsSeuls;

  // Richesse créée totale (dénominateur comptable exact : chaque euro vient de la valeur produite)
  const baseRichessePersonnelle =
    superBrutFoyer +
    eff.loyersNetsFonciersAnnuels +
    dividendesEnPocheBruts +
    eff.interetsBrutsFiscalisesAnnuels +
    eff.gainsAssuranceVieRachat +
    eff.plusValuesMobilieresBrutes +
    eff.plusValuesCryptoBrutes +
    eff.actionsGratuitesBspceGains;

  // En vue 100 % société+holding : richesse société = taxes immédiates + réserves brutes (qui incluent les impôts en attente + réserves nettes)
  const baseRichesseEntrepriseEtHolding = state.inclureTaxesSocieteEtHolding
    ? impotsEntrepriseImmediats + reservesBrutesSocieteEtHolding
    : 0;

  const richesseCreeeTotale = Math.max(
    0,
    Math.round(baseRichessePersonnelle) + baseRichesseEntrepriseEtHolding
  );

  // Réserves nettes restantes après provision des impôts en attente (garantit 0 double comptage et 0 € d'écart)
  const reservesBloqueesNonSorties = state.inclureTaxesSocieteEtHolding
    ? Math.max(0, reservesBrutesSocieteEtHolding - impotsEnAttenteActifs)
    : 0;

  // Cascade en 5 étages (exactement réconciliée au centime près)
  const prelevEtape1SourceEntreprisePatronal =
    familyTotals.patronales.amount +
    (state.inclureTaxesSocieteEtHolding ? impotsPayesParEntreprise : 0);
  const prelevEtape2CotisSalarialesCsgTns = familyTotals.salariales_sociales.amount;
  const prelevEtape3IrPfuCapitalTransmission =
    familyTotals.revenu.amount +
    Math.max(
      0,
      familyTotals.capital_entreprise.amount -
        (state.inclureTaxesSocieteEtHolding ? impotsPayesParEntreprise : 0)
    );

  // Étape 4 : Immobilier (taxe foncière, TEOM, balayage, IFI, DMTO...)
  const teomBalayageAmount = Math.round(teomReom + taxeBalayage);
  const prelevEtape4PatrimoineLocaux = familyTotals.immobilier_patrimoine.amount;

  // Étape 5 : Consommation (TVA + Énergie/Auto + Accises/Assurances)
  const prelevEtape5ConsommationTvaAccises =
    familyTotals.tva_conso.amount +
    familyTotals.energie_mobilite.amount +
    familyTotals.accises_assurances.amount;

  const etape1SuperBrutEtCreation = richesseCreeeTotale;
  const etape2RevenuBrutPersonnel = Math.max(
    0,
    etape1SuperBrutEtCreation - prelevEtape1SourceEntreprisePatronal - reservesBloqueesNonSorties
  );
  const etape3RevenuNetAvantImpots = Math.max(
    0,
    etape2RevenuBrutPersonnel - prelevEtape2CotisSalarialesCsgTns
  );
  const etape4RevenuDisponibleNet = Math.max(
    0,
    etape3RevenuNetAvantImpots - prelevEtape3IrPfuCapitalTransmission
  );

  // Règle d'expert-comptable :
  // Richesse créée = Impôts totaux (immédiats + en attente) + Réserves nettes bloquées + Reste net en poche personnelle
  const resteNetReelPur =
    richesseCreeeTotale - totalPrelevements - reservesBloqueesNonSorties;
  const resteNetApresAidesEtTaxes = resteNetReelPur + aides.totalAidesMonetaires;
  const ecartBalanceComptable =
    richesseCreeeTotale - (totalPrelevements + reservesBloqueesNonSorties + resteNetReelPur);

  const denomBrut = Math.max(richesseCreeeTotale, aides.totalAidesMonetaires, 1);
  const tauxPrelevementReelPct = Number(((totalPrelevements / denomBrut) * 100).toFixed(1));

  // Deux taux nets après redistribution :
  // 1) Aides monétaires seules (CAF, CROUS, Chèque énergie)
  const denomRedistMonetaire = Math.max(richesseCreeeTotale, aides.totalAidesMonetaires, 1);
  const tauxNetApresAidesMonetairesPct = Number(
    (((totalPrelevements - aides.totalAidesMonetaires) / denomRedistMonetaire) * 100).toFixed(1)
  );

  // 2) Taux Net Intégral 100 % (aides monétaires + études gratuites + santé CNAM + droits retraite/chômage + services publics)
  const denomRedistComplet = Math.max(richesseCreeeTotale, aides.totalAidesEtServicesComplet, 1);
  const tauxNetApresAidesPct = Number(
    (((totalPrelevements - aides.totalAidesEtServicesComplet) / denomRedistComplet) * 100).toFixed(1)
  );

  const epargneNetteAnnuelle = Math.max(
    0,
    Math.round(revenuDisponiblePourConso * clamp(state.tauxEpargnePct / 100, 0, 0.85))
  );
  const consommationPureHorsTaxes = Math.max(
    0,
    resteNetApresAidesEtTaxes - epargneNetteAnnuelle
  );

  // Calendrier de Libération Fiscale (basé sur taux brut réel, borné 0..365)
  const joursPourEtat =
    richesseCreeeTotale > 100
      ? clamp(
          Math.round((clamp(totalPrelevements, 0, richesseCreeeTotale) / richesseCreeeTotale) * 365),
          0,
          365
        )
      : 0;
  const joursPourVous = 365 - joursPourEtat;
  const jourLiberationDate = formatFrenchDateFromDayIndex(joursPourEtat);

  const totalPourParts = Math.max(1, totalPrelevements);
  const families: FamilyBreakdown[] = (Object.keys(TAX_FAMILIES) as TaxFamilyId[]).map((fid) => {
    const meta = TAX_FAMILIES[fid];
    const amt = familyTotals[fid].amount;
    return {
      id: fid,
      label: meta.label,
      shortLabel: meta.shortLabel,
      color: meta.color,
      lightBg: meta.lightBg,
      borderColor: meta.borderColor,
      amount: amt,
      shareOfTotalTax: Number(((amt / totalPourParts) * 100).toFixed(1)),
      shareOfWealth:
        richesseCreeeTotale > 100
          ? Number(((amt / richesseCreeeTotale) * 100).toFixed(1))
          : 0,
      items: familyTotals[fid].items,
    };
  });

  // Scanners du quotidien
  const pCarb = prixLitre || 1.79;
  const carbTva = pCarb * (0.2 / 1.2);
  const carbAccise = tauxTicpe > 0 ? tauxTicpe : 0.672;
  const carbTvaSurAccise = carbAccise * 0.2;
  const carbTvaSurProduit = Math.max(0, carbTva - carbTvaSurAccise);
  const carbHtPur = Math.max(0, pCarb - carbAccise - carbTva);
  const carbTaxPct = ((carbAccise + carbTva) / pCarb) * 100;

  const elecTaxes = acciseElec + ctaElec + tvaElec;
  const elecTaxPct = factureElecTtc > 0 ? (elecTaxes / factureElecTtc) * 100 : 0;

  const pTabac = eff.prixPaquetCigarettes || 13.0;
  const tabacAccise = pTabac * 0.655;
  const tabacTva = pTabac * (0.2 / 1.2);
  const tabacHtPur = Math.max(0, pTabac - tabacAccise - tabacTva);
  const tabacTaxPct = ((tabacAccise + tabacTva) / pTabac) * 100;

  const assTaxPct = totalAssurancesTtc > 0 ? (totalAssurancesTaxes / totalAssurancesTtc) * 100 : 0;

  const tauxPasMoyenPct =
    brutFoyer > 0 ? Number(((irNetApresCredits / Math.max(1, netAvantIrFoyer)) * 100).toFixed(1)) : 0;

  return {
    richesseCreeeTotale,
    totalPrelevements,
    impotsPersonnelsSeuls: Math.round(impotsPersonnelsSeuls),
    impotsEntrepriseImmediats: Math.round(impotsEntrepriseImmediats),
    impotsEnAttenteHolding: Math.round(impotsEnAttenteHolding),
    impotsPayesParEntreprise: Math.round(impotsPayesParEntreprise),
    resteNetReelPur: Math.round(resteNetReelPur),
    resteNetApresAidesEtTaxes: Math.round(resteNetApresAidesEtTaxes),
    tauxPrelevementReelPct,
    tauxNetApresAidesMonetairesPct,
    tauxNetApresAidesPct,
    ecartBalanceComptable,
    aides,
    holdingAndValuation,
    etape1SuperBrutEtCreation,
    prelevEtape1SourceEntreprisePatronal,
    etape2RevenuBrutPersonnel,
    prelevEtape2CotisSalarialesCsgTns,
    etape3RevenuNetAvantImpots,
    prelevEtape3IrPfuCapitalTransmission,
    etape4RevenuDisponibleNet,
    prelevEtape4PatrimoineLocaux,
    prelevEtape5ConsommationTvaAccises,
    epargneNetteAnnuelle,
    consommationPureHorsTaxes: Math.round(consommationPureHorsTaxes),
    superBrutFoyer: Math.round(superBrutFoyer),
    brutFoyer: Math.round(brutFoyer),
    netAvantIrFoyer: Math.round(netAvantIrFoyer),
    netApresIrFoyer: Math.round(netApresIrFoyer),
    reductionFillonAnnuelle: Math.round(a1.reductionFillon + a2.reductionFillon),
    nombrePartsFiscales: partsFiscales,
    revenuFiscalReference,
    tmiPct: irTravResult.tmiPct,
    tauxPasMoyenPct,
    pasMensuel: Math.round(irNetApresCredits / 12),
    pfuTotalMemo: Math.round(pfuDividendes + pfuInterets + pfuPvMobilieres + pfuCrypto),
    jourLiberationIndex: joursPourEtat,
    jourLiberationDate,
    joursPourEtat,
    joursPourVous,
    impotsVisibles: Math.round(impotsVisibles),
    impotsSemiVisibles: Math.round(impotsSemiVisibles),
    impotsCaches: Math.round(impotsCaches),
    partImpotsCachesPct: Number((((impotsCaches + impotsSemiVisibles) / totalPourParts) * 100).toFixed(1)),
    parBeneficiaire,
    families,
    items,
    itemsById,
    activeTaxCount,
    totalCatalogCount: FISCAL_CATALOG.filter((c) => !c.isMemoOnly).length,
    effective: eff,
    overriddenKeys,
    everydayBreakdown: {
      carburantPrixLitre: pCarb,
      carburantHtPur: Number(carbHtPur.toFixed(2)),
      carburantAccise: Number(carbAccise.toFixed(2)),
      carburantTvaSurAccise: Number(carbTvaSurAccise.toFixed(2)),
      carburantTvaSurProduit: Number(carbTvaSurProduit.toFixed(2)),
      carburantTaxPct: Number(carbTaxPct.toFixed(1)),
      electriciteFactureTtc: Math.round(factureElecTtc),
      electriciteTaxesTotal: Math.round(elecTaxes),
      electriciteTaxPct: Number(elecTaxPct.toFixed(1)),
      tabacPrixPaquet: pTabac,
      tabacAccise: Number(tabacAccise.toFixed(2)),
      tabacTva: Number(tabacTva.toFixed(2)),
      tabacHtPur: Number(tabacHtPur.toFixed(2)),
      tabacTaxPct: Number(tabacTaxPct.toFixed(1)),
      assurancesTotalTtc: Math.round(totalAssurancesTtc),
      assurancesTaxesTotal: Math.round(totalAssurancesTaxes),
      assurancesTaxPct: Number(assTaxPct.toFixed(1)),
    },
  };

  void teomBalayageAmount;
}
