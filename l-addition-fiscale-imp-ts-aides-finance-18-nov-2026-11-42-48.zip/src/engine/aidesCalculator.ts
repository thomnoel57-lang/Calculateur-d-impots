import { AideItem, AidesResult, SimulationState } from '../types/fiscal';
import { clamp } from '../utils/formatters';

// Barèmes officiels indicatifs France 2026 (CAF, CROUS, Action Logement, DREES, DEPP, MESR, INSEE)
const RSA_SOCLE_SEUL = 646.52 * 12; // ~7 758 €/an
const RSA_SOCLE_COUPLE = 969.78 * 12; // ~11 637 €/an
const RSA_MAJORATION_ENFANT = 258.61 * 12; // ~3 103 €/an
const FORFAIT_LOGEMENT_RSA_SEUL = 77.58 * 12;
const FORFAIT_LOGEMENT_RSA_COUPLE = 155.17 * 12;

// Barème Bourses CROUS (mensualités x 10 mois en 2025/2026)
const CROUS_ECHELONS_ANNUELS = [
  0,     // 0 : non boursier
  1454,  // 1 : échelon 0 bis
  2163,  // 2 : échelon 1
  3071,  // 3 : échelon 2
  3943,  // 4 : échelon 3
  4816,  // 5 : échelon 4
  5540,  // 6 : échelon 5
  6243,  // 7 : échelon 6
  6335,  // 8 : échelon 7
];

export interface AidesInput {
  state: SimulationState;
  revenuNetActiviteFoyer: number;
  revenuTotalNetAvantIr: number;
  revenuFiscalReference: number;
  cotisationsRetraiteContributives: number;
  cotisationsChomageContributives: number;
  gardeEnfantsFraisAnnuels?: number;
  taxeFonciereAnnuelle?: number;
}

export function computeAides2026({
  state,
  revenuNetActiviteFoyer,
  revenuTotalNetAvantIr,
  revenuFiscalReference,
  cotisationsRetraiteContributives,
  cotisationsChomageContributives,
  gardeEnfantsFraisAnnuels = 0,
  taxeFonciereAnnuelle = 0,
}: AidesInput): AidesResult {
  const items: AideItem[] = [];
  const itemsEnNatureEtDroits: AideItem[] = [];

  const isCouple = state.situationFamiliale === 'couple';
  const nbAdultes = isCouple ? 2 : 1;
  const nbEnfants = clamp(Math.round(state.nbEnfants), 0, 10);
  const nbEnfantsMoins3Ans = clamp(Math.round(state.nbEnfantsMoins3Ans ?? 0), 0, nbEnfants);
  const uc = 1 + (isCouple ? 0.5 : 0) + nbEnfants * 0.35;
  const rfrParUc = revenuFiscalReference / uc;

  // ======================== PARTIE 1 : AIDES MONÉTAIRES DIRECTES ========================
  // 1. Bourse CROUS + Repas 1 € + Aide mobilité/mérite (étudiants)
  if (state.statut === 'etudiant' && state.echelonBourseCrous > 0) {
    const idx = clamp(Math.round(state.echelonBourseCrous), 0, 8);
    const montantBourse = CROUS_ECHELONS_ANNUELS[idx];
    if (montantBourse > 0) {
      const echelonLabel = idx === 1 ? '0 bis' : String(idx - 1);
      items.push({
        id: 'bourse_crous',
        label: `Bourse CROUS sur critères sociaux (Échelon ${echelonLabel})`,
        organisme: 'État / CROUS',
        amount: montantBourse,
        explanation: 'Versée sur 10 mois universitaires selon les revenus parentaux et la distance.',
        category: 'monetaire',
      });
      items.push({
        id: 'repas_1_euro_crous',
        label: 'Tarif social Resto U à 1 € (avantage boursier estimé)',
        organisme: 'CROUS / État',
        amount: 460,
        explanation: 'Économie estimée (~200 repas/an × 2,30 € de différence avec le tarif étudiant normal).',
        category: 'monetaire',
      });
      if (idx >= 3) {
        items.push({
          id: 'aide_merite_mobilite_etudiant',
          label: 'Aide à la mobilité / mérite / CVEC exonérée',
          organisme: 'CROUS / MESR',
          amount: 405,
          explanation: 'Exonération CVEC (105 €) + part lissée aide mobilité/mérite pour étudiants boursiers.',
          category: 'monetaire',
        });
      }
    }
  }

  // 2. RSA
  const eligibleAgeRsa = !state.ageMoins25Ans || nbEnfants > 0 || state.parentIsole;
  if (state.statut === 'rsa_inactif' && eligibleAgeRsa) {
    const baseRsa =
      (isCouple ? RSA_SOCLE_COUPLE : RSA_SOCLE_SEUL) +
      nbEnfants * RSA_MAJORATION_ENFANT +
      (state.parentIsole && nbEnfants > 0 ? 2200 : 0);
    const forfaitLogement =
      state.statutLogement === 'locataire' || state.statutLogement === 'heberge'
        ? isCouple
          ? FORFAIT_LOGEMENT_RSA_COUPLE
          : FORFAIT_LOGEMENT_RSA_SEUL
        : 0;
    const rsaNet = Math.max(0, baseRsa - forfaitLogement - Math.max(0, revenuTotalNetAvantIr * 0.62));
    if (rsaNet > 0) {
      items.push({
        id: 'rsa',
        label: 'RSA (Revenu de Solidarité Active)',
        organisme: 'CAF / Département',
        amount: Math.round(rsaNet),
        explanation: 'Allocation différentielle garantissant un revenu minimum (après forfait logement).',
        category: 'monetaire',
      });
    }
  }

  // 3. ASPA (Minimum vieillesse) si retraité à très faible pension
  if (state.statut === 'retraite') {
    const plafondAspa = isCouple ? 19268 : 12411;
    const ressourcesRetraite = state.pensionRetraiteBruteAnnuelle + (isCouple ? state.pensionConjointBruteAnnuelle : 0);
    if (ressourcesRetraite > 0 && ressourcesRetraite < plafondAspa) {
      const aspaMontant = Math.round(plafondAspa - ressourcesRetraite);
      if (aspaMontant >= 180) {
        items.push({
          id: 'aspa_minimum_vieillesse',
          label: 'ASPA (Allocation de Solidarité aux Personnes Âgées — Minimum vieillesse)',
          organisme: 'CNAV / MSA / SASPA',
          amount: aspaMontant,
          explanation: 'Complément différentiel garantissant 1 034 €/mois seul (1 605 € couple) aux petites retraites.',
          category: 'monetaire',
        });
      }
    }
  }

  // 4. AAH (Allocation aux Adultes Handicapes — déconjugalisée depuis 2023)
  if (state.beneficiaireAah) {
    const plafondAah = 12396;
    const aahNet = Math.max(0, Math.round(plafondAah - Math.max(0, revenuNetActiviteFoyer * 0.55)));
    if (aahNet >= 120) {
      items.push({
        id: 'aah_handicap',
        label: 'AAH (Allocation aux Adultes Handicapés — déconjugalisée)',
        organisme: 'CAF / MDPH',
        amount: aahNet,
        explanation: 'Jusqu’à 1 033 €/mois calculés sur les seules ressources du bénéficiaire.',
        category: 'monetaire',
      });
    }
  }

  // 5. Prime d'activité
  const isActifEligiblePrime =
    state.statut === 'salarie_non_cadre' ||
    state.statut === 'salarie_cadre' ||
    state.statut === 'fonctionnaire' ||
    state.statut === 'apprenti' ||
    state.statut === 'independant_tns' ||
    state.statut === 'micro_entrepreneur' ||
    (state.statut === 'etudiant' && revenuNetActiviteFoyer >= 13200);

  if (isActifEligiblePrime && revenuNetActiviteFoyer > 0) {
    const seuilMinActivite =
      state.statut === 'apprenti' || state.statut === 'etudiant' ? 12800 : 3000;
    if (revenuNetActiviteFoyer >= seuilMinActivite) {
      const forfaitBase = (isCouple ? 935 : 622.63) * 12 + nbEnfants * (249 * 12);
      const plafondExtinction = (isCouple ? 34500 : 24200) + nbEnfants * 4800;
      if (revenuTotalNetAvantIr < plafondExtinction) {
        const bonusActivite = clamp((revenuNetActiviteFoyer - 7200) / 10500, 0, 1) * 2080;
        const calcul =
          forfaitBase + bonusActivite + 0.61 * revenuNetActiviteFoyer - revenuTotalNetAvantIr;
        const primeEstimee = clamp(Math.round(calcul * 0.28), 0, 4800);
        if (primeEstimee >= 180) {
          items.push({
            id: 'prime_activite',
            label: 'Prime d’activité (complément de revenu d’activité)',
            organisme: 'CAF',
            amount: primeEstimee,
            explanation: 'Complément versé aux actifs modestes (~200 €/mois au SMIC seul), non imposable.',
            category: 'monetaire',
          });
        }
      }
    }
  }

  // 6. APL / ALS + Aide Mobili-Jeune Action Logement (apprentis)
  let aplMontantCalcule = 0;
  if (
    (state.statutLogement === 'locataire' || state.statutLogement === 'residence_crous') &&
    state.loyerMensuelHorsCharges > 0
  ) {
    const loyerPlafond =
      state.zoneGeo === 'paris_idf'
        ? isCouple
          ? 410
          : 330
        : state.zoneGeo === 'grande_ville'
          ? isCouple
            ? 360
            : 290
          : 260;
    const loyerRetenu = Math.min(state.loyerMensuelHorsCharges, loyerPlafond + nbEnfants * 55);
    const seuilRevenuApl =
      (state.statut === 'etudiant' ? 12000 : 14500) +
      (isCouple ? 5500 : 0) +
      nbEnfants * 4500;
    const plafondFinApl =
      (state.statut === 'etudiant' ? 23500 : 25000) +
      (isCouple ? 9000 : 0) +
      nbEnfants * 6500;

    const revenuPrisEnCompte =
      state.statut === 'etudiant' && state.echelonBourseCrous > 0
        ? Math.min(revenuFiscalReference, 6500)
        : revenuFiscalReference;

    if (revenuPrisEnCompte < plafondFinApl) {
      const ratio =
        revenuPrisEnCompte <= seuilRevenuApl
          ? 1
          : clamp(1 - (revenuPrisEnCompte - seuilRevenuApl) / (plafondFinApl - seuilRevenuApl), 0, 1);
      const aplMaxAnnuelle =
        state.statutLogement === 'residence_crous'
          ? loyerRetenu * 12 * 0.42
          : loyerRetenu * 12 * 0.72;
      const aplMontant = Math.round(aplMaxAnnuelle * ratio);
      if (aplMontant >= 180) {
        aplMontantCalcule = aplMontant;
        items.push({
          id: 'apl_als',
          label:
            state.statutLogement === 'residence_crous'
              ? 'ALS / APL Résidence universitaire'
              : 'APL / ALS (Aide personnalisée au logement)',
          organisme: 'CAF',
          amount: aplMontant,
          explanation: 'Aide mensuelle réduisant votre loyer selon zone, foyer et ressources.',
          category: 'monetaire',
        });
      }
    }

    // Mobili-Jeune Action Logement (pour apprentis < 30 ans à <= 100 % SMIC, max 100 €/mois sur reste loyer)
    if (state.statut === 'apprenti' && state.salaireBrutAnnuel <= 22000) {
      const resteLoyerAnnuel = Math.max(0, state.loyerMensuelHorsCharges * 12 - aplMontantCalcule);
      const mobiliJeune = Math.min(1200, Math.round(resteLoyerAnnuel));
      if (mobiliJeune >= 120) {
        items.push({
          id: 'mobili_jeune_action_logement',
          label: 'Aide Mobili-Jeune (prise en charge loyer alternant)',
          organisme: 'Action Logement',
          amount: mobiliJeune,
          explanation: 'Jusqu’à 100 €/mois pour les jeunes en contrat d’apprentissage ou de professionnalisation.',
          category: 'monetaire',
        });
      }
    }
  }

  // 7. Famille & Petite Enfance : Allocations familiales + Complément familial + ASF + PAJE + CMG + ARS
  if (nbEnfants >= 2) {
    const afPlein = (148.52 + Math.max(0, nbEnfants - 2) * 190.29) * 12;
    const plafondT1 = 76800 + (nbEnfants - 2) * 6400;
    const plafondT2 = 102400 + (nbEnfants - 2) * 6400;
    const coeffModulation =
      revenuFiscalReference <= plafondT1 ? 1 : revenuFiscalReference <= plafondT2 ? 0.5 : 0.25;
    const afNet = Math.round(afPlein * coeffModulation);
    items.push({
      id: 'allocations_familiales',
      label: `Allocations familiales (${nbEnfants} enfants, ${
        coeffModulation === 1 ? 'taux plein' : coeffModulation === 0.5 ? '÷ 2' : '÷ 4'
      })`,
      organisme: 'CAF',
      amount: afNet,
      explanation: 'Versées automatiquement dès le 2e enfant, modulées selon le revenu fiscal.',
      category: 'monetaire',
    });
  }

  // Complément familial (3+ enfants sous plafond de ressources)
  if (nbEnfants >= 3) {
    const plafondCfBase = (isCouple ? 58500 : 48000) + (nbEnfants - 3) * 7800;
    const plafondCfMajore = plafondCfBase * 0.52;
    if (revenuFiscalReference <= plafondCfBase) {
      const cfAmount = revenuFiscalReference <= plafondCfMajore ? 3480 : 2320;
      items.push({
        id: 'complement_familial',
        label: `Complément familial (${nbEnfants} enfants)`,
        organisme: 'CAF',
        amount: cfAmount,
        explanation: 'Aide mensuelle versée aux familles d’au moins 3 enfants sous plafond de ressources.',
        category: 'monetaire',
      });
    }
  }

  // ASF (Allocation de Soutien Familial) pour parent isolé
  if (!isCouple && state.parentIsole && nbEnfants > 0) {
    const asfMontant = Math.round(nbEnfants * 195.86 * 12);
    items.push({
      id: 'asf_soutien_familial',
      label: `ASF (Allocation de Soutien Familial — ${nbEnfants} enfant${nbEnfants > 1 ? 's' : ''})`,
      organisme: 'CAF',
      amount: asfMontant,
      explanation: '195,86 €/mois et par enfant versés au parent élevant seul ses enfants sans pension alimentaire.',
      category: 'monetaire',
    });
  }

  // PAJE Allocation de base & CMG (enfants < 3 ans)
  if (nbEnfantsMoins3Ans > 0) {
    const plafondPajePlein = (isCouple ? 45200 : 37800) + nbEnfants * 6500;
    const plafondPajePartiel = plafondPajePlein * 1.25;
    if (revenuFiscalReference <= plafondPajePartiel) {
      const paje = revenuFiscalReference <= plafondPajePlein ? 2320 : 1160;
      items.push({
        id: 'paje_allocation_base',
        label: 'PAJE — Allocation de base jeune enfant (< 3 ans)',
        organisme: 'CAF',
        amount: paje,
        explanation: 'Versée chaque mois jusqu’aux 3 ans de l’enfant sous condition de ressources.',
        category: 'monetaire',
      });
    }

    const estActif =
      state.statut !== 'rsa_inactif' && state.statut !== 'retraite' && revenuNetActiviteFoyer > 0;
    const fraisGarde = gardeEnfantsFraisAnnuels > 0 ? gardeEnfantsFraisAnnuels : nbEnfantsMoins3Ans * 6500;
    if (estActif && fraisGarde > 0) {
      const tauxCmg =
        revenuFiscalReference < 26000
          ? 0.85
          : revenuFiscalReference < 54000
            ? 0.65
            : 0.45;
      const cmgPlafond = revenuFiscalReference < 26000 ? 6100 : revenuFiscalReference < 54000 ? 3900 : 2350;
      const cmg = Math.min(Math.round(fraisGarde * tauxCmg), cmgPlafond * nbEnfantsMoins3Ans);
      if (cmg > 0) {
        items.push({
          id: 'cmg_garde_enfant',
          label: 'CMG (Complément de libre choix du mode de garde)',
          organisme: 'CAF / Pajemploi',
          amount: cmg,
          explanation: 'Prise en charge CAF (45 % à 85 %) des frais d’assistante maternelle ou micro-crèche.',
          category: 'monetaire',
        });
      }
    }
  }

  // ARS (Allocation de Rentrée Scolaire) + Pass'Sport / Pass Culture
  if (nbEnfants >= 1 && revenuFiscalReference < 28500 + (nbEnfants - 1) * 6500) {
    items.push({
      id: 'ars_rentree',
      label: 'Allocation de rentrée scolaire (ARS estimée)',
      organisme: 'CAF',
      amount: Math.round(nbEnfants * 425),
      explanation: 'Versée chaque août aux familles sous plafond pour les enfants de 6 à 18 ans.',
      category: 'monetaire',
    });
  }

  if (nbEnfants >= 1 && revenuFiscalReference < 32000 + nbEnfants * 6000) {
    items.push({
      id: 'pass_sport_culture',
      label: 'Pass’Sport / Pass Culture jeunes',
      organisme: 'État / Min. Sports & Culture',
      amount: nbEnfants * 75,
      explanation: '50 €/enfant pour l’inscription sportive + part lissée Pass Culture pour les adolescents.',
      category: 'monetaire',
    });
  } else if ((state.statut === 'etudiant' || state.statut === 'apprenti') && state.ageMoins25Ans) {
    items.push({
      id: 'pass_sport_culture',
      label: 'Pass Culture & Pass’Sport étudiant/jeune (part annuelle)',
      organisme: 'État / Min. Culture',
      amount: 100,
      explanation: 'Dotation culturelle (150 € à 18 ans) et aides sportives jeunes lissées sur la période.',
      category: 'monetaire',
    });
  }

  // 8. Chèque énergie
  if (
    rfrParUc < 11000 &&
    (state.statutLogement === 'locataire' || state.statutLogement === 'proprietaire')
  ) {
    const cheque = rfrParUc < 5700 ? 277 : rfrParUc < 6800 ? 194 : 113;
    items.push({
      id: 'cheque_energie',
      label: 'Chèque énergie (aide factures électricité/gaz)',
      organisme: 'État / ASP',
      amount: cheque,
      explanation: 'Aide annuelle attribuée sous condition de revenu fiscal par unité de consommation.',
      category: 'monetaire',
    });
  }

  // ======================== PARTIE 2 : AIDES EN NATURE, TARIFS SOCIAUX & DROITS ACQUIS ========================
  // 1. Éducation & Études gratuites (DEPP / MESR / France Compétences)
  if (state.statut === 'etudiant') {
    itemsEnNatureEtDroits.push({
      id: 'education_superieure_gratuite',
      label: 'Études supérieures publiques gratuites (Université / IUT / Prépas)',
      organisme: 'État / MESR',
      amount: 11960,
      explanation:
        'Coût réel moyen annuel financé par l’impôt (hors droits d’inscription symboliques) : ~11 960 €/an/étudiant.',
      category: 'education',
    });
  } else if (state.statut === 'apprenti') {
    itemsEnNatureEtDroits.push({
      id: 'formation_cfa_apprentissage',
      label: 'Formation gratuite en CFA / École (financée par France Compétences)',
      organisme: 'France Compétences / Taxe apprentissage',
      amount: 10800,
      explanation:
        'Prise en charge intégrale des frais de scolarité et d’alternance en CFA (~10 800 €/an en moyenne).',
      category: 'education',
    });
  }

  if (nbEnfants > 0) {
    itemsEnNatureEtDroits.push({
      id: 'ecole_gratuite_enfants',
      label: `Scolarité publique gratuite (${nbEnfants} enfant${nbEnfants > 1 ? 's' : ''} : école / collège / lycée)`,
      organisme: 'État & Collectivités',
      amount: nbEnfants * 9100,
      explanation:
        'Coût annuel moyen DEPP pris en charge par la collectivité (~7 800 € primaire, ~9 500 € collège, ~11 600 € lycée).',
      category: 'education',
    });

    // Subvention mairie/département cantine scolaire & périscolaire (quotient familial)
    const cantineSubParEnfant =
      rfrParUc < 15000 ? 680 : rfrParUc < 28000 ? 450 : 250;
    itemsEnNatureEtDroits.push({
      id: 'cantine_periscolaire_subvention',
      label: `Subvention cantine scolaire & périscolaire (${nbEnfants} enfant${nbEnfants > 1 ? 's' : ''})`,
      organisme: 'Commune / Département / CAF',
      amount: nbEnfants * cantineSubParEnfant,
      explanation:
        'Part du repas scolaire et de l’accueil périscolaire financée par la collectivité selon votre quotient familial.',
      category: 'famille_logement',
    });
  }

  // Subvention crèche publique (PSU CAF + Mairie) si enfants < 3 ans
  if (nbEnfantsMoins3Ans > 0) {
    itemsEnNatureEtDroits.push({
      id: 'subvention_creche_petite_enfance',
      label: `Subvention petite enfance / Crèche publique PSU (${nbEnfantsMoins3Ans} enfant${nbEnfantsMoins3Ans > 1 ? 's' : ''} < 3 ans)`,
      organisme: 'CAF (PSU) & Commune',
      amount: nbEnfantsMoins3Ans * 7600,
      explanation:
        'Coût moyen d’une place en crèche municipale financé par la CAF et la mairie au-delà du tarif familial.',
      category: 'famille_logement',
    });
  }

  // 2. Logement social HLM (subvention implicite de loyer) & Dégrèvement Taxe Foncière modeste/senior
  if (state.logementSocialHlm && state.statutLogement === 'locataire') {
    const subHlm =
      state.zoneGeo === 'paris_idf'
        ? 4400
        : state.zoneGeo === 'grande_ville'
          ? 3100
          : 2100;
    itemsEnNatureEtDroits.push({
      id: 'subvention_hlm_logement_social',
      label: 'Logement social HLM (avantage loyer modéré vs marché privé)',
      organisme: 'Bailleurs sociaux / Action Logement / État',
      amount: subHlm,
      explanation:
        'Écart moyen annuel entre un loyer HLM conventionné et un loyer privé équivalent dans votre zone.',
      category: 'famille_logement',
    });
  }

  if (
    state.statutLogement === 'proprietaire' &&
    state.statut === 'retraite' &&
    taxeFonciereAnnuelle > 0 &&
    revenuFiscalReference < 18500 * (isCouple ? 1.5 : 1)
  ) {
    const degrev = Math.round(taxeFonciereAnnuelle * 0.65);
    if (degrev >= 100) {
      itemsEnNatureEtDroits.push({
        id: 'degrevement_taxe_fonciere_modeste',
        label: 'Exonération / Plafonnement Taxe Foncière (revenus modestes / senior)',
        organisme: 'Collectivités / DGFiP',
        amount: degrev,
        explanation: 'Allègement de taxe foncière accordé aux propriétaires seniors ou modestes sous plafond RFR.',
        category: 'famille_logement',
      });
    }
  }

  // 3. Tarifs sociaux transports en commun & Bonus écologique / MaPrimeRénov'
  const hasTarifSocialTransport =
    state.statut === 'rsa_inactif' ||
    state.statut === 'chomeur' ||
    (state.statut === 'etudiant' && state.echelonBourseCrous > 0) ||
    nbEnfants >= 3;
  if (hasTarifSocialTransport) {
    const montantTransport =
      state.zoneGeo === 'paris_idf'
        ? state.statut === 'rsa_inactif' || state.statut === 'chomeur'
          ? 780
          : 440
        : state.statut === 'rsa_inactif' || state.statut === 'chomeur'
          ? 480
          : 280;
    itemsEnNatureEtDroits.push({
      id: 'tarif_social_transports',
      label: 'Tarification sociale / gratuité Transports & Carte Famille Nombreuse',
      organisme: 'Régions / Autorités Mobilité (IDFM…)',
      amount: montantTransport,
      explanation:
        'Réduction de 50 % à 100 % sur les abonnements métro, bus, tram et TER pour bénéficiaires RSA, demandeurs d’emploi, boursiers ou familles ≥ 3 enfants.',
      category: 'famille_logement',
    });
  }

  if (state.typeVehicule === 'electrique' && rfrParUc < 26200) {
    itemsEnNatureEtDroits.push({
      id: 'bonus_ecologique_lisse',
      label: 'Bonus écologique véhicule électrique (part lissée sur 6 ans)',
      organisme: 'État / ADEME',
      amount: 650,
      explanation: 'Aide publique de 3 000 € à 4 000 € à l’achat électrique sous plafond de revenu, lissée sur la durée de détention.',
      category: 'famille_logement',
    });
  }

  // 4. Santé (Assurance Maladie Sécu + Complémentaire Santé Solidaire CSS)
  const santeAdulte =
    state.statut === 'retraite'
      ? 6400
      : state.statut === 'etudiant' || state.statut === 'apprenti'
        ? 1850
        : 3100;
  const santeConjoint =
    isCouple ? (state.statutConjoint === 'retraite' ? 6400 : 3100) : 0;
  const santeEnfants = nbEnfants * 1400;
  const eligibleCssGratuite =
    state.statut === 'rsa_inactif' || state.beneficiaireAah || rfrParUc < 10339;
  const eligibleCssParticipative = !eligibleCssGratuite && rfrParUc < 13957;
  const cssBonus = eligibleCssGratuite
    ? 750 * nbAdultes
    : eligibleCssParticipative
      ? 360 * nbAdultes
      : 0;
  const totalSante = santeAdulte + santeConjoint + santeEnfants + cssBonus;

  itemsEnNatureEtDroits.push({
    id: 'sante_assurance_maladie',
    label: eligibleCssGratuite
      ? 'Santé gratuite (Sécurité sociale + Complémentaire Santé Solidaire)'
      : 'Soins & remboursements Santé (Assurance Maladie / Hôpital public)',
    organisme: 'Sécurité sociale (CNAM)',
    amount: totalSante,
    explanation:
      'Dépense publique annuelle moyenne prise en charge par la Sécu selon l’âge/situation (chiffres DREES) + CSS si éligible.',
    category: 'sante',
  });

  // 5. Droits acquis à la retraite, chômage & Formation professionnelle (CPF / France Travail)
  const droitsRetraiteAcquis = Math.round(cotisationsRetraiteContributives * 0.75);
  const droitsChomageAcquis = Math.round(cotisationsChomageContributives * 0.65);
  if (droitsRetraiteAcquis > 0) {
    itemsEnNatureEtDroits.push({
      id: 'droits_retraite_constitues',
      label: 'Droits à la retraite acquis dans l’année (trimestres & points Agirc-Arrco)',
      organisme: 'CNAV / Agirc-Arrco / SSI',
      amount: droitsRetraiteAcquis,
      explanation:
        'Part de vos cotisations retraite qui n’est pas un impôt perdu mais un salaire différé vous ouvrant une pension future (hors part solidarité/CSG).',
      category: 'retraite_droits',
    });
  }
  if (droitsChomageAcquis > 0) {
    itemsEnNatureEtDroits.push({
      id: 'droits_chomage_assures',
      label: 'Assurance chômage & garantie salaires acquises (droits ARE)',
      organisme: 'France Travail / Unédic',
      amount: droitsChomageAcquis,
      explanation:
        'Valeur actuarielle de la couverture chômage (ARE) financée par vos cotisations employeur.',
      category: 'retraite_droits',
    });
  }

  // CPF / Formation continue / Accompagnement France Travail
  const isActifCpf =
    state.statut === 'salarie_non_cadre' ||
    state.statut === 'salarie_cadre' ||
    state.statut === 'fonctionnaire' ||
    state.statut === 'independant_tns' ||
    state.statut === 'micro_entrepreneur' ||
    state.statut === 'apprenti';
  if (state.statut === 'chomeur' || state.statut === 'rsa_inactif') {
    itemsEnNatureEtDroits.push({
      id: 'formation_cpf_france_travail',
      label: 'Accompagnement & Formations financées (France Travail / CPF / Région)',
      organisme: 'France Travail / France Compétences',
      amount: state.statut === 'chomeur' ? 1350 : 950,
      explanation:
        'Valeur moyenne annuelle des bilans, accompagnements et formations professionnelles financés pour les demandeurs d’emploi.',
      category: 'retraite_droits',
    });
  } else if (isActifCpf && revenuNetActiviteFoyer > 0) {
    itemsEnNatureEtDroits.push({
      id: 'formation_cpf_france_travail',
      label: 'Droits Formation CPF & Plan de formation (500 €/an/actif)',
      organisme: 'Caisse des Dépôts / OPCO / France Compétences',
      amount: 500 * (isCouple && state.statutConjoint !== 'aucun' && state.statutConjoint !== 'retraite' ? 2 : 1),
      explanation:
        'Alimentation annuelle du Compte Personnel de Formation (500 €/an, 800 € moins qualifiés) financée par les cotisations formation.',
      category: 'retraite_droits',
    });
  }

  // 6. Services publics collectifs & infrastructures (INSEE Portrait Social)
  const servicesCollectifs = Math.round(nbAdultes * 3100 + nbEnfants * 1100);
  itemsEnNatureEtDroits.push({
    id: 'services_collectifs_infrastructures',
    label: 'Services publics collectifs (transports, routes, police, justice, défense, culture)',
    organisme: 'État & Collectivités locales',
    amount: servicesCollectifs,
    explanation:
      'Coût moyen des services régaliens et locaux financés pour chaque habitant (barème INSEE Portrait Social).',
    category: 'services_publics',
  });

  const totalAidesMonetaires = items.reduce((s, item) => s + item.amount, 0);
  const totalPrestationsEnNatureEtDroits = itemsEnNatureEtDroits.reduce(
    (s, item) => s + item.amount,
    0
  );
  const totalAidesEtServicesComplet =
    totalAidesMonetaires + totalPrestationsEnNatureEtDroits;

  return {
    totalAidesMonetaires,
    totalPrestationsEnNatureEtDroits,
    totalAidesEtServicesComplet,
    items,
    itemsEnNatureEtDroits,
    servicesPublicsEstimes: totalPrestationsEnNatureEtDroits,
    servicesPublicsNote:
      'Inclut à 100 % allocations directes (CAF, CROUS, ASPA, AAH, ASF, CMG, PAJE, Mobili-Jeune), tarifs sociaux (cantine, crèche, HLM, transports), études gratuites, soins CNAM/CSS, droits retraite/CPF et services publics.',
  };
}
