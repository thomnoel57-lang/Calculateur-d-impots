import assert from 'node:assert/strict';
import test from 'node:test';
import { PRESET_PROFILES } from '../data/presets';
import { runSimulation } from './taxEngine';

test('All 12 preset profiles simulate cleanly with finite values and zero double-counting', () => {
  for (const preset of PRESET_PROFILES) {
    const res = runSimulation(preset.state);
    assert.ok(Number.isFinite(res.richesseCreeeTotale), `${preset.id} richesse finite`);
    assert.ok(Number.isFinite(res.totalPrelevements), `${preset.id} totalPrelevements finite`);
    assert.ok(Number.isFinite(res.tauxPrelevementReelPct), `${preset.id} taux brut finite`);
    assert.ok(Number.isFinite(res.tauxNetApresAidesPct), `${preset.id} taux net finite`);
    assert.ok(res.jourLiberationIndex >= 0 && res.jourLiberationIndex <= 365, `${preset.id} liberation bounds`);

    // Memo items must never add to totals
    assert.equal(res.itemsById['pas_info'].amount, 0);
    assert.equal(res.itemsById['pfu_total_memo'].amount, 0);
    assert.equal(res.itemsById['redevance_tv_abrogee_memo'].amount, 0);

    // Sum of families equals totalPrelevements
    const sumFamilies = res.families.reduce((s, f) => s + f.amount, 0);
    assert.equal(sumFamilies, res.totalPrelevements, `${preset.id} families sum matches total`);

    // 100% CPA accounting balance: zero euro gap between wealth created and outflows/reserves/net
    assert.equal(
      res.ecartBalanceComptable,
      0,
      `${preset.id} double-entry accounting reconciliation must equal 0 € (got ${res.ecartBalanceComptable})`
    );

    // Every preset includes corporate & holding taxes 100% by default
    assert.equal(
      preset.state.inclureTaxesSocieteEtHolding,
      true,
      `${preset.id} must include corporate/holding taxes by default`
    );

    // Integral 100% net rate (including free education/health/pension rights) <= cash-only net rate
    assert.ok(
      res.tauxNetApresAidesPct <= res.tauxNetApresAidesMonetairesPct + 1e-9,
      `${preset.id} integral rate should reflect non-monetary transfers`
    );
  }
});

test('Student and RSA profiles receive social aids + free education/healthcare and have negative net tax rate', () => {
  const etudiant = PRESET_PROFILES.find((p) => p.id === 'etudiant_boursier')!;
  const resEtud = runSimulation(etudiant.state);
  assert.ok(resEtud.aides.totalAidesMonetaires > 5000, 'Student CROUS + APL should exceed 5000 €');
  const uniItem = resEtud.aides.itemsEnNatureEtDroits.find(
    (i) => i.id === 'education_superieure_gratuite'
  );
  assert.equal(uniItem?.amount, 11960, 'Student gets 11 960 € free university tuition in-kind');
  assert.ok(resEtud.aides.totalAidesEtServicesComplet > 22000);
  assert.ok(resEtud.tauxNetApresAidesPct < 0, 'Student net rate after aids should be negative');
  assert.equal(resEtud.itemsById['ir_bareme_travail'].amount, 0, 'Student 5k€ job is exempt from IR');

  const rsa = PRESET_PROFILES.find((p) => p.id === 'rsa_beneficiaire')!;
  const resRsa = runSimulation(rsa.state);
  assert.ok(resRsa.aides.totalAidesMonetaires > 7000, 'RSA + APL should exceed 7000 €');
  assert.ok(resRsa.aides.totalPrestationsEnNatureEtDroits > 6000, 'RSA gets CNAM + CSS + public services');
  assert.ok(resRsa.tauxNetApresAidesPct < 0, 'RSA net rate after aids should be negative');
});

test('Family, median worker and retiree profiles include school, pension rights and CNAM healthcare 100%', () => {
  const famille = PRESET_PROFILES.find((p) => p.id === 'famille_classe_moyenne')!;
  const resFam = runSimulation(famille.state);
  const ecole = resFam.aides.itemsEnNatureEtDroits.find((i) => i.id === 'ecole_gratuite_enfants');
  assert.equal(ecole?.amount, 18200, '2 children receive 18 200 € free public schooling');

  const median = PRESET_PROFILES.find((p) => p.id === 'salarie_median')!;
  const resMed = runSimulation(median.state);
  const retraite = resMed.aides.itemsEnNatureEtDroits.find(
    (i) => i.id === 'droits_retraite_constitues'
  );
  assert.ok((retraite?.amount ?? 0) > 5000, 'Median worker accrues contributory pension rights');

  const retraitePreset = PRESET_PROFILES.find((p) => p.id === 'retraites_proprietaires')!;
  const resRet = runSimulation(retraitePreset.state);
  const sante = resRet.aides.itemsEnNatureEtDroits.find(
    (i) => i.id === 'sante_assurance_maladie'
  );
  assert.equal(sante?.amount, 12800, 'Retired couple receives 12 800 € CNAM healthcare');
});

test('Apprentice under 1 SMIC pays 0 € IR and receives CFA training in-kind', () => {
  const apprenti = PRESET_PROFILES.find((p) => p.id === 'apprenti_alternant')!;
  const res = runSimulation(apprenti.state);
  assert.equal(res.itemsById['ir_bareme_travail'].amount, 0);
  assert.ok(res.aides.totalAidesMonetaires > 1000, 'Apprentice gets APL/Prime');
  const cfa = res.aides.itemsEnNatureEtDroits.find(
    (i) => i.id === 'formation_cfa_apprentissage'
  );
  assert.equal(cfa?.amount, 10800);
});

test('Corporate vs Personal toggle cleanly separates company taxes from personal pocket taxes', () => {
  const ultra = PRESET_PROFILES.find((p) => p.id === 'ultra_riche_actionnaire')!;
  const resPersoOnly = runSimulation({ ...ultra.state, inclureTaxesSocieteEtHolding: false });
  const resWithCorp = runSimulation({ ...ultra.state, inclureTaxesSocieteEtHolding: true });

  assert.equal(resPersoOnly.totalPrelevements, resPersoOnly.impotsPersonnelsSeuls);
  assert.ok(resPersoOnly.impotsPayesParEntreprise > 1000000, 'Company pays > 1M€ IS/holding/CFE');
  assert.equal(
    resWithCorp.totalPrelevements,
    resWithCorp.impotsPersonnelsSeuls + resWithCorp.impotsPayesParEntreprise
  );
  assert.ok(resWithCorp.totalPrelevements > resPersoOnly.totalPrelevements);
  assert.equal(resPersoOnly.ecartBalanceComptable, 0);
  assert.equal(resWithCorp.ecartBalanceComptable, 0);
});

test('Holding routing defers personal PFU and creates latent exit tax; Bernard Arnault cash-out < valuation', () => {
  const ultra = PRESET_PROFILES.find((p) => p.id === 'ultra_riche_actionnaire')!;
  const allPocket = runSimulation({
    ...ultra.state,
    overrides: { ...ultra.state.overrides, partRemonteeHoldingPct: 0 },
  });
  const mostlyHolding = runSimulation({
    ...ultra.state,
    overrides: { ...ultra.state.overrides, partRemonteeHoldingPct: 80 },
  });

  assert.ok(
    mostlyHolding.itemsById['pfu_dividendes_poche'].amount <
      allPocket.itemsById['pfu_dividendes_poche'].amount,
    'Routing 80% to holding cuts immediate personal PFU'
  );
  assert.ok(
    mostlyHolding.holdingAndValuation.reserveRestantEnHolding > 1500000,
    'Money stays blocked inside holding'
  );
  assert.ok(
    mostlyHolding.holdingAndValuation.impotLatentSiSortieHolding > 400000,
    'Latent tax waits if extracted from holding'
  );
  assert.ok(
    mostlyHolding.holdingAndValuation.cashReelSiToutVendu <
      mostlyHolding.holdingAndValuation.valorisationPapierEstimee * 0.6,
    'Selling 100% of company yields far less real cash than paper valuation'
  );
  assert.equal(allPocket.ecartBalanceComptable, 0);
  assert.equal(mostlyHolding.ecartBalanceComptable, 0);
});

test('Holding deferred taxes (impots en attente), treasury IS, 2% passive tax, surtaxe IS, and 150-0 B ter reconcile at 0 EUR gap', () => {
  const ultra = PRESET_PROFILES.find((p) => p.id === 'ultra_riche_actionnaire')!;
  const withLatent = runSimulation({
    ...ultra.state,
    inclureTaxesSocieteEtHolding: true,
    inclureImpotsLatentsHolding: true,
    overrides: {
      ...ultra.state.overrides,
      chiffreAffairesEntreprise: 3_500_000_000, // triggers +41.2% surtaxe IS
      beneficeSocieteAvantIs: 8_000_000,
      dividendesBrutsAnnuels: 2_500_000,
      partRemonteeHoldingPct: 80,
      tresorerieAccumuleeHolding: 10_000_000,
      rendementTresorerieHoldingPct: 4, // 400k€ financial yield -> 100k€ IS
      actifsNonOperationnelsHolding: 8_000_000, // > 5M€ -> 160k€ (2%)
      plusValuesEnReport150OBTer: 4_000_000,
    },
  });
  const withoutLatent = runSimulation({
    ...ultra.state,
    inclureTaxesSocieteEtHolding: true,
    inclureImpotsLatentsHolding: false,
    overrides: {
      ...ultra.state.overrides,
      chiffreAffairesEntreprise: 3_500_000_000,
      beneficeSocieteAvantIs: 8_000_000,
      dividendesBrutsAnnuels: 2_500_000,
      partRemonteeHoldingPct: 80,
      tresorerieAccumuleeHolding: 10_000_000,
      rendementTresorerieHoldingPct: 4,
      actifsNonOperationnelsHolding: 8_000_000,
      plusValuesEnReport150OBTer: 4_000_000,
    },
  });

  // Immediate corporate & holding taxes
  assert.ok(withLatent.itemsById['surtaxe_is_grandes_entreprises'].amount > 700000);
  assert.equal(withLatent.itemsById['holding_is_produits_financiers'].amount, 100000);
  assert.equal(withLatent.itemsById['holding_taxe_patrimoniale_2pct'].amount, 160000);

  // Pending deferred taxes on BOTH holding reserves and retained subsidiary profit
  assert.ok(withLatent.holdingAndValuation.impotLatentSiSortieHolding > 600000);
  assert.ok(withLatent.holdingAndValuation.impotLatentSiSortieFiliale > 300000);
  assert.equal(
    withLatent.holdingAndValuation.totalImpotsEnAttenteFlux,
    withLatent.holdingAndValuation.impotLatentSiSortieHolding +
      withLatent.holdingAndValuation.impotLatentSiSortieFiliale
  );
  assert.ok(withLatent.holdingAndValuation.impotLatentReport150OBTer > 1_200_000);

  // Toggling inclureImpotsLatentsHolding transfers pending tax between taxes and reserves cleanly
  assert.equal(withLatent.impotsEnAttenteHolding, withLatent.holdingAndValuation.totalImpotsEnAttenteFlux);
  assert.equal(withoutLatent.impotsEnAttenteHolding, 0);
  assert.equal(withLatent.richesseCreeeTotale, withoutLatent.richesseCreeeTotale);
  assert.equal(withLatent.resteNetReelPur, withoutLatent.resteNetReelPur);
  assert.equal(
    withLatent.totalPrelevements - withoutLatent.totalPrelevements,
    withLatent.impotsEnAttenteHolding
  );
  assert.equal(withLatent.ecartBalanceComptable, 0);
  assert.equal(withoutLatent.ecartBalanceComptable, 0);
});

test('Expanded French 2026 aids cover Mobili-Jeune, ASF, PAJE/CMG/crèche, HLM, AAH, ASPA, and social tariffs', () => {
  // 1. Apprentice gets Mobili-Jeune Action Logement
  const apprenti = PRESET_PROFILES.find((p) => p.id === 'apprenti_alternant')!;
  const resApprenti = runSimulation(apprenti.state);
  const mobili = resApprenti.aides.items.find((i) => i.id === 'mobili_jeune_action_logement');
  assert.ok((mobili?.amount ?? 0) >= 1000, 'Apprentice paying rent receives Mobili-Jeune');

  // 2. Solo working parent with 1 child < 3 ans and HLM receives ASF, PAJE, CMG, crèche PSU, and HLM subsidy
  const baseMedian = PRESET_PROFILES.find((p) => p.id === 'salarie_median')!;
  const soloParentRes = runSimulation({
    ...baseMedian.state,
    situationFamiliale: 'celibataire',
    statutConjoint: 'aucun',
    parentIsole: true,
    nbEnfants: 2,
    nbEnfantsMoins3Ans: 1,
    statutLogement: 'locataire',
    logementSocialHlm: true,
    zoneGeo: 'grande_ville',
  });
  assert.ok(soloParentRes.aides.items.some((i) => i.id === 'asf_soutien_familial'));
  assert.ok(soloParentRes.aides.items.some((i) => i.id === 'paje_allocation_base'));
  assert.ok(soloParentRes.aides.items.some((i) => i.id === 'cmg_garde_enfant'));
  assert.ok(soloParentRes.aides.items.some((i) => i.id === 'pass_sport_culture'));
  assert.ok(
    soloParentRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'subvention_creche_petite_enfance')
  );
  assert.ok(
    soloParentRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'subvention_hlm_logement_social')
  );
  assert.ok(
    soloParentRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'cantine_periscolaire_subvention')
  );
  assert.equal(soloParentRes.ecartBalanceComptable, 0);

  // 3. Low-pension retiree with AAH receives ASPA + AAH + Taxe Foncière relief
  const retraite = PRESET_PROFILES.find((p) => p.id === 'retraites_proprietaires')!;
  const lowRetRes = runSimulation({
    ...retraite.state,
    situationFamiliale: 'celibataire',
    statutConjoint: 'aucun',
    pensionRetraiteBruteAnnuelle: 8400,
    beneficiaireAah: true,
    overrides: {
      ...retraite.state.overrides,
      taxeFonciereAnnuelle: 900,
    },
  });
  assert.ok(lowRetRes.aides.items.some((i) => i.id === 'aspa_minimum_vieillesse'));
  assert.ok(lowRetRes.aides.items.some((i) => i.id === 'aah_handicap'));
  assert.ok(
    lowRetRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'degrevement_taxe_fonciere_modeste')
  );

  // 4. Unemployed profile receives social transport fares and France Travail/CPF support
  const chomeur = PRESET_PROFILES.find((p) => p.id === 'chomeur_are')!;
  const chomeurRes = runSimulation(chomeur.state);
  assert.ok(
    chomeurRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'tarif_social_transports')
  );
  assert.ok(
    chomeurRes.aides.itemsEnNatureEtDroits.some((i) => i.id === 'formation_cpf_france_travail')
  );
});

